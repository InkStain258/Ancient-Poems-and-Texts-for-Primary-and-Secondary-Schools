import type { ClassicalWork } from '../types';

export const primaryWorks: ClassicalWork[] = [
  {
    id: 'p_001',
    title: '静夜思',
    author: '李白',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '一年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['思乡'],
    text: {
      original: '床前明月光，疑是地上霜。举头望明月，低头思故乡。',
      sentences: ['床前明月光', '疑是地上霜', '举头望明月', '低头思故乡'],
      rhymeScheme: ['光', '霜', '乡'],
    },
    annotations: [
      { term: '床', note: '指井台，一说指井栏。也有解为卧床的。' },
      { term: '疑', note: '怀疑，以为。' },
      { term: '举头', note: '抬头。' },
      { term: '霜', note: '秋夜地面凝结的白色冰晶。此处形容月光洁白如霜。' },
      { term: '故乡', note: '家乡，出生或长期居住的地方。' },

      { term: '思故乡', note: '想念家乡。思，思念。' }
    ],
    translation: '明亮的月光洒在床前，好像地上泛起了一层白霜。抬头看那空中的一轮明月，不由得低头沉思，想起远方的家乡。',
    literaryInfo: {
      authorBio: '李白（701年—762年），字太白，号青莲居士，唐代伟大的浪漫主义诗人，被后人誉为"诗仙"。',
      background: '此诗作于李白离开故乡漫游途中，客居他乡的夜晚，看到明月引发了思乡之情。',
      significance: `这首诗语言朴素无华，却表达了深切的思乡之情，是千古传诵的思乡名篇。诗中以月光引发霜的错觉，由错觉转入仰望，再由仰望引发低首沉思，情感层层递进。"疑"字刻画出朦胧恍惚的心理状态，将月光的清冷与内心的孤寂融为一体。全诗二十字，却包含了从视觉到心理、从外界到内心的完整转换，堪称"以少胜多"的典范。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '床前明月光', emotion: '宁静', intensity: 3 },
          { segment: '疑是地上霜', emotion: '惊讶', intensity: 5 },
          { segment: '举头望明月', emotion: '感伤', intensity: 7 },
          { segment: '低头思故乡', emotion: '深切思念', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_002',
    title: '春晓',
    author: '孟浩然',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '人生'],
    text: {
      original: '春眠不觉晓，处处闻啼鸟。夜来风雨声，花落知多少。',
      sentences: ['春眠不觉晓', '处处闻啼鸟', '夜来风雨声', '花落知多少'],
      rhymeScheme: ['晓', '鸟', '少'],
    },
    annotations: [
      { term: '晓', note: '天刚亮的时候。' },
      { term: '不觉晓', note: '不知不觉天就亮了。' },
      { term: '闻', note: '听到。' },
      { term: '啼鸟', note: '鸟的啼叫声。' },
      { term: '花落知多少', note: '不知有多少花被风雨打落了。知多少，不知有多少，表达惜春之情。' },

      { term: '眠', note: '睡觉。' },
      { term: '知多少', note: '不知有多少。表示感叹。' }
    ],
    translation: '春天的夜晚一直甜甜地睡到天亮，醒来时只听到到处是鸟儿的啼鸣声。回想昨夜那阵阵风雨声，不知有多少花瓣被吹落在地。',
    literaryInfo: {
      authorBio: '孟浩然（689年—740年），名浩，字浩然，号孟山人，唐代著名山水田园派诗人。',
      background: '此诗是诗人在春天清晨醒来时的即兴之作，表达了对春天的喜爱和对落花的惋惜。',
      significance: `全诗以清新自然的笔调，写出了春晨的美好与惜春之情。前两句写醒后的听觉感受，以鸟鸣声烘托春天的生机；后两句转入对昨夜风雨的回味，以问句收束，含蓄而深远。"花落知多少"既是惜花，也是惜春，更暗含对美好事物易逝的感慨。全诗四句由"不觉"到"闻"，由"闻"到"忆"，再由"忆"到"问"，层层推进，言有尽而意无穷。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '近景', content: '春眠初醒，鸟鸣入耳', keywords: ['春眠', '啼鸟'] },
          { level: '中景', content: '昨夜风雨声', keywords: ['夜来', '风雨'] },
          { level: '远景', content: '风雨过后的落花', keywords: ['花落', '多少'] },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_003',
    title: '望庐山瀑布',
    author: '李白',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水'],
    text: {
      original: '日照香炉生紫烟，遥看瀑布挂前川。飞流直下三千尺，疑是银河落九天。',
      sentences: ['日照香炉生紫烟', '遥看瀑布挂前川', '飞流直下三千尺', '疑是银河落九天'],
      rhymeScheme: ['烟', '川', '天'],
    },
    annotations: [
      { term: '香炉', note: '指庐山香炉峰。' },
      { term: '紫烟', note: '日光透过云雾折射出的紫色烟雾。' },
      { term: '挂前川', note: '悬挂在山前的河面上。挂，悬挂，化动为静。' },
      { term: '九天', note: '古代传说天有九层，九天指天的最高处。' },
      { term: '疑', note: '怀疑，以为。此处是夸张想象。' },
      { term: '银河', note: '晴天夜空中的银河，此处比喻瀑布。' },

    ],
    translation: '太阳照射在香炉峰上，升起紫色的云烟，远远望去，瀑布像白绢悬挂在山前。激流飞快地直泻而下，有三千尺之高，让人怀疑是银河从天上落了下来。',
    literaryInfo: {
      authorBio: '李白（701年—762年），字太白，号青莲居士，唐代伟大的浪漫主义诗人，被后人誉为"诗仙"。',
      background: '此诗作于李白游历庐山时，被庐山瀑布的壮丽景色所震撼而作。',
      significance: `此诗以夸张的手法描绘了庐山瀑布的雄伟壮丽。"飞流直下三千尺"以极度夸张写瀑布之高之急，"疑是银河落九天"更以天上银河倾泻而下的奇想，将瀑布的壮观推向极致。一个"挂"字化动为静，远观瀑布宛如白练悬于山前；而"飞""落"二字又使画面由静转动，气势磅礴。全诗从实景到想象，由人间到天上，体现了李白浪漫主义诗歌的典型风格。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '香炉峰紫烟缭绕', keywords: ['日照', '紫烟'] },
          { level: '中景', content: '瀑布如白练挂前山', keywords: ['瀑布', '挂前川'] },
          { level: '近景', content: '飞流直下的壮观', keywords: ['飞流', '三千尺'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_004',
    title: '登鹳雀楼',
    author: '王之涣',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['哲理', '山水'],
    text: {
      original: '白日依山尽，黄河入海流。欲穷千里目，更上一层楼。',
      sentences: ['白日依山尽', '黄河入海流', '欲穷千里目', '更上一层楼'],
      rhymeScheme: ['流', '楼'],
    },
    annotations: [
      { term: '鹳雀楼', note: '在今山西省永济市，因时有鹳雀栖其上而得名。' },
      { term: '白日', note: '太阳。' },
      { term: '依', note: '依傍，沿着。' },
      { term: '穷', note: '穷尽，看尽。' },
      { term: '千里目', note: '看到千里之外，形容视野辽阔。' },

      { term: '依山尽', note: '沿着山峦沉落。依，沿着，靠着。尽，消失。' },
    ],
    translation: '太阳依傍着连绵的群山渐渐落下，黄河之水向着大海奔腾东流。想要看到千里之外更远的景色，就要再登上更高的一层楼。',
    literaryInfo: {
      authorBio: '王之涣（688年—742年），字季凌，唐代诗人，以边塞诗见长。',
      background: '诗人登临鹳雀楼时，被眼前壮阔的景象所感染，即景抒情，写下了这首哲理诗。',
      significance: `此诗将自然景观与人生哲理巧妙结合。前两句写景，以"依"字写落日缓缓沉山的动态，以"入"字写黄河奔涌向海的气势，勾勒出雄浑壮阔的画面。后两句由景生理，"欲穷千里目，更上一层楼"成为千古流传的哲理名句，寓意站得高才能看得远，只有不断进取才能达到更高的境界。全诗由景入理，浑然天成，意境深远。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '诗人在鹳雀楼上远眺，目送落日西沉、黄河东流，感悟到登高方能望远的道理。',
        timeline: [
          { event: '日落群山', order: 1 },
          { event: '黄河入海', order: 2 },
          { event: '登高远望', order: 3 },
          { event: '领悟哲理', order: 4 },
          { event: '更上一层楼', order: 5 },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_005',
    title: '悯农（其二）',
    author: '李绅',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['人生', '哲理'],
    text: {
      original: '锄禾日当午，汗滴禾下土。谁知盘中餐，粒粒皆辛苦。',
      sentences: ['锄禾日当午', '汗滴禾下土', '谁知盘中餐', '粒粒皆辛苦'],
      rhymeScheme: ['午', '土', '苦'],
    },
    annotations: [
      { term: '锄禾', note: '用锄头松禾苗周围的土。' },
      { term: '日当午', note: '太阳当头直射，指正午时分。' },
      { term: '盘中餐', note: '碗里的饭食。' },
      { term: '皆', note: '都，全。' },
      { term: '辛苦', note: '劳苦，辛勤劳作。' },

      { term: '汗滴禾下土', note: '汗水滴入禾苗下的泥土中。形容劳作辛苦。' },
    ],
    translation: '农民在正午烈日下给禾苗锄草松土，汗水一滴滴落入禾苗下的泥土。又有谁知道盘中的饭食，每一粒都来自农民的辛苦劳作。',
    literaryInfo: {
      authorBio: '李绅（772年—846年），字公垂，唐代诗人。其《悯农》诗两首流传极广。',
      background: '诗人看到农民辛苦劳作的场景，感慨粮食来之不易而作此诗。',
      significance: `这首诗语言朴实，感情真挚，深刻地反映了农民的辛劳。"锄禾日当午，汗滴禾下土"选取最炎热的中午劳作场景，以"日当午"与"汗滴土"的强烈对比突出农民之苦。后两句由叙事转入议论，"谁知"二字饱含愤慨与惋惜，"粒粒皆辛苦"以叠词强化语势，告诫人们珍惜粮食。全诗从具体场景上升到普遍道理，具有深刻的教育意义。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '锄禾日当午', emotion: '辛劳', intensity: 7 },
          { segment: '汗滴禾下土', emotion: '艰苦', intensity: 8 },
          { segment: '谁知盘中餐', emotion: '感叹', intensity: 6 },
          { segment: '粒粒皆辛苦', emotion: '感慨', intensity: 9 },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_006',
    title: '江南',
    author: '汉乐府',
    dynasty: '汉',
    gradeLevel: { stage: '小学', grade: '一年级' },
    genre: { category: '诗', subGenre: '古体诗' },
    themes: ['山水', '田园'],
    text: {
      original: '江南可采莲，莲叶何田田。鱼戏莲叶间。鱼戏莲叶东，鱼戏莲叶西，鱼戏莲叶南，鱼戏莲叶北。',
      sentences: ['江南可采莲', '莲叶何田田', '鱼戏莲叶间', '鱼戏莲叶东', '鱼戏莲叶西', '鱼戏莲叶南', '鱼戏莲叶北'],
    },
    annotations: [
      { term: '田田', note: '莲叶茂盛的样子。' },
      { term: '乐府', note: '古代音乐官署，也指由其采集的民间诗歌。' },
      { term: '可', note: '适宜，正好。' },
      { term: '戏', note: '嬉戏，游玩。' },

    ],
    translation: '江南又到了适宜采莲的季节，莲叶浮出水面，挨挨挤挤，重重叠叠，茂盛如盖。鱼儿在莲叶间嬉戏玩耍。鱼儿在莲叶东边嬉戏，鱼儿在莲叶西边嬉戏，鱼儿在莲叶南边嬉戏，鱼儿在莲叶北边嬉戏。',
    literaryInfo: {
      authorBio: '汉乐府，汉代官方音乐机构采集的民间诗歌，作者多为无名氏。',
      background: '此诗为汉代采莲歌谣，描绘了江南采莲时的欢乐景象。',
      significance: `这是中国最早的采莲诗，也是乐府诗的名篇。全诗以简朴的语言展现了江南水乡的美丽景色和欢乐气氛。前两句写莲叶茂盛，点明季节与地点；"鱼戏莲叶间"为总写，以下四句分别从东、西、南、北四个方位反复咏唱鱼儿的嬉戏，形成回环往复的节奏感。这种重章叠句的手法源于民歌传统，既增强了音乐性，又渲染了鱼儿自由活泼的动态美。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '全景', content: '江南莲塘，莲叶茂密', keywords: ['采莲', '田田'] },
          { level: '中景', content: '鱼儿在莲叶间嬉戏', keywords: ['鱼戏', '莲叶间'] },
          { level: '动态', content: '东西南北鱼儿穿梭', keywords: ['东西南北', '戏'] },
        ],
      },
    },
    stats: { charCount: 35, sentenceCount: 7, rhymeCount: 0 },
  },
  {
    id: 'p_007',
    title: '咏鹅',
    author: '骆宾王',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '一年级' },
    genre: { category: '诗', subGenre: '古体诗' },
    themes: ['咏物'],
    text: {
      original: '鹅，鹅，鹅，曲项向天歌。白毛浮绿水，红掌拨清波。',
      sentences: ['鹅，鹅，鹅', '曲项向天歌', '白毛浮绿水', '红掌拨清波'],
      rhymeScheme: ['歌', '波'],
    },
    annotations: [
      { term: '曲项', note: '弯着脖子。项，脖子。' },
      { term: '拨', note: '划动。' },
      { term: '向天歌', note: '朝着天空鸣叫。歌，鸣叫。' },
      { term: '红掌', note: '红色的脚掌，指鹅的蹼。' },

      { term: '拨清波', note: '划动清澈的水波。拨，划动。' }
    ],
    translation: '鹅，鹅，鹅，弯着脖子朝天唱歌。雪白的羽毛漂浮在碧绿的水面上，红色的脚掌划着清清的水波。',
    literaryInfo: {
      authorBio: '骆宾王（约619年—约687年），字观光，唐代诗人，与王勃、杨炯、卢照邻合称"初唐四杰"。',
      background: '相传此诗作于骆宾王七岁时，是儿童即兴咏物之作。',
      significance: `此诗生动形象地描绘了鹅的形态和动作，色彩鲜明。"曲项向天歌"写出鹅鸣叫时的姿态，"白毛浮绿水，红掌拨清波"以白、绿、红三色构成鲜明画面，视觉与动态结合，既有浮水的静谧，又有拨波的灵动。全诗由声到形、由静到动，层次分明，是儿童学习古诗的入门之作，也展现了少年骆宾王过人的观察力和表达力。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '形态', content: '曲项向天歌的白鹅', keywords: ['曲项', '向天歌'] },
          { level: '色彩', content: '白毛浮绿水', keywords: ['白毛', '绿水'] },
          { level: '动作', content: '红掌拨清波', keywords: ['红掌', '清波'] },
        ],
      },
    },
    stats: { charCount: 18, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_008',
    title: '村居',
    author: '高鼎',
    dynasty: '清',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['田园', '节日'],
    text: {
      original: '草长莺飞二月天，拂堤杨柳醉春烟。儿童散学归来早，忙趁东风放纸鸢。',
      sentences: ['草长莺飞二月天', '拂堤杨柳醉春烟', '儿童散学归来早', '忙趁东风放纸鸢'],
      rhymeScheme: ['天', '烟', '鸢'],
    },
    annotations: [
      { term: '拂堤', note: '轻轻擦着堤岸。' },
      { term: '春烟', note: '春天里如烟般的雾气。' },
      { term: '纸鸢', note: '风筝。鸢，老鹰类的鸟。' },
      { term: '散学', note: '放学。' },
      { term: '醉', note: '迷醉，沉醉。此处用拟人手法写杨柳仿佛醉于春光。' },

    ],
    translation: '农历二月，小草生长，黄莺飞舞，杨柳轻拂堤岸，仿佛沉醉在春天的烟雾之中。村里的孩子们放学回来得很早，急忙趁着东风放起了风筝。',
    literaryInfo: {
      authorBio: '高鼎，清代后期诗人，字象一，一字拙吾，仁和（今浙江杭州）人。',
      background: '此诗描写了清代农村春天的景象，充满生机与童趣。',
      significance: `全诗以轻快的笔调描绘了春日村居的景象。"草长莺飞二月天"以简洁四字概括春日特征，"拂堤杨柳醉春烟"中"醉"字用拟人手法，写杨柳似醉非醉地垂拂堤岸。后两句转入写人，儿童散学归来放风筝的场景充满生活气息和童趣。"忙趁"二字写出了孩子们的急切与欢欣，与前面的春景相映成趣，构成一幅生机盎然的春日村居图。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '草长莺飞的春日天空', keywords: ['草长', '莺飞'] },
          { level: '中景', content: '杨柳拂堤，春烟朦胧', keywords: ['杨柳', '春烟'] },
          { level: '近景', content: '儿童放风筝', keywords: ['儿童', '纸鸢'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_009',
    title: '所见',
    author: '袁枚',
    dynasty: '清',
    gradeLevel: { stage: '小学', grade: '一年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['田园', '咏物'],
    text: {
      original: '牧童骑黄牛，歌声振林樾。意欲捕鸣蝉，忽然闭口立。',
      sentences: ['牧童骑黄牛', '歌声振林樾', '意欲捕鸣蝉', '忽然闭口立'],
      rhymeScheme: ['樾', '立'],
    },
    annotations: [
      { term: '林樾', note: '树林。樾，树阴。' },
      { term: '意欲', note: '心想，打算。' },
      { term: '振', note: '振荡，回荡。形容歌声嘹亮。' },
      { term: '鸣蝉', note: '鸣叫的知了。' },

      { term: '闭口立', note: '闭上嘴巴站立不动。形容专心致志。' }
    ],
    translation: '牧童骑在黄牛背上，嘹亮的歌声在林中回荡。忽然想要捕捉鸣叫的知了，马上停止唱歌，一声不响地站立着。',
    literaryInfo: {
      authorBio: '袁枚（1716年—1797年），字子才，号简斋，清代诗人、散文家、文学批评家。',
      background: '诗人在乡间看到牧童捕蝉的情景，即兴赋诗。',
      significance: `此诗捕捉了一个生动的瞬间，从动到静的转换极为自然。"骑黄牛"与"歌声振林樾"写牧童的活泼自在，"意欲捕鸣蝉"是心理转折，"忽然闭口立"由动转静，刻画出牧童发现蝉后屏息凝神的样子。全诗二十字，前半写动，后半写静，一动一静之间充满童趣与画面感，充分体现了袁枚"性灵说"的创作主张。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '牧童骑牛高歌，忽见蝉鸣，遂闭口静立欲捕之。',
        timeline: [
          { event: '牧童骑牛', order: 1 },
          { event: '歌声振林樾', order: 2 },
          { event: '发现鸣蝉', order: 3 },
          { event: '闭口静立', order: 4 },
          { event: '欲捕鸣蝉', order: 5 },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_010',
    title: '小池',
    author: '杨万里',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '一年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '咏物'],
    text: {
      original: '泉眼无声惜细流，树阴照水爱晴柔。小荷才露尖尖角，早有蜻蜓立上头。',
      sentences: ['泉眼无声惜细流', '树阴照水爱晴柔', '小荷才露尖尖角', '早有蜻蜓立上头'],
      rhymeScheme: ['流', '柔', '头'],
    },
    annotations: [
      { term: '泉眼', note: '泉水的出口。' },
      { term: '惜', note: '吝惜，珍惜。拟人手法，写泉眼仿佛舍不得水流走。' },
      { term: '晴柔', note: '晴天里柔和的风光。' },
      { term: '尖尖角', note: '初生荷叶的尖端。' },
      { term: '爱', note: '喜爱。拟人手法，写树阴仿佛喜爱水面的晴柔风光。' },

      { term: '上头', note: '上面。指荷叶尖上。' }
    ],
    translation: '泉眼悄然无声，似乎在珍惜细细的水流；树阴映照在水面上，仿佛在爱恋晴天柔和的风光。小小的荷叶才刚刚露出尖尖的角，早已有蜻蜓停立在上面。',
    literaryInfo: {
      authorBio: '杨万里（1127年—1206年），字廷秀，号诚斋，南宋诗人，"南宋四家"之一。',
      background: '此诗作于初夏时节，诗人在小池边观察自然景物而作。',
      significance: `"小荷才露尖尖角，早有蜻蜓立上头"是千古名句。全诗妙在拟人，"惜"与"爱"赋予泉眼和树阴以人的情感，使自然景物充满温情。"才露"与"早有"形成时间的紧凑衔接，表现出蜻蜓对小荷的亲近，也暗含对新生事物的敏锐发现。全诗从泉眼到细流，从树阴到水面，从荷叶到蜻蜓，由大到小，由远及近，层次分明，意境清新。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '水源', content: '泉眼细流', keywords: ['泉眼', '细流'] },
          { level: '水边', content: '树阴映水', keywords: ['树阴', '晴柔'] },
          { level: '水面', content: '小荷与蜻蜓', keywords: ['小荷', '蜻蜓'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_011',
    title: '画',
    author: '佚名',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '一年级' },
    genre: { category: '诗', subGenre: '古体诗' },
    themes: ['咏物', '哲理'],
    text: {
      original: '远看山有色，近听水无声。春去花还在，人来鸟不惊。',
      sentences: ['远看山有色', '近听水无声', '春去花还在', '人来鸟不惊'],
      rhymeScheme: ['声', '惊'],
    },
    annotations: [
      { term: '色', note: '颜色，此处指山的色彩。' },
      { term: '无声', note: '没有声音。' },
      { term: '惊', note: '受惊，害怕。' },
      { term: '远看山有色', note: '远看山有颜色，真山远看则色淡，此句暗示画中山色鲜明如近。' },
      { term: '春去花还在', note: '春天过去了花仍然开，真花则春去花落，此句暗示画中之花不会凋谢。' },

      { term: '去来', note: '走来走去，指人经过。画中花不会因为人来人往而惊飞鸟儿。' }
    ],
    translation: '在远处可以看清山有青翠的颜色，在近处却听不到水流的声音。春天过去了，但花儿依然开放，人走近了，鸟儿却不会被惊飞。',
    literaryInfo: {
      authorBio: '佚名，此诗作者不详，相传为唐代诗人王维所作，但无确证。',
      background: '此诗为一首画赞，描写的是一幅山水花鸟画，以画中景与真景的对比来赞美画作之妙。',
      significance: `全诗以虚实对比的手法，句句写画却不见画字，巧妙地表现了画作的逼真传神。每句都包含一个矛盾：远看应有色却近听无声，春去花应凋却还在，人来鸟应惊却不惊。这些矛盾正是画与真景的区别，也是画之美所在。全诗以反常合道的手法，将画的特质表现得淋漓尽致，是儿童启蒙的经典诗作。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '远处青翠的山峦', keywords: ['远看', '山有色'] },
          { level: '中景', content: '无声的流水', keywords: ['近听', '水无声'] },
          { level: '近景', content: '不谢的花和不惊的鸟', keywords: ['花还在', '鸟不惊'] },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_012',
    title: '古朗月行（节选）',
    author: '李白',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '一年级' },
    genre: { category: '诗', subGenre: '古体诗' },
    themes: ['咏物', '人生'],
    text: {
      original: '小时不识月，呼作白玉盘。又疑瑶台镜，飞在青云端。',
      sentences: ['小时不识月', '呼作白玉盘', '又疑瑶台镜', '飞在青云端'],
      rhymeScheme: ['盘', '端'],
    },
    annotations: [
      { term: '呼作', note: '叫做，称为。' },
      { term: '白玉盘', note: '白玉做成的盘子，此处比喻月亮。' },
      { term: '瑶台', note: '传说中神仙居住的地方。' },
      { term: '青云', note: '高空中的云。' },
      { term: '疑', note: '怀疑，以为。此处是天真想象。' },

      { term: '飞镜', note: '飞升的明镜，比喻月亮。' }
    ],
    translation: '小时候不认识月亮，把它叫做白玉盘。又怀疑是瑶台上的仙镜，飞到了高高的云端。',
    literaryInfo: {
      authorBio: '李白（701年—762年），字太白，号青莲居士，唐代伟大的浪漫主义诗人，被后人誉为"诗仙"。',
      background: '此诗原为长诗，课文节选前四句，描写儿童对月亮的天真想象。',
      significance: `节选部分以儿童的视角描绘月亮，想象丰富，天真烂漫。"呼作白玉盘"以日常器物比喻月亮，质朴而传神；"又疑瑶台镜"由生活想象升华为神话想象，由人间到天上，想象力层层递进。"飞在青云端"一个"飞"字，将静态的月亮赋予了动态之美。全诗从"不识"到"呼作"再到"疑"，真实再现了儿童认知的心理过程，也体现了李白诗歌的浪漫气质。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '小时不识月', emotion: '天真', intensity: 5 },
          { segment: '呼作白玉盘', emotion: '好奇', intensity: 6 },
          { segment: '又疑瑶台镜', emotion: '想象', intensity: 7 },
          { segment: '飞在青云端', emotion: '惊叹', intensity: 8 },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_013',
    title: '风',
    author: '李峤',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '一年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['咏物'],
    text: {
      original: '解落三秋叶，能开二月花。过江千尺浪，入竹万竿斜。',
      sentences: ['解落三秋叶', '能开二月花', '过江千尺浪', '入竹万竿斜'],
      rhymeScheme: ['花', '斜'],
    },
    annotations: [
      { term: '解落', note: '能够吹落。解，能够。' },
      { term: '三秋', note: '深秋，秋季的第三个月。' },
      { term: '二月', note: '早春二月。' },
      { term: '斜', note: '倾斜。' },
      { term: '千尺浪', note: '夸张手法，形容风在江面上掀起的巨浪。' },

      { term: '三秋叶', note: '秋天的树叶。三秋，秋季三个月。' },
      { term: '过江千尺浪', note: '刮过江面能掀起千尺巨浪。' }
    ],
    translation: '可以吹落秋天的树叶，可以催开春天的花朵。刮过江面能掀起千尺巨浪，吹进竹林能使万竿竹子倾斜。',
    literaryInfo: {
      authorBio: '李峤（644年—713年），字巨山，唐代诗人，与苏味道、崔融、杜审言并称"文章四友"。',
      background: '此诗为咏风之作，全诗不着一个风字，却句句写风。',
      significance: `此诗构思巧妙，全诗不着一个风字，却句句写风。四句分别描写风在秋、春、江、竹四种场景中的表现：落秋叶、开春花、掀巨浪、斜万竿，从季节到地域，从植物到水面，展现风的不同面貌。"三秋"与"二月"对举，"千尺"与"万竿"对举，对仗工整，气势雄浑。这种以效果写本体的手法，是咏物诗中的上乘之作。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '秋景', content: '秋叶飘落', keywords: ['三秋叶', '解落'] },
          { level: '春景', content: '春花绽放', keywords: ['二月花', '能开'] },
          { level: '江景', content: '江上巨浪', keywords: ['千尺浪', '过江'] },
          { level: '竹林', content: '竹子倾斜', keywords: ['万竿斜', '入竹'] },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_014',
    title: '赠汪伦',
    author: '李白',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '一年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['友情', '送别'],
    text: {
      original: '李白乘舟将欲行，忽闻岸上踏歌声。桃花潭水深千尺，不及汪伦送我情。',
      sentences: ['李白乘舟将欲行', '忽闻岸上踏歌声', '桃花潭水深千尺', '不及汪伦送我情'],
      rhymeScheme: ['行', '声', '情'],
    },
    annotations: [
      { term: '将欲行', note: '将要离开。' },
      { term: '踏歌', note: '一边唱歌一边用脚踏地打拍子。' },
      { term: '桃花潭', note: '在今安徽省泾县。' },
      { term: '不及', note: '比不上。' },
      { term: '忽闻', note: '忽然听到。' },

      { term: '深千尺', note: '有千尺之深。形容桃花潭水很深，夸张手法。' },
      { term: '汪伦', note: '李白的朋友，泾县桃花潭的村民。' }
    ],
    translation: '李白坐上小船正要出发，忽然听到岸上传来踏着节拍唱歌的声音。即使桃花潭水有千尺之深，也比不上汪伦送我的深厚情谊。',
    literaryInfo: {
      authorBio: '李白（701年—762年），字太白，号青莲居士，唐代伟大的浪漫主义诗人，被后人誉为"诗仙"。',
      background: '李白游泾县桃花潭时，当地人汪伦常以美酒招待，临别时汪伦踏歌相送，李白深受感动而作此诗。',
      significance: `此诗以潭水之深比喻友情之深。"忽闻岸上踏歌声"以"忽"字写出意外之喜，汪伦不期而至的送别令人动容。"桃花潭水深千尺，不及汪伦送我情"以有形的潭水之深衬托无形的情谊之深，化虚为实，使抽象的情感变得可感可量。全诗由叙事到抒情，转折自然，真挚感人，"不及"二字将情与景的对比推向极致。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '李白乘舟将欲行', emotion: '平静', intensity: 3 },
          { segment: '忽闻岸上踏歌声', emotion: '惊喜', intensity: 7 },
          { segment: '桃花潭水深千尺', emotion: '感叹', intensity: 8 },
          { segment: '不及汪伦送我情', emotion: '感动', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_015',
    title: '寻隐者不遇',
    author: '贾岛',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '一年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '人生'],
    text: {
      original: '松下问童子，言师采药去。只在此山中，云深不知处。',
      sentences: ['松下问童子', '言师采药去', '只在此山中', '云深不知处'],
      rhymeScheme: ['去', '处'],
    },
    annotations: [
      { term: '隐者', note: '隐居山林的人，此处指诗人寻访的友人。' },
      { term: '童子', note: '小孩，此处指隐者的徒弟。' },
      { term: '言', note: '说。' },
      { term: '云深', note: '云雾浓密。' },
      { term: '不知处', note: '不知道在哪里。处，所在的地方。' },

      { term: '松下', note: '松树下面。松树象征高洁。' },
      { term: '言师', note: '说师父。言，说。' },
    ],
    translation: '松树下询问隐者的徒弟，他说师傅采药去了。他就在这座大山之中，可是云雾浓密，不知究竟在什么地方。',
    literaryInfo: {
      authorBio: '贾岛（779年—843年），字浪仙，唐代诗人，以苦吟著称，有"诗奴"之称。',
      background: '诗人前往山中寻访隐者友人，却未能相遇，于是写下这首诗。',
      significance: `此诗以问答形式写寻访不遇，语言简洁却意境深远。前三句以松下问答叙事，从"问"到"言"再到"只在此山中"，三问三答，信息逐层递进又渐趋模糊。"云深不知处"以景结情，云雾遮蔽的山中，隐者踪迹难寻，恰与隐者的超然出尘相映照。全诗寓问于答，以不遇写遇，虽未见其人，却通过云雾深山的意境传达出隐者的高逸风神。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '近景', content: '松下问童子', keywords: ['松下', '童子'] },
          { level: '中景', content: '山中采药', keywords: ['采药', '此山'] },
          { level: '远景', content: '云雾深山', keywords: ['云深', '不知处'] },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_016',
    title: '池上',
    author: '白居易',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '一年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['田园', '咏物'],
    text: {
      original: '小娃撑小艇，偷采白莲回。不解藏踪迹，浮萍一道开。',
      sentences: ['小娃撑小艇', '偷采白莲回', '不解藏踪迹', '浮萍一道开'],
      rhymeScheme: ['回', '开'],
    },
    annotations: [
      { term: '小艇', note: '小船。' },
      { term: '不解', note: '不懂得，不明白。' },
      { term: '踪迹', note: '行动留下的痕迹。' },
      { term: '浮萍', note: '水生植物，漂浮在水面上。' },
      { term: '偷采', note: '偷偷地采摘，表现儿童的天真顽皮。' },

      { term: '撑', note: '划，撑船。' },
      { term: '不解藏踪迹', note: '不懂得隐藏自己的行踪。解，懂得。' },
      { term: '浮萍一道开', note: '浮萍被小船划开了一道痕迹。' }
    ],
    translation: '一个小孩撑着小船，偷偷地采了白莲回来。他不懂得隐藏自己的踪迹，小船划过，浮萍上留下了一道长长的痕迹。',
    literaryInfo: {
      authorBio: '白居易（772年—846年），字乐天，号香山居士，唐代伟大的现实主义诗人。',
      background: '此诗描绘了一个天真可爱的儿童偷采白莲的情景，富有生活情趣。',
      significance: `全诗刻画了一个天真调皮的儿童形象。"偷采白莲回"一个"偷"字写出了孩子的顽皮可爱；"不解藏踪迹"最为传神，孩子自以为做得巧妙，却不知浮萍被船划开暴露了行踪，童趣盎然。"浮萍一道开"以画面收束，既是写实的细节，又暗含善意的调侃，把儿童的幼稚可爱表现得淋漓尽致。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '小娃撑船偷采白莲，不懂得隐藏踪迹，浮萍被船划开一道痕迹。',
        timeline: [
          { event: '小娃撑小艇', order: 1 },
          { event: '偷采白莲', order: 2 },
          { event: '不知藏踪迹', order: 3 },
          { event: '浮萍一道开', order: 4 },
          { event: '踪迹败露', order: 5 },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_017',
    title: '画鸡',
    author: '唐寅',
    dynasty: '明',
    gradeLevel: { stage: '小学', grade: '一年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['咏物'],
    text: {
      original: '头上红冠不用裁，满身雪白走将来。平生不敢轻言语，一叫千门万户开。',
      sentences: ['头上红冠不用裁', '满身雪白走将来', '平生不敢轻言语', '一叫千门万户开'],
      rhymeScheme: ['裁', '来', '开'],
    },
    annotations: [
      { term: '红冠', note: '红色的鸡冠。' },
      { term: '不用裁', note: '不用剪裁，天生如此。' },
      { term: '走将来', note: '走过来。将，助词。' },
      { term: '轻言语', note: '轻易开口说话。' },
      { term: '千门万户', note: '形容人家众多，夸张手法写出鸡鸣的影响力。' },

      { term: '裁', note: '剪裁。比喻好似用剪刀裁出。' },
      { term: '似', note: '好像，如同。' }
    ],
    translation: '头上的红色鸡冠不用剪裁，天生就是那样美丽，满身雪白的羽毛走了过来。它平素不敢轻易开口啼叫，一旦叫起来，千家万户的门都会打开。',
    literaryInfo: {
      authorBio: '唐寅（1470年—1524年），字伯虎，号六如居士，明代著名画家、诗人，"吴中四才子"之一。',
      background: '此诗为唐寅题画之作，画中一只大公鸡，诗人借画抒发情怀。',
      significance: `全诗以鸡喻人，表面写鸡的威严，实则暗喻有才能的人平时低调，一旦发声便有惊天动地的影响力。前两句写形——红冠白羽，色彩鲜明，英姿勃发；后两句写神——"不敢"与"一叫"形成对比，由沉默到爆发的转折，暗含"不鸣则已，一鸣惊人"的深意。全诗托物言志，寄托了诗人胸怀壮志、不甘平庸的豪情。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '一只红冠白羽的大公鸡，平时沉默，一叫便唤醒千家万户。',
        timeline: [
          { event: '红冠天生', order: 1 },
          { event: '白羽走来', order: 2 },
          { event: '平时沉默', order: 3 },
          { event: '一鸣惊人', order: 4 },
          { event: '万户开门', order: 5 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  // ===== 二年级上册 =====
  {
    id: 'p_018',
    title: '梅花',
    author: '王安石',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['咏物', '哲理'],
    text: {
      original: '墙角数枝梅，凌寒独自开。遥知不是雪，为有暗香来。',
      sentences: ['墙角数枝梅', '凌寒独自开', '遥知不是雪', '为有暗香来'],
      rhymeScheme: ['梅', '开', '来'],
    },
    annotations: [
      { term: '凌寒', note: '冒着严寒。' },
      { term: '遥知', note: '远远地就知道。' },
      { term: '为', note: '因为。' },
      { term: '暗香', note: '清幽的香气。' },
      { term: '独自开', note: '独自开放，表现梅花不随众芳的品格。' },

    ],
    translation: '墙角有几枝梅花，冒着严寒独自开放。远远看去知道那不是雪，因为有淡淡的清香飘来。',
    literaryInfo: {
      authorBio: '王安石（1021年—1086年），字介甫，号半山，北宋政治家、文学家，"唐宋八大家"之一。',
      background: '此诗写于王安石变法失败后退居江宁时期，借梅花表达坚贞不屈的品格。',
      significance: `此诗以梅喻人，赞美了梅花凌寒独开的品质。"墙角"点明梅花的偏僻处境，"凌寒独自开"突出其不畏严寒、不随流俗的品格。"遥知不是雪，为有暗香来"以梅与雪的形似写梅与雪的神异，梅似雪而胜于雪，胜在暗香。全诗托物言志，借梅花暗喻诗人自己不畏艰难、坚守信念的精神，含蓄而深沉。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '近景', content: '墙角数枝寒梅', keywords: ['墙角', '梅花'] },
          { level: '特征', content: '凌寒独开', keywords: ['凌寒', '独自开'] },
          { level: '感受', content: '暗香浮动', keywords: ['暗香', '不是雪'] },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_019',
    title: '小儿垂钓',
    author: '胡令能',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['田园', '咏物'],
    text: {
      original: '蓬头稚子学垂纶，侧坐莓苔草映身。路人借问遥招手，怕得鱼惊不应人。',
      sentences: ['蓬头稚子学垂纶', '侧坐莓苔草映身', '路人借问遥招手', '怕得鱼惊不应人'],
      rhymeScheme: ['纶', '身', '人'],
    },
    annotations: [
      { term: '蓬头', note: '头发蓬乱。' },
      { term: '稚子', note: '小孩子。' },
      { term: '垂纶', note: '钓鱼。纶，钓鱼用的丝线。' },
      { term: '莓苔', note: '莓草和青苔。' },
      { term: '应人', note: '回应别人。' },

      { term: '不应人', note: '不答应人。形容专心钓鱼。' }
    ],
    translation: '一个头发蓬乱的小孩子在学习钓鱼，侧身坐在莓苔上，野草遮映着他的身体。有过路的人向他问路，他远远地摆了摆手，生怕惊动了鱼儿，不敢回应别人。',
    literaryInfo: {
      authorBio: '胡令能，唐代诗人，生卒年不详，莆田（今属福建）人，早年曾为修补锅碗的工匠，人称"胡钉铰"。',
      background: '诗人看到乡间小儿专心垂钓的情景，写下了这首生动的儿童诗。',
      significance: `此诗把垂钓小儿的专注和天真刻画得惟妙惟肖。"蓬头稚子"写外貌，"侧坐莓苔草映身"写姿态，环境与人物融为一体。"遥招手"这一动作最为传神——不是不应，而是不敢应，远远地摆手示意，既不想惊鱼又不愿无礼，孩童的机灵与专注跃然纸上。全诗以动作和心理细节取胜，是描写儿童的佳作。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '蓬头小儿学钓鱼，路人问路时远远摆手，怕惊走鱼儿不敢应答。',
        timeline: [
          { event: '蓬头稚子学垂纶', order: 1 },
          { event: '侧坐莓苔', order: 2 },
          { event: '草映身', order: 3 },
          { event: '路人借问', order: 4 },
          { event: '遥招手不应人', order: 5 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_020',
    title: '江雪',
    author: '柳宗元',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '人生'],
    text: {
      original: '千山鸟飞绝，万径人踪灭。孤舟蓑笠翁，独钓寒江雪。',
      sentences: ['千山鸟飞绝', '万径人踪灭', '孤舟蓑笠翁', '独钓寒江雪'],
      rhymeScheme: ['绝', '灭', '雪'],
    },
    annotations: [
      { term: '绝', note: '消失，断绝。' },
      { term: '万径', note: '无数的道路。' },
      { term: '踪灭', note: '踪迹消失。' },
      { term: '蓑笠翁', note: '披蓑衣戴斗笠的老翁。' },
      { term: '孤舟', note: '孤零零的小船。' },

      { term: '径', note: '小路。' },
      { term: '独钓', note: '独自垂钓。独，孤独一人。' }
    ],
    translation: '千座山峰上鸟的踪影已经消失，万条小路上也看不到人的足迹。只有一叶孤舟上一位披蓑戴笠的老翁，独自在漫天风雪中垂钓。',
    literaryInfo: {
      authorBio: '柳宗元（773年—819年），字子厚，唐代文学家、哲学家，"唐宋八大家"之一。',
      background: '此诗作于柳宗元被贬永州期间，借寒江独钓的渔翁形象表达自己的孤独与坚贞。',
      significance: `全诗以极度的空旷寂静衬托渔翁的孤独身影。前两句以"千山""万径"的广阔背景与"鸟飞绝""人踪灭"的绝对空无形成巨大的张力，营造出天地间唯余冰雪的苍茫意境。"孤舟蓑笠翁"在空旷中出现，孤独却坚定；"独钓寒江雪"以"独"字点明渔翁的不屈姿态。全诗以冷峻的画面寄托了诗人被贬后坚守节操、不与世俗同流的精神。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '千山无鸟，万径无人', keywords: ['千山', '万径'] },
          { level: '中景', content: '孤舟漂于寒江', keywords: ['孤舟', '寒江'] },
          { level: '近景', content: '蓑笠翁独钓', keywords: ['蓑笠翁', '独钓'] },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_021',
    title: '夜宿山寺',
    author: '李白',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水'],
    text: {
      original: '危楼高百尺，手可摘星辰。不敢高声语，恐惊天上人。',
      sentences: ['危楼高百尺', '手可摘星辰', '不敢高声语', '恐惊天上人'],
      rhymeScheme: ['辰', '人'],
    },
    annotations: [
      { term: '危楼', note: '高楼。危，高。' },
      { term: '百尺', note: '虚数，形容极高。' },
      { term: '星辰', note: '星星的总称。' },
      { term: '天上人', note: '天上的神仙。' },
      { term: '恐', note: '恐怕，担心。' },

      { term: '语', note: '说话，出声。恐惊，恐怕惊动。' }
    ],
    translation: '山上寺院的高楼多么高啊，似乎一伸手就可以摘下天上的星星。不敢大声说话，恐怕惊动了天上的仙人。',
    literaryInfo: {
      authorBio: '李白（701年—762年），字太白，号青莲居士，唐代伟大的浪漫主义诗人，被后人誉为"诗仙"。',
      background: '此诗作于李白夜宿山寺时，以夸张的手法描写寺楼之高。',
      significance: `全诗运用大胆的想象和夸张。"危楼高百尺"以虚数极力渲染楼之高，"手可摘星辰"以不可能的动作进一步夸张，仿佛伸手可及星空。后两句由想象转入心理——"不敢高声语，恐惊天上人"，用不敢出声的敬畏来反衬楼之高，比直接写高更加传神。全诗从实写到虚写，从视觉到心理，将楼高写得淋漓尽致，体现了李白诗歌的浪漫主义特色。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '高耸入云的楼阁', keywords: ['危楼', '百尺'] },
          { level: '中景', content: '伸手可及的星辰', keywords: ['摘星辰'] },
          { level: '近景', content: '低声细语的人', keywords: ['不敢高声语', '天上人'] },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_022',
    title: '敕勒歌',
    author: '北朝民歌',
    dynasty: '魏晋南北朝',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '古体诗' },
    themes: ['山水', '田园'],
    text: {
      original: '敕勒川，阴山下。天似穹庐，笼盖四野。天苍苍，野茫茫，风吹草低见牛羊。',
      sentences: ['敕勒川，阴山下', '天似穹庐', '笼盖四野', '天苍苍', '野茫茫', '风吹草低见牛羊'],
      rhymeScheme: ['下', '野', '羊'],
    },
    annotations: [
      { term: '敕勒川', note: '敕勒族居住的平原，在今内蒙古一带。' },
      { term: '穹庐', note: '游牧民族居住的圆顶毡帐，即蒙古包。' },
      { term: '苍苍', note: '深蓝色。' },
      { term: '见', note: `同"现"，显露。古今异义。` },
      { term: '茫茫', note: '辽阔无边的样子。' },

      { term: '阴山下', note: '阴山脚下。阴山，山脉名，在内蒙古。' },
    ],
    translation: '敕勒族居住的大平原，就在阴山脚下。天空像一顶巨大的圆顶毡帐，笼罩着四面的原野。天空蓝蓝的，原野辽阔无边，风吹来草低伏，露出了成群的牛羊。',
    literaryInfo: {
      authorBio: '北朝民歌，南北朝时期北方民族的民间歌谣，作者不详。',
      background: '此歌约产生于北魏时期，是敕勒族人的民歌，描绘了北方草原的壮丽景色。',
      significance: `此歌气势雄浑，以极简的语言描绘了北方草原的壮阔景象。先写大环境——阴山、敕勒川、穹庐般的天空，由远及近；再以"天苍苍，野茫茫"对举，苍天与旷野相接，天地浑然一体；最后"风吹草低见牛羊"是全诗高潮，风吹草动之际牛羊隐现，静态画面顿生动态之美。全诗由静到动、由大到小、由远及近，层次分明，堪称描写草原风光的千古绝唱。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '阴山下的敕勒川', keywords: ['阴山', '敕勒川'] },
          { level: '全景', content: '穹庐般的天空', keywords: ['穹庐', '笼盖'] },
          { level: '近景', content: '风吹草低见牛羊', keywords: ['风吹草低', '牛羊'] },
        ],
      },
    },
    stats: { charCount: 27, sentenceCount: 6, rhymeCount: 3 },
  },
  // ===== 二年级下册 =====
  {
    id: 'p_023',
    title: '咏柳',
    author: '贺知章',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['咏物', '山水'],
    text: {
      original: '碧玉妆成一树高，万条垂下绿丝绦。不知细叶谁裁出，二月春风似剪刀。',
      sentences: ['碧玉妆成一树高', '万条垂下绿丝绦', '不知细叶谁裁出', '二月春风似剪刀'],
      rhymeScheme: ['高', '绦', '刀'],
    },
    annotations: [
      { term: '碧玉', note: '绿色的玉，此处比喻柳树嫩绿的颜色。' },
      { term: '妆成', note: '装饰，打扮。' },
      { term: '丝绦', note: '丝带。' },
      { term: '裁', note: '裁剪。' },
      { term: '绿', note: '碧绿色，此处形容柳叶初生的嫩绿色彩。' },

      { term: '二月春风', note: '早春的春风。二月，农历二月。' }
    ],
    translation: '高高的柳树长满了翠绿的新叶，像是用碧玉装扮而成，千万条下垂的柳枝如同绿色的丝带。不知道这细细的柳叶是谁裁剪出来的，原来是二月的春风就像一把剪刀。',
    literaryInfo: {
      authorBio: '贺知章（659年—744年），字季真，唐代诗人、书法家，自号"四明狂客"。',
      background: '此诗写早春时节柳树的美丽姿态，诗人以巧妙的比喻赞美春风的创造力。',
      significance: `"二月春风似剪刀"是千古名句。全诗三重比喻层层递进：先以碧玉喻柳色，再以丝绦喻柳条，最后以剪刀喻春风。"不知细叶谁裁出"设问，将自然现象拟人化，赋予春风以匠人的巧手。剪刀之喻新颖独特，既写出了柳叶的精致形态，又表现了春风的创造力，化无形的春风为有形的工具，成为描写春天的经典意象。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '整体', content: '碧玉般的柳树', keywords: ['碧玉', '一树高'] },
          { level: '细节', content: '柳条如丝绦', keywords: ['绿丝绦', '万条'] },
          { level: '创意', content: '春风如剪', keywords: ['春风', '剪刀'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_024',
    title: '赋得古原草送别（节选）',
    author: '白居易',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['哲理', '送别'],
    text: {
      original: '离离原上草，一岁一枯荣。野火烧不尽，春风吹又生。',
      sentences: ['离离原上草', '一岁一枯荣', '野火烧不尽', '春风吹又生'],
      rhymeScheme: ['草', '荣', '生'],
    },
    annotations: [
      { term: '离离', note: '青草茂盛的样子。' },
      { term: '一岁', note: '一年。' },
      { term: '枯荣', note: '枯萎和茂盛。' },
      { term: '尽', note: '完，灭尽。' },
      { term: '荣', note: '茂盛，繁荣。' },
      { term: '枯', note: '干枯，枯萎。' },

      { term: '又生', note: '又生长出来。形容小草生命力顽强。' }
    ],
    translation: '原野上长满了茂盛的野草，每年一度枯萎一度繁荣。野火也无法将它烧尽，春风一吹它又重新生长。',
    literaryInfo: {
      authorBio: '白居易（772年—846年），字乐天，号香山居士，唐代伟大的现实主义诗人。',
      background: '此诗为白居易十六岁时作的应考习作，原诗八句，课文节选前四句。相传白居易以此诗谒顾况，顾况叹赏。',
      significance: `"野火烧不尽，春风吹又生"是千古名句。"离离原上草"以叠词写出春草的繁茂，"一岁一枯荣"以极简的语言概括了草的生命周期，枯荣交替中蕴含着生生不息的力量。"野火烧不尽"以野火之猛烈反衬春草之顽强，"春风吹又生"写出生命不可遏制的力量。全诗既描写了小草顽强的生命力，也蕴含了新生事物不可战胜的哲理。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '离离原上草', emotion: '赞叹', intensity: 5 },
          { segment: '一岁一枯荣', emotion: '感慨', intensity: 6 },
          { segment: '野火烧不尽', emotion: '震撼', intensity: 8 },
          { segment: '春风吹又生', emotion: '欣喜', intensity: 9 },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_025',
    title: '晓出净慈寺送林子方',
    author: '杨万里',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '送别'],
    text: {
      original: '毕竟西湖六月中，风光不与四时同。接天莲叶无穷碧，映日荷花别样红。',
      sentences: ['毕竟西湖六月中', '风光不与四时同', '接天莲叶无穷碧', '映日荷花别样红'],
      rhymeScheme: ['中', '同', '红'],
    },
    annotations: [
      { term: '毕竟', note: '到底，终究。' },
      { term: '四时', note: '四季，此处指其他季节。' },
      { term: '无穷碧', note: '一片无边无际的碧绿。' },
      { term: '别样红', note: '红得特别出色，不同寻常。' },
      { term: '净慈寺', note: '杭州西湖边的一座佛寺。' },

      { term: '接天', note: '与天相连。形容荷花面积广阔。' }
    ],
    translation: '到底是西湖的六月时节，风光与其他季节截然不同。碧绿的莲叶铺满湖面，一望无际，仿佛与天相接，阳光映照下的荷花格外鲜艳红润。',
    literaryInfo: {
      authorBio: '杨万里（1127年—1206年），字廷秀，号诚斋，南宋诗人，"南宋四家"之一。',
      background: '此诗为诗人清晨从净慈寺出来送别友人林子方时所作，借西湖美景表达惜别之情。',
      significance: `"接天莲叶无穷碧，映日荷花别样红"是描写荷花的千古名句。"毕竟西湖六月中"以"毕竟"二字起笔，语气坚定，断言此时风光与众不同。"接天莲叶"写莲叶之广，碧绿的荷叶与天相接，无边无际；"映日荷花"写荷花之艳，朝阳映照下的红莲格外鲜丽。碧与红对比，天与日相映，色彩浓烈而又和谐，成为描写西湖荷花的千古绝唱。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '全景', content: '六月的西湖', keywords: ['西湖', '六月'] },
          { level: '中景', content: '无穷碧的莲叶', keywords: ['莲叶', '无穷碧'] },
          { level: '近景', content: '映日红荷花', keywords: ['映日', '别样红'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_026',
    title: '绝句',
    author: '杜甫',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '咏物'],
    text: {
      original: '两个黄鹂鸣翠柳，一行白鹭上青天。窗含西岭千秋雪，门泊东吴万里船。',
      sentences: ['两个黄鹂鸣翠柳', '一行白鹭上青天', '窗含西岭千秋雪', '门泊东吴万里船'],
      rhymeScheme: ['天', '船'],
    },
    annotations: [
      { term: '黄鹂', note: '一种鸟，羽毛黄色，叫声悦耳。' },
      { term: '白鹭', note: '一种水鸟，羽毛白色。' },
      { term: '窗含', note: '从窗户望去，景色像嵌在窗框中。含，镶嵌。' },
      { term: '西岭', note: '成都西边的岷山。' },
      { term: '泊', note: '停泊。' },
      { term: '东吴', note: '古代指长江下游一带。' },

      { term: '鸣翠柳', note: '在翠绿的柳枝上鸣叫。' },
      { term: '含西岭', note: '窗口对着西岭，仿佛含着雪山景色。含，镶嵌。' },
    ],
    translation: '两只黄鹂在翠绿的柳枝间鸣叫，一行白鹭直冲向蔚蓝的天空。从窗户望去可以看见西边山岭上终年不化的积雪，门前停泊着从东吴远航而来的船只。',
    literaryInfo: {
      authorBio: '杜甫（712年—770年），字子美，自号少陵野老，唐代伟大的现实主义诗人，被后人誉为"诗圣"。',
      background: '此诗作于杜甫寓居成都草堂时期，春日晴好，诗人心情愉悦而作。',
      significance: `此诗四句写了四幅画面，色彩鲜明，动静结合，远近交错。前两句写近景——黄鹂鸣翠柳、白鹭上青天，色彩明丽，动静相映；后两句写远景——窗含西岭千秋雪、门泊东吴万里船，"含"字以窗框取景，将远山纳入画框；"泊"字以船连接万里时空，千秋对万里，时空交错。全诗由近及远、由小到大、由春到冬，四句四景却浑然一体。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '近景', content: '黄鹂鸣翠柳', keywords: ['黄鹂', '翠柳'] },
          { level: '中景', content: '白鹭上青天', keywords: ['白鹭', '青天'] },
          { level: '远景', content: '西岭千秋雪', keywords: ['西岭', '千秋雪'] },
          { level: '水景', content: '东吴万里船', keywords: ['东吴', '万里船'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_027',
    title: '悯农（其一）',
    author: '李绅',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['人生', '哲理'],
    text: {
      original: '春种一粒粟，秋收万颗子。四海无闲田，农夫犹饿死。',
      sentences: ['春种一粒粟', '秋收万颗子', '四海无闲田', '农夫犹饿死'],
      rhymeScheme: ['子', '死'],
    },
    annotations: [
      { term: '粟', note: '谷子，粮食的统称。' },
      { term: '万颗子', note: '形容收成极多。' },
      { term: '四海', note: '天下，全国。' },
      { term: '犹', note: '还，仍然。' },
      { term: '闲田', note: '空闲的田地，没有耕种的田。' },

      { term: '饿死', note: '因饥饿而死。揭露社会不公。' }
    ],
    translation: '春天种下一粒种子，秋天可以收获万颗粮食。天下没有一块闲置的田地，可种田的农民还是会被饿死。',
    literaryInfo: {
      authorBio: '李绅（772年—846年），字公垂，唐代诗人。其《悯农》诗两首流传极广。',
      background: '此诗与《悯农（其二）》为姊妹篇，诗人以强烈的对比揭露了当时社会的不公。',
      significance: `全诗以"丰收"与"饿死"的强烈对比揭露社会不公。"春种一粒粟，秋收万颗子"以一与万的数字对比写出农业丰收；"四海无闲田"强调土地尽被开垦。前三句层层铺垫，似乎在歌颂丰收与勤耕，末句"农夫犹饿死"猝然转折，以丰收之年农民却依然饿死的极端矛盾揭露赋税之重和社会之不公，具有强烈的批判力量。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '春种一粒粟', emotion: '希望', intensity: 4 },
          { segment: '秋收万颗子', emotion: '喜悦', intensity: 6 },
          { segment: '四海无闲田', emotion: '赞叹', intensity: 5 },
          { segment: '农夫犹饿死', emotion: '悲愤', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_028',
    title: '舟夜书所见',
    author: '查慎行',
    dynasty: '清',
    gradeLevel: { stage: '小学', grade: '二年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水'],
    text: {
      original: '月黑见渔灯，孤光一点萤。微微风簇浪，散作满河星。',
      sentences: ['月黑见渔灯', '孤光一点萤', '微微风簇浪', '散作满河星'],
      rhymeScheme: ['萤', '星'],
    },
    annotations: [
      { term: '月黑', note: '没有月亮的夜晚，漆黑一片。' },
      { term: '孤光', note: '孤零零的灯光。' },
      { term: '簇', note: '聚集，此处指风吹起的浪花。' },
      { term: '散作', note: '散开变成。' },
      { term: '萤', note: '萤火虫，此处比喻渔灯的微弱光亮。' },

    ],
    translation: '漆黑的夜晚看不见月亮，只见那渔船上的灯火，像一只萤火虫发出孤零零的光。微风吹来，吹起细细的波浪，渔灯的倒影在水面上散开，仿佛满河的星星。',
    literaryInfo: {
      authorBio: '查慎行（1650年—1727年），字初白，清代诗人，诗学苏轼、陆游，为清代宗宋诗派的代表人物。',
      background: '诗人在夜航船上所见之景，记录了暗夜中渔灯与水面倒影的美妙景象。',
      significance: `此诗以细腻的观察描写夜航所见。"月黑见渔灯"以黑暗中的孤灯起笔，"孤光一点萤"以萤火虫比喻渔灯的微弱。后两句写出动态变化——微风吹起涟漪，灯影在水面上散开，如满天繁星落入河中。从一点微光到满河星光，由静到动，由少到多，以极小的变化写出极美的效果，展现了诗人敏锐的观察力和精微的表现力。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '漆黑无月的夜空', keywords: ['月黑', '渔灯'] },
          { level: '中景', content: '孤灯如萤', keywords: ['孤光', '萤'] },
          { level: '近景', content: '倒影散作满河星', keywords: ['风簇浪', '满河星'] },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  // ===== 三年级上册 =====
  {
    id: 'p_029',
    title: '山行',
    author: '杜牧',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '哲理'],
    text: {
      original: '远上寒山石径斜，白云生处有人家。停车坐爱枫林晚，霜叶红于二月花。',
      sentences: ['远上寒山石径斜', '白云生处有人家', '停车坐爱枫林晚', '霜叶红于二月花'],
      rhymeScheme: ['斜', '家', '花'],
    },
    annotations: [
      { term: '寒山', note: '深秋时节的山。' },
      { term: '石径斜', note: '石头铺成的小路弯弯曲曲。' },
      { term: '坐', note: '因为。' },
      { term: '红于', note: '比……更红。' },
      { term: '霜叶', note: '经霜的枫叶。' },

    ],
    translation: '沿着弯弯曲曲的小路远上深秋的山峦，白云飘生的地方有几户人家。停下车来是因为喜爱枫林的晚景，经霜的红叶比二月的春花还要鲜艳。',
    literaryInfo: {
      authorBio: '杜牧（803年—852年），字牧之，唐代诗人，与李商隐并称"小李杜"。',
      background: '此诗作于诗人深秋山行途中，被山中枫林美景所吸引而作。',
      significance: `"霜叶红于二月花"是千古名句。诗人一反悲秋的传统，赞美秋色胜过春光。"远上寒山石径斜"写山路的曲折，"白云生处有人家"以"生"字写出云雾升腾的动态，有人家则山路不寒。"停车坐爱枫林晚"以"坐"字交代停车的原因——因为喜爱，"晚"字点明夕阳下的枫林更加绚烂。"红于"二字将秋叶与春花对比，以秋胜春，格调高昂。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '寒山石径与白云人家', keywords: ['寒山', '白云'] },
          { level: '中景', content: '枫林如火', keywords: ['枫林', '停车'] },
          { level: '近景', content: '红于春花的霜叶', keywords: ['霜叶', '红于二月花'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_030',
    title: '赠刘景文',
    author: '苏轼',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['咏物', '哲理'],
    text: {
      original: '荷尽已无擎雨盖，菊残犹有傲霜枝。一年好景君须记，最是橙黄橘绿时。',
      sentences: ['荷尽已无擎雨盖', '菊残犹有傲霜枝', '一年好景君须记', '最是橙黄橘绿时'],
      rhymeScheme: ['枝', '时'],
    },
    annotations: [
      { term: '擎雨盖', note: '撑着雨伞一样的荷叶。擎，举。' },
      { term: '傲霜', note: '不怕霜冻。' },
      { term: '君', note: '您，指刘景文。' },
      { term: '橙黄橘绿', note: '指初冬时节橙子金黄、橘子青绿的景象。' },
      { term: '犹', note: '还，仍然。' },

      { term: '傲霜枝', note: '傲然挺立在霜中的花枝。比喻菊花坚强不屈。' }
    ],
    translation: '荷花已经凋谢，再也没有像雨伞一样撑起的荷叶，菊花虽然已经凋残，但仍有不怕霜冻的花枝。一年中最好的景色你必须记住，那就是橙子金黄、橘子青绿的时候。',
    literaryInfo: {
      authorBio: '苏轼（1037年—1101年），字子瞻，号东坡居士，北宋文学家、书画家，"唐宋八大家"之一。',
      background: '此诗作于苏轼知杭州时，赠友人刘景文，以初冬景色勉励友人保持乐观的心态。',
      significance: `此诗一反悲秋伤冬的传统，以"橙黄橘绿"展现初冬的生机。"荷尽已无擎雨盖"写荷花的凋零，"菊残犹有傲霜枝"写菊花的顽强，一衰一荣对比鲜明。后两句笔锋一转，指出初冬并非萧条，"最是橙黄橘绿时"——橙黄橘绿正是丰收的季节。全诗以景喻人，劝勉友人在看似衰落之时仍要保持乐观，发现生活中的美好。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '衰景', content: '荷花凋谢', keywords: ['荷尽', '擎雨盖'] },
          { level: '傲景', content: '菊残傲霜枝', keywords: ['菊残', '傲霜'] },
          { level: '盛景', content: '橙黄橘绿', keywords: ['橙黄', '橘绿'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_031',
    title: '夜书所见',
    author: '叶绍翁',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['思乡', '田园'],
    text: {
      original: '萧萧梧叶送寒声，江上秋风动客情。知有儿童挑促织，夜深篱落一灯明。',
      sentences: ['萧萧梧叶送寒声', '江上秋风动客情', '知有儿童挑促织', '夜深篱落一灯明'],
      rhymeScheme: ['声', '情', '明'],
    },
    annotations: [
      { term: '萧萧', note: '风声，此处指梧桐叶被风吹落的声音。' },
      { term: '动客情', note: '触动了旅客的思乡之情。' },
      { term: '挑促织', note: '捉蟋蟀。促织，蟋蟀。' },
      { term: '篱落', note: '篱笆。' },
      { term: '寒声', note: '寒冷的声音，指秋风带来的寒意。' },

      { term: '挑', note: '拨弄。用针拨灯芯。' },
    ],
    translation: '梧桐树叶萧萧飘落，送来阵阵寒意，江上的秋风吹起了旅客的思乡之情。知道有小孩在捉蟋蟀，夜深了篱笆旁还有一盏灯亮着。',
    literaryInfo: {
      authorBio: '叶绍翁，南宋诗人，字嗣宗，号靖逸，龙泉（今属浙江）人。',
      background: '诗人在秋天客居他乡，夜晚被秋风触动思乡之情，看到儿童捉蟋蟀更添感慨。',
      significance: `此诗以儿童夜捉蟋蟀的欢快反衬诗人的孤独思乡。"萧萧梧叶送寒声"以声写秋，"江上秋风动客情"直写思乡。后两句写儿童挑灯捉蟋蟀，表面是写童趣，实则是以乐景写哀情——儿童的快乐更反衬自己的孤独，远在家乡的儿童是否也在篱边嬉戏？以乐衬哀，更显思乡之深切。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '萧萧梧叶送寒声', emotion: '凄凉', intensity: 6 },
          { segment: '江上秋风动客情', emotion: '思乡', intensity: 8 },
          { segment: '知有儿童挑促织', emotion: '怀念', intensity: 7 },
          { segment: '夜深篱落一灯明', emotion: '孤寂', intensity: 9 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_032',
    title: '望天门山',
    author: '李白',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水'],
    text: {
      original: '天门中断楚江开，碧水东流至此回。两岸青山相对出，孤帆一片日边来。',
      sentences: ['天门中断楚江开', '碧水东流至此回', '两岸青山相对出', '孤帆一片日边来'],
      rhymeScheme: ['开', '回', '来'],
    },
    annotations: [
      { term: '天门', note: '天门山，在今安徽和县与芜湖之间，长江两岸的东梁山与西梁山合称。' },
      { term: '楚江', note: '长江流经古代楚地的一段。' },
      { term: '回', note: '回旋，转弯。' },
      { term: '日边', note: '天边，太阳升起的方向。' },
      { term: '中断', note: '从中间断开，形容天门山被长江隔开。' },

      { term: '帆', note: '船帆。指孤帆一片从天边驶来。' }
    ],
    translation: '天门山被长江从中间断开，碧绿的江水向东流去，在这里转弯回旋。两岸的青山对峙着出现在眼前，一片孤帆从太阳升起的地方驶来。',
    literaryInfo: {
      authorBio: '李白（701年—762年），字太白，号青莲居士，唐代伟大的浪漫主义诗人，被后人誉为"诗仙"。',
      background: '此诗作于李白乘舟东下途经天门山时，被壮丽的山水景色所震撼。',
      significance: `此诗气势雄浑，以雄健的笔力描绘了天门山的壮丽景观。"天门中断楚江开"以山被江水劈开的力量感开篇；"碧水东流至此回"写江水受阻回旋的壮观。"两岸青山相对出"以"出"字赋予青山以动态，仿佛山在迎接来客；"孤帆一片日边来"以孤帆点缀壮阔的画面，大与小相映成趣，意境开阔。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '天门山被楚江隔开', keywords: ['天门', '楚江'] },
          { level: '中景', content: '碧水东流回旋', keywords: ['碧水', '东流'] },
          { level: '近景', content: '两岸青山相对', keywords: ['青山', '相对出'] },
          { level: '动态', content: '孤帆从日边来', keywords: ['孤帆', '日边来'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_033',
    title: '饮湖上初晴后雨',
    author: '苏轼',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水'],
    text: {
      original: '水光潋滟晴方好，山色空蒙雨亦奇。欲把西湖比西子，淡妆浓抹总相宜。',
      sentences: ['水光潋滟晴方好', '山色空蒙雨亦奇', '欲把西湖比西子', '淡妆浓抹总相宜'],
      rhymeScheme: ['奇', '宜'],
    },
    annotations: [
      { term: '潋滟', note: '波光闪动的样子。' },
      { term: '空蒙', note: '云雾迷蒙的样子。' },
      { term: '西子', note: '西施，春秋时期越国的美女。' },
      { term: '相宜', note: '合适，恰当。' },
      { term: '方好', note: '正好，正美。' },

    ],
    translation: '晴天时西湖波光粼粼的样子正好，雨天时山色朦胧也别有奇妙。如果把西湖比作美女西施，无论淡妆还是浓抹都是那样美丽动人。',
    literaryInfo: {
      authorBio: '苏轼（1037年—1101年），字子瞻，号东坡居士，北宋文学家、书画家，"唐宋八大家"之一。',
      background: '此诗作于苏轼任杭州通判期间，先晴后雨的西湖给了诗人灵感。',
      significance: `"欲把西湖比西子，淡妆浓抹总相宜"是赞美西湖的千古名句。前两句分写晴雨之景："水光潋滟"是晴天的波光粼粼，"山色空蒙"是雨天的云雾迷离。后两句以美人西施比喻西湖，晴天如浓妆，雨天如淡妆，无论晴雨都美不胜收。以人喻湖，将西湖之美提升到人格化的高度，构思新颖独特，"西子湖"的别称即源于此诗。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '晴景', content: '波光潋滟的水面', keywords: ['潋滟', '晴方好'] },
          { level: '雨景', content: '空蒙的山色', keywords: ['空蒙', '雨亦奇'] },
          { level: '比喻', content: '西子般的美', keywords: ['西子', '淡妆浓抹'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_034',
    title: '望洞庭',
    author: '刘禹锡',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水'],
    text: {
      original: '湖光秋月两相和，潭面无风镜未磨。遥望洞庭山水翠，白银盘里一青螺。',
      sentences: ['湖光秋月两相和', '潭面无风镜未磨', '遥望洞庭山水翠', '白银盘里一青螺'],
      rhymeScheme: ['磨', '螺'],
    },
    annotations: [
      { term: '相和', note: '互相映衬，和谐交融。' },
      { term: '潭面', note: '湖面。' },
      { term: '镜未磨', note: '未打磨的铜镜，形容水面平静但不完全光滑。' },
      { term: '青螺', note: '青色的螺，此处比喻洞庭湖中的君山。' },
      { term: '白银盘', note: '银白色的盘子，比喻月下洞庭湖面。' },

      { term: '湖光秋月', note: '洞庭湖上的月光。秋月映照湖面。' },
    ],
    translation: '秋夜的湖光与月色交相辉映，湖面风平浪静，如同未打磨的铜镜。远望洞庭湖山青水翠，就像白银盘里放着一枚青青的螺。',
    literaryInfo: {
      authorBio: '刘禹锡（772年—842年），字梦得，唐代诗人、哲学家，有"诗豪"之称。',
      background: '此诗作于刘禹锡赴任途中经过洞庭湖时，月夜远望洞庭湖景而作。',
      significance: `"白银盘里一青螺"是描写洞庭湖的千古名句。前两句以"和"字写湖光与秋月的和谐，以"镜未磨"比喻湖面的朦胧宁静。后两句以白银盘喻湖面，以青螺喻君山，大小对比、色彩映衬，将壮阔的洞庭山水浓缩为精致的艺术品，体现了刘禹锡诗歌的精巧构思和丰富的想象力。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '湖光秋月交融', keywords: ['湖光', '秋月'] },
          { level: '中景', content: '潭面如镜', keywords: ['潭面', '镜未磨'] },
          { level: '近景', content: '白银盘里的青螺', keywords: ['白银盘', '青螺'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_035',
    title: '早发白帝城',
    author: '李白',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '人生'],
    text: {
      original: '朝辞白帝彩云间，千里江陵一日还。两岸猿声啼不住，轻舟已过万重山。',
      sentences: ['朝辞白帝彩云间', '千里江陵一日还', '两岸猿声啼不住', '轻舟已过万重山'],
      rhymeScheme: ['间', '还', '山'],
    },
    annotations: [
      { term: '白帝', note: '白帝城，在今重庆市奉节县。' },
      { term: '彩云间', note: '指白帝城地势很高，好像在云彩之间。' },
      { term: '江陵', note: '今湖北省荆州市。' },
      { term: '万重山', note: '层层叠叠的山。' },
      { term: '轻舟', note: '轻快的小船。' },

      { term: '千里', note: '千里之遥。形容路途遥远，但一日即达，极写船行之快。' },
      { term: '猿声', note: '猿猴的叫声。三峡多猿，啼声凄清。' }
    ],
    translation: '清晨告别了彩云环绕的白帝城，千里之遥的江陵一天就可以到达。两岸猿猴的啼叫声还在耳边回荡，轻快的小船已经穿过了重重叠叠的山峦。',
    literaryInfo: {
      authorBio: '李白（701年—762年），字太白，号青莲居士，唐代伟大的浪漫主义诗人，被后人誉为"诗仙"。',
      background: '此诗作于李白被流放夜郎途中遇赦东归时，心情畅快，船行极速。',
      significance: `此诗以轻快的笔调抒写了遇赦后愉快的心情。"朝辞白帝彩云间"以彩云写出白帝城的高峻，也暗示心情的明朗；"千里江陵一日还"以千里与一日的对比写出船行之快，也暗含归心似箭的畅快。"两岸猿声啼不住"以猿声的不断反衬船行的迅速；"轻舟已过万重山"以"轻"字写船，也写心情的轻快——重山已过，劫难已终。全诗节奏明快，气势如虹，是李白诗歌浪漫气质的集中体现。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '清晨告别白帝城，乘轻舟顺流而下，一日即达千里之外的江陵。',
        timeline: [
          { event: '朝辞白帝彩云间', order: 1 },
          { event: '千里江陵一日还', order: 2 },
          { event: '两岸猿声啼不住', order: 3 },
          { event: '轻舟已过万重山', order: 4 },
          { event: '归心似箭', order: 5 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_036',
    title: '采莲曲',
    author: '王昌龄',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['田园', '咏物'],
    text: {
      original: '荷叶罗裙一色裁，芙蓉向脸两边开。乱入池中看不见，闻歌始觉有人来。',
      sentences: ['荷叶罗裙一色裁', '芙蓉向脸两边开', '乱入池中看不见', '闻歌始觉有人来'],
      rhymeScheme: ['裁', '开', '来'],
    },
    annotations: [
      { term: '罗裙', note: '丝织的裙子。' },
      { term: '芙蓉', note: '荷花。' },
      { term: '乱入', note: '混入，融入。' },
      { term: '始觉', note: '才发觉。' },
      { term: '一色裁', note: '同色裁剪，形容裙子与荷叶颜色相同。' },

    ],
    translation: '采莲少女的绿罗裙与荷叶同色裁就，少女的脸庞与荷花一样娇艳。她们融入池塘中难以分辨，听到歌声才发觉有人来了。',
    literaryInfo: {
      authorBio: '王昌龄（698年—757年），字少伯，唐代诗人，以边塞诗著称，被誉为"七绝圣手"。',
      background: '此诗描写采莲少女的美丽形象，以荷花映衬少女之美的构思极为巧妙。',
      significance: `全诗以荷叶荷花衬托采莲少女，构思奇巧。"荷叶罗裙一色裁"写裙与叶同色，"芙蓉向脸两边开"写脸与花同美，人花交融。"乱入池中看不见"写人花难辨——少女与荷花浑然一体；"闻歌始觉有人来"以歌声揭示人的存在，花丛中方见人影。全诗以视觉的"看不见"与听觉的"闻歌"形成反差，人花合一的意境极为优美。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '色彩', content: '罗裙与荷叶同色', keywords: ['罗裙', '一色裁'] },
          { level: '面容', content: '芙蓉向脸', keywords: ['芙蓉', '两边开'] },
          { level: '动态', content: '闻歌方知人来', keywords: ['闻歌', '有人来'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  // ===== 三年级下册 =====
  {
    id: 'p_037',
    title: '绝句',
    author: '杜甫',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '咏物'],
    text: {
      original: '迟日江山丽，春风花草香。泥融飞燕子，沙暖睡鸳鸯。',
      sentences: ['迟日江山丽', '春风花草香', '泥融飞燕子', '沙暖睡鸳鸯'],
      rhymeScheme: ['丽', '香', '鸯'],
    },
    annotations: [
      { term: '迟日', note: '春日，春天日渐长，故称迟日。' },
      { term: '泥融', note: '泥土湿润柔软。' },
      { term: '鸳鸯', note: '一种水鸟，常成对出现，比喻恩爱夫妻。' },
      { term: '丽', note: '秀丽，美丽。' },

      { term: '沙暖', note: '沙滩被太阳晒暖。' }
    ],
    translation: '春天的太阳使得江山格外秀丽，春风送来花草的芬芳。泥土融化燕子飞来飞去衔泥筑巢，暖和的沙子上睡着成双成对的鸳鸯。',
    literaryInfo: {
      authorBio: '杜甫（712年—770年），字子美，自号少陵野老，唐代伟大的现实主义诗人，被后人誉为"诗圣"。',
      background: '此诗作于成都草堂，安史之乱后杜甫回到草堂，面对春日美景心情舒畅。',
      significance: `全诗四句四景，有声有色，动静结合。"迟日江山丽"总写春日之美，"春风花草香"以嗅觉丰富感受。"泥融飞燕子"写燕衔泥筑巢的忙碌，"沙暖睡鸳鸯"写鸳鸯在暖沙上安眠的闲适。飞与睡、动与静、忙与闲形成对比，相映成趣。全诗清新自然，色彩鲜明，是杜甫少有的轻快之作。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '春日江山秀丽', keywords: ['迟日', '江山丽'] },
          { level: '中景', content: '春风花草飘香', keywords: ['春风', '花草香'] },
          { level: '动态', content: '燕子衔泥飞舞', keywords: ['泥融', '燕子'] },
          { level: '静态', content: '鸳鸯沙上安睡', keywords: ['沙暖', '鸳鸯'] },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_038',
    title: '惠崇春江晚景',
    author: '苏轼',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '咏物'],
    text: {
      original: '竹外桃花三两枝，春江水暖鸭先知。蒌蒿满地芦芽短，正是河豚欲上时。',
      sentences: ['竹外桃花三两枝', '春江水暖鸭先知', '蒌蒿满地芦芽短', '正是河豚欲上时'],
      rhymeScheme: ['枝', '知', '时'],
    },
    annotations: [
      { term: '惠崇', note: '北宋僧人，能诗善画。' },
      { term: '蒌蒿', note: '一种生长在水边的草本植物。' },
      { term: '芦芽', note: '芦苇的嫩芽。' },
      { term: '河豚', note: '一种鱼，味道鲜美但有毒性。' },
      { term: '先知', note: '最先感知。' },

      { term: '上', note: '指河滩上。' }
    ],
    translation: '竹林外面有几枝桃花刚刚绽放，春天江水变暖鸭子最先知道。蒌蒿遍地芦苇刚刚冒出短芽，正是河豚将要逆流而上的季节。',
    literaryInfo: {
      authorBio: '苏轼（1037年—1101年），字太白，号东坡居士，北宋文学家、书画家，"唐宋八大家"之一。',
      background: '此诗为苏轼为僧人惠崇的画作《春江晚景》所写的题画诗。',
      significance: `"春江水暖鸭先知"是千古名句。此诗为题画诗，却突破了画面的限制，将视觉与触觉结合——画中能看到鸭子戏水，却感受不到水温，苏轼以想象补足画外之意。"竹外桃花三两枝"以稀疏的笔触写早春，"蒌蒿满地芦芽短，正是河豚欲上时"由画中景物联想到画外河豚，由岸及水，由静转动，体现了苏轼诗歌的丰富想象力。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '近景', content: '竹外桃花', keywords: ['竹外', '桃花'] },
          { level: '中景', content: '春江鸭戏水', keywords: ['水暖', '鸭先知'] },
          { level: '远景', content: '蒌蒿满地芦芽短', keywords: ['蒌蒿', '芦芽'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_039',
    title: '三衢道中',
    author: '曾几',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '田园'],
    text: {
      original: '梅子黄时日日晴，小溪泛尽却山行。绿阴不减来时路，添得黄鹂四五声。',
      sentences: ['梅子黄时日日晴', '小溪泛尽却山行', '绿阴不减来时路', '添得黄鹂四五声'],
      rhymeScheme: ['晴', '行', '声'],
    },
    annotations: [
      { term: '三衢', note: '三衢山，在今浙江省衢州市。' },
      { term: '梅子黄时', note: '指初夏梅子成熟的季节。' },
      { term: '泛尽', note: '乘船到了尽头。' },
      { term: '却', note: '再，又。' },
      { term: '不减', note: '不比……少，不少于。' },

      { term: '泛', note: '乘船，泛舟。' }
    ],
    translation: '梅子黄透的时候天天都是晴朗的天气，乘船到了小溪的尽头再改走山路。山路上绿树成荫的浓密程度不比来时少，还增添了黄鹂的几声清脆鸣叫。',
    literaryInfo: {
      authorBio: '曾几（1084年—1166年），字吉甫，号茶山居士，南宋诗人，陆游的老师。',
      background: '此诗写诗人在三衢山道中旅行的见闻感受，初夏时节景色宜人。',
      significance: `此诗以轻快的笔调写初夏山行之乐。"梅子黄时日日晴"点明时令和好天气，梅雨季难得晴天，格外可贵；"小溪泛尽却山行"写水路转山路，行程变化带来新鲜感。"绿阴不减来时路"写归途所见，绿荫依旧浓密；"添得黄鹂四五声"以声衬静，黄鹂的鸣叫为绿荫增添了生机。全诗"不减"与"添得"对比，写出归途比来时更多了一份惊喜。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '天景', content: '梅子黄时日日晴', keywords: ['梅子黄', '日日晴'] },
          { level: '水景', content: '小溪泛尽', keywords: ['小溪', '泛尽'] },
          { level: '山景', content: '绿阴不减', keywords: ['绿阴', '山行'] },
          { level: '声景', content: '黄鹂鸣叫', keywords: ['黄鹂', '四五声'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_040',
    title: '忆江南',
    author: '白居易',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '词' },
    themes: ['山水', '思乡'],
    text: {
      original: '江南好，风景旧曾谙。日出江花红胜火，春来江水绿如蓝。能不忆江南？',
      sentences: ['江南好', '风景旧曾谙', '日出江花红胜火', '春来江水绿如蓝', '能不忆江南'],
      rhymeScheme: ['谙', '蓝', '南'],
    },
    annotations: [
      { term: '谙', note: '熟悉。' },
      { term: '江花', note: '江边的花。' },
      { term: '蓝', note: '蓼蓝，一种植物，叶子可制蓝色染料。' },
      { term: '忆江南', note: '词牌名，原为唐教坊曲名。' },
      { term: '胜', note: '胜过，超过。' },

      { term: '胜火', note: '比火还红。胜，超过。' },
    ],
    translation: '江南的风景多么美好，那里的风光我曾经多么熟悉。春天到来时，太阳从江面升起，江边的花朵比火还红，江水像蓼蓝一样碧绿。怎能不怀念江南？',
    literaryInfo: {
      authorBio: '白居易（772年—846年），字乐天，号香山居士，唐代伟大的现实主义诗人。',
      background: '白居易曾任杭州刺史、苏州刺史，对江南风光有深厚感情，回到北方后写下此词。',
      significance: `"日出江花红胜火，春来江水绿如蓝"是赞美江南的千古名句。以强烈的色彩对比追忆江南之美——"红胜火"以火的红色比喻江花的艳丽，"绿如蓝"以蓝草的深绿比喻江水的碧透，红与绿对比鲜明，视觉冲击力极强。"能不忆江南"以反问收束，强调江南之美令人魂牵梦萦。全词语言明快，色调浓烈。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '色彩', content: '江花红胜火', keywords: ['江花', '红胜火'] },
          { level: '水色', content: '江水绿如蓝', keywords: ['江水', '绿如蓝'] },
          { level: '情感', content: '忆江南', keywords: ['忆', '江南'] },
        ],
      },
    },
    stats: { charCount: 27, sentenceCount: 5, rhymeCount: 3 },
  },
  {
    id: 'p_041',
    title: '元日',
    author: '王安石',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['节日', '人生'],
    text: {
      original: '爆竹声中一岁除，春风送暖入屠苏。千门万户曈曈日，总把新桃换旧符。',
      sentences: ['爆竹声中一岁除', '春风送暖入屠苏', '千门万户曈曈日', '总把新桃换旧符'],
      rhymeScheme: ['除', '苏', '符'],
    },
    annotations: [
      { term: '元日', note: '农历正月初一，即春节。' },
      { term: '屠苏', note: '一种药酒，正月初一饮用以避瘟疫。' },
      { term: '曈曈', note: '光辉灿烂的样子。' },
      { term: '新桃旧符', note: '桃符是古代挂在门上的两块桃木板，新年换新桃符。' },
      { term: '除', note: '逝去，过去。' },

      { term: '一岁除', note: '一年过去了。除，逝去。' },
      { term: '曈曈日', note: '初升的太阳光辉灿烂的样子。' }
    ],
    translation: '在噼噼啪啪的爆竹声中送走了旧年，春风把暖意送进了屠苏酒中。初升的太阳照耀着千家万户，人们都忙着把旧的桃符取下换上新的桃符。',
    literaryInfo: {
      authorBio: '王安石（1021年—1086年），字介甫，号半山，北宋政治家、文学家，"唐宋八大家"之一。',
      background: '此诗作于王安石推行新法时期，借新年除旧布新的气象寄托政治理想。',
      significance: `此诗描写了春节的热闹景象。"爆竹声中一岁除"以声开篇，辞旧迎新；"春风送暖入屠苏"写春日的温暖与祝福。"千门万户曈曈日"写旭日东升照耀千家万户，气象宏大；"总把新桃换旧符"以桃符的更替象征除旧布新。全诗既写出了春节的热闹喜庆，也暗含王安石推行新法、除旧布新的政治抱负，写景与抒志浑然一体。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '春节除旧迎新，爆竹声声，春风送暖，千家万户换桃符。',
        timeline: [
          { event: '爆竹声起', order: 1 },
          { event: '一岁除旧', order: 2 },
          { event: '春风送暖入屠苏', order: 3 },
          { event: '曈曈日照千门万户', order: 4 },
          { event: '新桃换旧符', order: 5 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_042',
    title: '清明',
    author: '杜牧',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['节日', '思乡'],
    text: {
      original: '清明时节雨纷纷，路上行人欲断魂。借问酒家何处有？牧童遥指杏花村。',
      sentences: ['清明时节雨纷纷', '路上行人欲断魂', '借问酒家何处有', '牧童遥指杏花村'],
      rhymeScheme: ['纷', '魂', '村'],
    },
    annotations: [
      { term: '清明', note: '清明节，二十四节气之一，在每年四月五日前后。' },
      { term: '纷纷', note: '细雨密密飘落的样子。' },
      { term: '断魂', note: '形容伤感极深，好像灵魂离开了身体。' },
      { term: '杏花村', note: '杏花深处的村庄。' },

      { term: '欲断魂', note: '形容极其伤感。断魂，形容忧伤极深。' },
    ],
    translation: '清明节这天细雨纷纷飘洒，路上远行的人好像断了魂一样迷茫凄凉。请问哪里有酒家可以歇脚？牧童远远指向那个杏花深处的村庄。',
    literaryInfo: {
      authorBio: '杜牧（803年—852年），字牧之，唐代诗人，与李商隐并称"小李杜"。',
      background: '此诗写清明时节旅人冒雨赶路的愁苦心情，以及寻得酒家的欣慰。',
      significance: `此诗以清明时节的雨中景象写旅人的愁苦。"清明时节雨纷纷"以环境渲染气氛，雨与愁天然相配；"路上行人欲断魂"直写行人思乡的悲苦。"借问酒家何处有"以问句转折，寻求消愁之所；"牧童遥指杏花村"以一幅生动的画面作答，牧童、遥指、杏花，在忧愁中透出一丝希望与暖意。全诗由愁而问、由问而得，情绪由抑到扬，余味悠长。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '清明雨纷纷', keywords: ['清明', '雨纷纷'] },
          { level: '中景', content: '路上断魂人', keywords: ['行人', '断魂'] },
          { level: '近景', content: '杏花村的酒家', keywords: ['杏花村', '酒家'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_043',
    title: '九月九日忆山东兄弟',
    author: '王维',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['思乡', '节日'],
    text: {
      original: '独在异乡为异客，每逢佳节倍思亲。遥知兄弟登高处，遍插茱萸少一人。',
      sentences: ['独在异乡为异客', '每逢佳节倍思亲', '遥知兄弟登高处', '遍插茱萸少一人'],
      rhymeScheme: ['亲', '人'],
    },
    annotations: [
      { term: '九月九日', note: '重阳节，古人有登高、插茱萸的习俗。' },
      { term: '山东', note: '华山以东，诗人家乡在蒲州（今山西永济），在华山东面。' },
      { term: '茱萸', note: '一种香草，重阳节佩戴可辟邪。' },
      { term: '倍', note: '更加。' },

      { term: '异乡', note: '他乡，远离故乡的地方。' },
      { term: '登高', note: '重阳节有登高望远的习俗。' },
    ],
    translation: '独自漂泊在他乡做异乡之客，每逢佳节到来就更加思念亲人。遥想兄弟们今天登高远眺的时候，插遍了茱萸只少了我一个人。',
    literaryInfo: {
      authorBio: '王维（701年—761年），字摩诘，唐代诗人、画家，有"诗佛"之称。',
      background: '此诗作于王维十七岁时独自在长安求取功名，重阳节思念家乡亲人而作。',
      significance: `"每逢佳节倍思亲"是千古流传的名句。"独在异乡为异客"以两个"异"字写出漂泊他乡的孤独感；"每逢佳节倍思亲"道出游子的普遍情感体验，"倍"字将思亲之情推向极致。后两句转换视角，从家乡兄弟登高的角度来写，想象他们插茱萸时发现少了一人，不写自己思念而写兄弟思念自己，对面落笔，更显情深意切。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '独在异乡为异客', emotion: '孤独', intensity: 7 },
          { segment: '每逢佳节倍思亲', emotion: '思念', intensity: 9 },
          { segment: '遥知兄弟登高处', emotion: '想象', intensity: 6 },
          { segment: '遍插茱萸少一人', emotion: '伤感', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_044',
    title: '滁州西涧',
    author: '韦应物',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '田园'],
    text: {
      original: '独怜幽草涧边生，上有黄鹂深树鸣。春潮带雨晚来急，野渡无人舟自横。',
      sentences: ['独怜幽草涧边生', '上有黄鹂深树鸣', '春潮带雨晚来急', '野渡无人舟自横'],
      rhymeScheme: ['生', '鸣', '横'],
    },
    annotations: [
      { term: '滁州', note: '今安徽省滁州市。' },
      { term: '西涧', note: '滁州城西的溪流。' },
      { term: '独怜', note: '唯独喜爱。怜，爱。' },
      { term: '野渡', note: '荒野的渡口。' },

      { term: '深树', note: '树丛深处。' },
    ],
    translation: '唯独喜爱涧边生长的幽幽芳草，还有树丛深处鸣叫的黄鹂。傍晚时分春潮夹着雨水来得很急，荒野的渡口没有行人，一只小船独自横在水面上。',
    literaryInfo: {
      authorBio: '韦应物（737年—792年），唐代诗人，以山水田园诗著称，与王维、孟浩然、柳宗元并称"王孟韦柳"。',
      background: '此诗作于韦应物任滁州刺史期间，春日游西涧时所作。',
      significance: `"野渡无人舟自横"是千古名句。"独怜幽草涧边生"以"独怜"表达对幽草的偏爱，"上有黄鹂深树鸣"以鸟鸣衬出山涧的幽静。"春潮带雨晚来急"写傍晚春雨骤至、潮水猛涨的动态；"野渡无人舟自横"以无人渡口的小舟横斜写出一种闲适自得之意。全诗动静结合，"自"字赋予小舟以自在的意趣，意境幽远。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '近景', content: '涧边幽草', keywords: ['幽草', '涧边'] },
          { level: '中景', content: '黄鹂深树鸣', keywords: ['黄鹂', '深树'] },
          { level: '远景', content: '春潮带雨', keywords: ['春潮', '晚来急'] },
          { level: '特写', content: '野渡舟横', keywords: ['野渡', '舟自横'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_045',
    title: '大林寺桃花',
    author: '白居易',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '哲理'],
    text: {
      original: '人间四月芳菲尽，山寺桃花始盛开。长恨春归无觅处，不知转入此中来。',
      sentences: ['人间四月芳菲尽', '山寺桃花始盛开', '长恨春归无觅处', '不知转入此中来'],
      rhymeScheme: ['开', '来'],
    },
    annotations: [
      { term: '大林寺', note: '在庐山香炉峰顶。' },
      { term: '芳菲', note: '花草的芳香，代指花。' },
      { term: '尽', note: '凋谢，开完。' },
      { term: '长恨', note: '常常遗憾。' },

      { term: '人间', note: '指山下的尘世。' },
      { term: '不知', note: '不知道，未发现。' },
      { term: '转', note: '转变，指从春天到了夏天。' }
    ],
    translation: '人间的四月百花已经凋零，但山寺中的桃花才刚刚盛开。常常遗憾春天归去无处寻觅，却不知春天已经转到了这山寺中来了。',
    literaryInfo: {
      authorBio: '白居易（772年—846年），字乐天，号香山居士，唐代伟大的现实主义诗人。',
      background: '此诗作于白居易被贬江州司马期间，游览庐山大林寺时所作。',
      significance: `此诗以山寺桃花迟开的自然现象，写出"春去又回"的惊喜。"人间四月芳菲尽"写山下春花已谢的遗憾；"山寺桃花始盛开"写山上桃花正在盛开的惊喜。"长恨春归无觅处"承上，写惜春寻春而不得的怅惘；"不知转入此中来"转下，原来春天并未归去，只是转到了山寺之中。全诗由憾转喜，以山寺桃花的迟开表达了对春天的眷恋，也蕴含着人生处处有转机的哲理。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '人间', content: '四月芳菲尽', keywords: ['四月', '芳菲尽'] },
          { level: '山寺', content: '桃花始盛开', keywords: ['山寺', '桃花'] },
          { level: '感悟', content: '春归此处', keywords: ['春归', '此中来'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 2 },
  },
  // ===== 四年级上册 =====
  {
    id: 'p_046',
    title: '暮江吟',
    author: '白居易',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水'],
    text: {
      original: '一道残阳铺水中，半江瑟瑟半江红。可怜九月初三夜，露似真珠月似弓。',
      sentences: ['一道残阳铺水中', '半江瑟瑟半江红', '可怜九月初三夜', '露似真珠月似弓'],
      rhymeScheme: ['中', '红', '弓'],
    },
    annotations: [
      { term: '暮江吟', note: '傍晚在江边所作的诗。吟，古代诗歌体裁。' },
      { term: '瑟瑟', note: '碧绿色，形容未受到夕阳照射的江水颜色。' },
      { term: '可怜', note: `可爱。古今异义。` },
      { term: '真珠', note: '珍珠。' },
      { term: '铺', note: '铺展，此处形容夕阳余晖平铺水面的柔和景象。' },

    ],
    translation: '一道夕阳的余晖铺洒在江面上，江水一半呈现出碧绿色一半呈现出红色。最可爱的是九月初三的夜晚，露水像珍珠一样晶莹，月亮像弯弓一样弯曲。',
    literaryInfo: {
      authorBio: '白居易（772年—846年），字乐天，号香山居士，唐代伟大的现实主义诗人。',
      background: '此诗作于白居易赴任杭州途中，傍晚时分在江边所见美景。',
      significance: `此诗以细腻的笔触描绘了从黄昏到夜晚的江上美景。"一道残阳铺水中"以"铺"字写出夕阳平铺水面的柔和，比"照"字更显安闲；"半江瑟瑟半江红"以色彩对比——碧绿与殷红各占半江，视觉鲜明。"可怜九月初三夜"以"可怜"（可爱）直抒赞美；"露似真珠月似弓"以珍珠比喻露珠、以弯弓比喻新月，两个比喻精巧贴切。全诗从夕阳到新月，时间推移中景色变幻，美不胜收。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '残阳铺水', keywords: ['残阳', '铺水中'] },
          { level: '中景', content: '半江瑟瑟半江红', keywords: ['瑟瑟', '半江红'] },
          { level: '近景', content: '露似真珠月似弓', keywords: ['真珠', '月似弓'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_047',
    title: '题西林壁',
    author: '苏轼',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['哲理', '山水'],
    text: {
      original: '横看成岭侧成峰，远近高低各不同。不识庐山真面目，只缘身在此山中。',
      sentences: ['横看成岭侧成峰', '远近高低各不同', '不识庐山真面目', '只缘身在此山中'],
      rhymeScheme: ['峰', '同', '中'],
    },
    annotations: [
      { term: '西林壁', note: '西林寺的墙壁，西林寺在庐山脚下。' },
      { term: '横看', note: '从正面看。' },
      { term: '缘', note: '因为。' },
      { term: '真面目', note: '真实的面貌。' },

      { term: '侧', note: '从侧面看。' },
    ],
    translation: '从正面看庐山是连绵的山岭，从侧面看又成了高耸的山峰，从远处近处高处低处看都不相同。之所以认不清庐山的真实面貌，只是因为自己身在这座山中。',
    literaryInfo: {
      authorBio: '苏轼（1037年—1101年），字子瞻，号东坡居士，北宋文学家、书画家，"唐宋八大家"之一。',
      background: '此诗作于苏轼游庐山时，由观山感悟到认识事物的道理。',
      significance: `"不识庐山真面目，只缘身在此山中"是千古哲理名句。"横看成岭侧成峰"以横看与侧看的不同视角写出庐山的多姿形态；"远近高低各不同"进一步扩展视角，不同距离和高度所见各异。后两句由写景转出哲理——之所以看不清庐山的真面目，是因为身处山中，被局部所限。全诗以游山的感受揭示认识论的哲理：当局者迷，旁观者清，要认识事物的全貌必须超越局限。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '横看侧看庐山各异，因身在其中而难以认清其真面目，蕴含哲理。',
        timeline: [
          { event: '横看成岭', order: 1 },
          { event: '侧成峰', order: 2 },
          { event: '远近高低各不同', order: 3 },
          { event: '不识庐山真面目', order: 4 },
          { event: '只缘身在此山中', order: 5 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_048',
    title: '雪梅',
    author: '卢钺',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['咏物', '哲理'],
    text: {
      original: '梅雪争春未肯降，骚人阁笔费评章。梅须逊雪三分白，雪却输梅一段香。',
      sentences: ['梅雪争春未肯降', '骚人阁笔费评章', '梅须逊雪三分白', '雪却输梅一段香'],
      rhymeScheme: ['降', '章', '香'],
    },
    annotations: [
      { term: '降', note: `认输，服输。` },
      { term: '骚人', note: '诗人。' },
      { term: '阁笔', note: `放下笔。阁，同"搁"。通假字。` },
      { term: '评章', note: '评议文章，此处指评判梅与雪的高下。' },
      { term: '逊', note: '不及，比不上。' },

      { term: '雪却输梅一段香', note: '白雪却在香气上输给了梅花。输，不及，比不上。' },
    ],
    translation: '梅花和雪争夺春色谁也不肯认输，诗人放下笔费尽心思也难以评判。梅花须比雪差三分洁白，雪却输给梅花一段清香。',
    literaryInfo: {
      authorBio: '卢钺，南宋诗人，生卒年不详，字威节，一作威仲，闽清（今属福建）人。',
      background: '此诗以梅雪争春为喻，阐述事物各有所长也各有所短的道理。',
      significance: `此诗以梅雪之争写哲理思考。"梅雪争春未肯降"以拟人手法写梅与雪各不相让；"骚人阁笔费评章"写文人也无法评判高下。"梅须逊雪三分白"指出梅不如雪白，"雪却输梅一段香"指出雪不如梅香，两者各有长短。全诗以梅雪之争说明世间万物各有所长也各有所短，不可偏废，蕴含了辩证思考的哲理。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '梅雪争春未肯降', emotion: '争执', intensity: 6 },
          { segment: '骚人阁笔费评章', emotion: '为难', intensity: 5 },
          { segment: '梅须逊雪三分白', emotion: '理性', intensity: 7 },
          { segment: '雪却输梅一段香', emotion: '感悟', intensity: 8 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_049',
    title: '出塞',
    author: '王昌龄',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['边塞', '战争', '爱国'],
    text: {
      original: '秦时明月汉时关，万里长征人未还。但使龙城飞将在，不教胡马度阴山。',
      sentences: ['秦时明月汉时关', '万里长征人未还', '但使龙城飞将在', '不教胡马度阴山'],
      rhymeScheme: ['关', '还', '山'],
    },
    annotations: [
      { term: '出塞', note: '出关征战的乐府旧题。' },
      { term: '龙城飞将', note: '指汉将卫青和李广，此处借指英勇善战的将领。' },
      { term: '胡马', note: '指外族入侵的骑兵。' },
      { term: '阴山', note: '昆仑山的北支，绵延于长城以北。' },

      { term: '关', note: '边关，要塞。' },
      { term: '万里长征人未还', note: '万里长征的将士还没有回来。' },
      { term: '飞将', note: '飞将军李广，汉代名将，匈奴畏惧他。' }
    ],
    translation: '依然是秦汉时期的明月和边关，守边御敌鏖战万里的征人至今仍然没有回来。只要有像飞将军李广那样的名将守在边关，绝不会让敌人的骑兵越过阴山。',
    literaryInfo: {
      authorBio: '王昌龄（698年—757年），字少伯，唐代诗人，以边塞诗著称，被誉为"七绝圣手"。',
      background: '此诗以边塞为题材，对当时边患不断、将士久戍不归的现实表达感慨。',
      significance: `此诗被誉为唐代七绝压卷之作。"秦时明月汉时关"以互文手法，将秦汉两个时代融合，千年的明月与边关积淀了无尽的历史沧桑；"万里长征人未还"点明战争的残酷。"但使龙城飞将在，不教胡马度阴山"以假设表达对良将的渴望。全诗雄浑苍凉，既有对战争苦难的同情，也有保家卫国的壮志。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '秦时明月汉时关', emotion: '苍凉', intensity: 7 },
          { segment: '万里长征人未还', emotion: '悲痛', intensity: 9 },
          { segment: '但使龙城飞将在', emotion: '期盼', intensity: 8 },
          { segment: '不教胡马度阴山', emotion: '豪壮', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_050',
    title: '凉州词',
    author: '王翰',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['边塞', '战争'],
    text: {
      original: '葡萄美酒夜光杯，欲饮琵琶马上催。醉卧沙场君莫笑，古来征战几人回？',
      sentences: ['葡萄美酒夜光杯', '欲饮琵琶马上催', '醉卧沙场君莫笑', '古来征战几人回'],
      rhymeScheme: ['杯', '催', '回'],
    },
    annotations: [
      { term: '夜光杯', note: '一种白玉制成的酒杯，光能照夜。' },
      { term: '琵琶', note: '一种弦乐器。' },
      { term: '沙场', note: '战场。' },
      { term: '凉州词', note: '凉州歌的唱词，凉州在今甘肃一带。' },

      { term: '万仞', note: '形容极高。仞，古代长度单位，一仞约八尺。' },
      { term: '何须', note: '何必。何必用杨柳来怨别呢。' },
      { term: '春风', note: '暗指朝廷的恩典。' }
    ],
    translation: '精美的酒杯中斟满了葡萄美酒，正要畅饮却又听到马上弹起了琵琶催促出发。即使醉倒在战场上也请你不要笑话，自古以来出征打仗的人有几个能活着回来？',
    literaryInfo: {
      authorBio: '王翰，唐代诗人，生卒年不详，字子羽，并州晋阳（今山西太原）人。',
      background: '此诗描写边塞将士们战前饮酒的豪迈场面，反映征人的复杂心理。',
      significance: `"醉卧沙场君莫笑，古来征战几人回"以豪迈与悲壮交织的笔调写边塞情怀。前两句"葡萄美酒夜光杯，欲饮琵琶马上催"以华美的意象写战前痛饮，琵琶催征由享乐转入紧张。"醉卧沙场"看似旷达实则悲壮，"古来征战几人回"以反问收束，看似潇洒实则悲痛。全诗以"莫笑"自宽，以"几人回"自叹，豪迈与悲凉交织。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '葡萄美酒夜光杯', emotion: '豪迈', intensity: 6 },
          { segment: '欲饮琵琶马上催', emotion: '紧迫', intensity: 7 },
          { segment: '醉卧沙场君莫笑', emotion: '悲壮', intensity: 8 },
          { segment: '古来征战几人回', emotion: '感伤', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_051',
    title: '夏日绝句',
    author: '李清照',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['爱国', '咏史'],
    text: {
      original: '生当作人杰，死亦为鬼雄。至今思项羽，不肯过江东。',
      sentences: ['生当作人杰', '死亦为鬼雄', '至今思项羽', '不肯过江东'],
      rhymeScheme: ['雄', '东'],
    },
    annotations: [
      { term: '人杰', note: '人中的豪杰。' },
      { term: '鬼雄', note: '鬼中的英雄。' },
      { term: '项羽', note: '秦末农民起义领袖，后与刘邦争天下，兵败自刎于乌江。' },
      { term: '江东', note: '长江下游以东地区，项羽起兵之地。' },

    ],
    translation: '活着就要做人中的豪杰，死了也要做鬼中的英雄。直到今天人们还在思念项羽，因为他宁死也不肯逃回江东。',
    literaryInfo: {
      authorBio: '李清照（1084年—约1155年），号易安居士，宋代女词人，婉约词派代表，有"千古第一才女"之称。',
      background: '此诗作于南宋初年，金兵南侵，朝廷偏安南渡，李清照借项羽讽刺当权者的懦弱妥协。',
      significance: `此诗以项羽不肯过江东的气节，讽刺南宋朝廷偏安苟且。"生当作人杰，死亦为鬼雄"以生死并论，写出人生当壮烈的气概；"至今思项羽，不肯过江东"以项羽宁死不渡江回乡的事迹暗讽南宋朝廷偏安江南、不思北伐的怯懦。李清照身为女子，却有如此豪壮之气，以古讽今，气势不输须眉。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '生当作人杰', emotion: '豪迈', intensity: 8 },
          { segment: '死亦为鬼雄', emotion: '壮烈', intensity: 9 },
          { segment: '至今思项羽', emotion: '缅怀', intensity: 7 },
          { segment: '不肯过江东', emotion: '敬佩', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_052',
    title: '嫦娥',
    author: '李商隐',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['咏物', '人生'],
    text: {
      original: '云母屏风烛影深，长河渐落晓星沉。嫦娥应悔偷灵药，碧海青天夜夜心。',
      sentences: ['云母屏风烛影深', '长河渐落晓星沉', '嫦娥应悔偷灵药', '碧海青天夜夜心'],
      rhymeScheme: ['深', '沉', '心'],
    },
    annotations: [
      { term: '云母屏风', note: '镶嵌云母的屏风，云母是一种发光的矿物。' },
      { term: '长河', note: '银河。' },
      { term: '灵药', note: '指嫦娥偷吃的长生不老药。' },
      { term: '碧海青天', note: '指嫦娥所在的月宫。' },

    ],
    translation: '云母屏风后面烛光暗淡，银河渐渐斜落，晨星也隐没了。嫦娥想必悔恨当初偷吃了不死药，如今只能面对碧海青天，夜夜孤独伤心。',
    literaryInfo: {
      authorBio: '李商隐（约813年—约858年），字义山，唐代诗人，与杜牧合称"小李杜"，诗风绮丽含蓄。',
      background: '此诗以嫦娥奔月的传说为题材，以嫦娥的孤独暗喻自己的处境。',
      significance: `此诗以嫦娥的悔恨表达了对孤独的深刻感受。"云母屏风烛影深"以烛影的暗淡暗示长夜的孤寂；"长河渐落晓星沉"以星河的推移写出通宵未眠。"嫦娥应悔偷灵药"以"悔"字道出嫦娥的孤寂之苦；"碧海青天夜夜心"以夜夜重复的孤独，将悔恨推向无尽。全诗借神话写人世，以仙人的寂寞映射诗人自身的孤清。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '云母屏风烛影深', emotion: '幽暗', intensity: 5 },
          { segment: '长河渐落晓星沉', emotion: '孤寂', intensity: 7 },
          { segment: '嫦娥应悔偷灵药', emotion: '悔恨', intensity: 8 },
          { segment: '碧海青天夜夜心', emotion: '孤独', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_053',
    title: '别董大',
    author: '高适',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['送别', '友情'],
    text: {
      original: '千里黄云白日曛，北风吹雁雪纷纷。莫愁前路无知己，天下谁人不识君。',
      sentences: ['千里黄云白日曛', '北风吹雁雪纷纷', '莫愁前路无知己', '天下谁人不识君'],
      rhymeScheme: ['曛', '纷', '君'],
    },
    annotations: [
      { term: '董大', note: '唐代著名琴师董庭兰，在兄弟中排行第一，故称"大"。' },
      { term: '曛', note: '昏暗，此处指夕阳西沉时的昏暗景象。' },
      { term: '知己', note: '彼此相互了解而情谊深切的人。' },
      { term: '识', note: '认识，了解。' },

      { term: '黄云', note: '黄色的云。形容天色昏暗。' },
      { term: '莫愁前路无知己', note: '不要担心前方的路上没有知己。' }
    ],
    translation: '千里黄云遮天蔽日使天色昏暗，北风吹着大雁又飘着纷纷大雪。不要担心前方的路上没有知己，天下有谁不认识你呢？',
    literaryInfo: {
      authorBio: '高适（约704年—765年），字达夫，唐代边塞诗人，与岑参并称"高岑"。',
      background: '此诗作于高适送别好友董庭兰时，以壮语相慰，格调高昂。',
      significance: `"莫愁前路无知己，天下谁人不识君"是千古送别名句。此诗一扫送别诗的伤感之气，以豪迈的语调鼓励友人——像你这样才华横溢的人，天下谁人不识？"莫愁"二字是宽慰也是自信，"天下谁人"以反问强化语气。全诗格调高昂，在送别诗中独树一帜，展现了盛唐文人豪迈洒脱的风采。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '千里黄云白日曛', emotion: '苍凉', intensity: 6 },
          { segment: '北风吹雁雪纷纷', emotion: '凄寒', intensity: 7 },
          { segment: '莫愁前路无知己', emotion: '豁达', intensity: 8 },
          { segment: '天下谁人不识君', emotion: '豪迈', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_054',
    title: '王戎不取道旁李',
    author: '佚名',
    dynasty: '魏晋南北朝',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '文言文', subGenre: '记叙文' },
    themes: ['哲理', '人生'],
    text: {
      original: '王戎七岁，尝与诸小儿游。看道边李树多子折枝，诸儿竞走取之，唯戎不动。人问之，答曰：\`树在道边而多子，此必苦李。\`取之，信然。',
      sentences: ['王戎七岁，尝与诸小儿游', '看道边李树多子折枝，诸儿竞走取之，唯戎不动', '人问之，答曰：树在道边而多子，此必苦李', '取之，信然'],
    },
    annotations: [
      { term: '尝', note: '曾经。' },
      { term: '诸', note: '众，各。' },
      { term: '竞走', note: '争相跑过去。' },
      { term: '信然', note: '确实如此。' },

      { term: '唯', note: '只有。' },
      { term: '取信', note: '相信。取，这里指采信。' }
    ],
    translation: '王戎七岁的时候，曾经和一群小朋友一起玩耍。看到路边的李树上结满了果实，压弯了树枝，小朋友们争相跑去摘李子，只有王戎站着不动。有人问他为什么不去摘，他回答说："树长在路边却果实累累，这一定是苦李子。"大家摘来一尝，果然如此。',
    literaryInfo: {
      authorBio: '佚名，出自南朝刘义庆编《世说新语》。刘义庆（403年—444年），南朝宋宗室，文学家。',
      background: '此故事选自《世说新语·雅量》，记述了王戎幼年时的聪慧故事。',
      significance: `此故事启示人们做事要善于观察和思考，不能盲目从众。"道边李树多子折枝"是关键信息——李子多到压弯枝条却无人摘，说明一定是苦李。众人竞相取之，唯王戎不动，以推理代替盲从。"取之，信然"验证了王戎的判断，是培养思辨能力的经典寓言。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '王戎七岁时与小伙伴看到路边的李树果实累累，其他孩子争相去摘，唯有王戎判断是苦李子而不动。',
        timeline: [
          { event: '诸小儿游', order: 1 },
          { event: '见李树多子折枝', order: 2 },
          { event: '诸儿竞走取之', order: 3 },
          { event: '王戎不动', order: 4 },
          { event: '答曰必苦李', order: 5 },
          { event: '取之信然', order: 6 },
        ],
      },
    },
    stats: { charCount: 53, sentenceCount: 4, rhymeCount: 3 },
  },
  // ===== 四年级下册 =====
  {
    id: 'p_055',
    title: '四时田园杂兴（其二十五）',
    author: '范成大',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['田园'],
    text: {
      original: '梅子金黄杏子肥，麦花雪白菜花稀。日长篱落无人过，惟有蜻蜓蛱蝶飞。',
      sentences: ['梅子金黄杏子肥', '麦花雪白菜花稀', '日长篱落无人过', '惟有蜻蜓蛱蝶飞'],
      rhymeScheme: ['肥', '稀', '飞'],
    },
    annotations: [
      { term: '杂兴', note: '随兴而写的诗。' },
      { term: '肥', note: '果肉丰满。' },
      { term: '篱落', note: '篱笆。' },
      { term: '蛱蝶', note: '蝴蝶的一种。' },

      { term: '麦花雪白菜花稀', note: '麦花白如雪，油菜花已经稀少。' },
    ],
    translation: '梅子已经变成金黄色，杏子也长得很肥大了，荞麦花雪白雪白的，油菜花则变得稀少了。白天变长了，篱笆旁没有人经过，只有蜻蜓和蝴蝶在那里飞舞。',
    literaryInfo: {
      authorBio: '范成大（1126年—1193年），字致能，号石湖居士，南宋诗人，与陆游、杨万里、尤袤合称"南宋四家"。',
      background: '此诗选自《四时田园杂兴》组诗，描写初夏江南农村的景象。',
      significance: `此诗以白描手法写出初夏田园风光。"梅子金黄杏子肥"以色彩和果实写丰收，"麦花雪白菜花稀"写季节推移。"日长篱落无人过"以长日无人写农村宁静，"惟有蜻蜓蛱蝶飞"以蜻蜓蝴蝶的飞舞增添动感。全诗以静为主、以动衬静，色彩明丽。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '果景', content: '梅子金黄杏子肥', keywords: ['梅子', '杏子'] },
          { level: '花景', content: '麦花雪白', keywords: ['麦花', '菜花'] },
          { level: '动态', content: '蜻蜓蛱蝶飞', keywords: ['蜻蜓', '蛱蝶'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_056',
    title: '宿新市徐公店',
    author: '杨万里',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['田园'],
    text: {
      original: '篱落疏疏一径深，树头新绿未成阴。儿童急走追黄蝶，飞入菜花无处寻。',
      sentences: ['篱落疏疏一径深', '树头新绿未成阴', '儿童急走追黄蝶', '飞入菜花无处寻'],
      rhymeScheme: ['深', '阴', '寻'],
    },
    annotations: [
      { term: '新市', note: '地名，在今浙江省德清县。' },
      { term: '徐公店', note: '姓徐的人开的客店。' },
      { term: '疏疏', note: '稀疏。' },
      { term: '急走', note: '快跑。' },

      { term: '篱落疏疏', note: '篱笆稀稀疏疏。疏疏，稀疏的样子。' },
      { term: '黄蝶', note: '黄色的蝴蝶。飞入菜花中因颜色相同而难以分辨。' }
    ],
    translation: '篱笆稀稀疏疏有一条小路通向远处，树头刚长出的新叶还没有形成浓密的绿荫。儿童快步跑去追逐黄色的蝴蝶，蝴蝶飞入菜花丛中再也找不到了。',
    literaryInfo: {
      authorBio: '杨万里（1127年—1206年），字廷秀，号诚斋，南宋诗人，"南宋四家"之一。',
      background: '此诗写诗人在新市徐公店住宿时所见乡村春景。',
      significance: `"儿童急走追黄蝶，飞入菜花无处寻"生动描绘了儿童捕蝶的情景。"篱落疏疏一径深"写篱笆稀疏小路幽深，"树头新绿未成阴"写树叶初生尚未浓密。"急走"写出儿童追蝶的急切，"飞入菜花无处寻"以黄蝶飞入黄色菜花中无法分辨写出童趣的失落，一"追"一"寻"充满天真活泼。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '篱落疏疏小径深', keywords: ['篱落', '一径'] },
          { level: '中景', content: '新绿未成阴', keywords: ['新绿', '未成阴'] },
          { level: '近景', content: '儿童追黄蝶', keywords: ['黄蝶', '急走'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_057',
    title: '清平乐·村居',
    author: '辛弃疾',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '词', subGenre: '婉约派' },
    themes: ['田园'],
    text: {
      original: `茅檐低小，溪上青青草。醉里吴音相媚好，白发谁家翁媪？大儿锄豆溪东，中儿正织鸡笼。最喜小儿亡赖，溪头卧剥莲蓬。`,
      sentences: ['茅檐低小', '溪上青青草', '醉里吴音相媚好', '白发谁家翁媪', '大儿锄豆溪东', '中儿正织鸡笼', '最喜小儿亡赖', '溪头卧剥莲蓬'],
      rhymeScheme: ['草', '媪', '东', '笼', '蓬'],
    },
    annotations: [
      { term: '清平乐', note: '词牌名。' },
      { term: '茅檐', note: '茅屋的屋檐。' },
      { term: '吴音', note: '吴地的方言，泛指南方方言。' },
      { term: '相媚好', note: '互相逗趣取乐。' },
      { term: '翁媪', note: '老翁和老妇。' },
      { term: '亡赖', note: '同"无赖"，此处指顽皮可爱。亡，同"无"。' },
      { term: '剥', note: '剥开。' },

    ],
    translation: '茅屋低矮小巧，溪边长满了青青的草。带着醉意用吴地方言互相逗趣，那满头白发的是谁家的老翁老妇？大儿子在溪东边的豆田里锄草，二儿子正在编织鸡笼。最令人喜爱的是小儿子顽皮可爱，趴在溪头剥着莲蓬。',
    literaryInfo: {
      authorBio: '辛弃疾（1140年—1207年），字幼安，号稼轩，南宋豪放派词人，与苏轼合称"苏辛"。',
      background: '此词作于辛弃疾闲居上饶期间，描绘了一家五口农村生活的温馨画面。',
      significance: `此词以白描手法勾勒农村一家五口的生活画面。"茅檐低小，溪上青青草"写环境——矮屋小溪青草；"醉里吴音相媚好"写翁媪对饮相媚的温馨；"大儿""中儿"各有劳作；"最喜小儿亡赖，溪头卧剥莲蓬"以"亡赖"写顽皮，"卧"字最妙——趴着剥莲蓬，写尽天真。全词质朴清新，洋溢着田园生活的怡然自得。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '茅檐低小溪上草', keywords: ['茅檐', '青草'] },
          { level: '中景', content: '翁媪醉里相媚好', keywords: ['翁媪', '吴音'] },
          { level: '近景', content: '大儿中儿各自忙', keywords: ['锄豆', '织鸡笼'] },
          { level: '特写', content: '小儿卧剥莲蓬', keywords: ['卧剥', '莲蓬'] },
        ],
      },
    },
    stats: { charCount: 46, sentenceCount: 8, rhymeCount: 5 },
  },
  {
    id: 'p_058',
    title: '卜算子·咏梅',
    author: '毛泽东',
    dynasty: '近现代',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '词', subGenre: '婉约派' },
    themes: ['咏物', '哲理'],
    text: {original: `风雨送春归，飞雪迎春到。已是悬崖百丈冰，犹有花枝俏。俏也不争春，只把春来报。待到山花烂漫时，她在丛中笑。`,
      sentences: ['风雨送春归，飞雪迎春到', '已是悬崖百丈冰，犹有花枝俏', '俏也不争春，只把春来报', '待到山花烂漫时，她在丛中笑'],
      rhymeScheme: ['到', '俏', '报', '笑'],
    },
    annotations: [
      { term: '卜算子', note: '词牌名。' },
      { term: '百丈冰', note: '形容冰柱极长，极言严寒。' },
      { term: '俏', note: '俊俏美丽。' },
      { term: '烂漫', note: '色彩鲜明美丽。' },

      { term: '已是黄昏独自愁', note: '已经是黄昏时分还在独自忧愁。' },
      { term: '无意苦争春', note: '不想费尽心思去争抢春光。苦，苦苦地，极力。' },
      { term: '一任', note: '任凭，听任。' }
    ],
    translation: '风雨把春天送走了，飞雪又把春天迎来。已经是悬崖上结下了百丈冰柱的严寒，却仍有梅花的花枝俏丽绽放。俏丽却不与百花争春，只是把春天的到来预报。等到漫山遍野鲜花盛开的时候，她在花丛中微笑。',
    literaryInfo: {
      authorBio: '毛泽东（1893年—1976年），字润之，中国革命的领袖，也是杰出的诗人。',
      background: '此词作于1961年，读陆游咏梅词后反其意而用之，以梅花象征革命者的坚强品格。',
      significance: `此词一反陆游咏梅词的孤寂愁苦，以乐观豪迈的气概写出梅花的高洁品质。"已是悬崖百丈冰，犹有花枝俏"写环境越严酷梅花越俏丽；"俏也不争春，只把春来报"写梅花不与百花争春，只做春的使者；"待到山花烂漫时，她在丛中笑"写功成不居的谦逊豁达，格调高昂。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '风雨送春归，飞雪迎春到', emotion: '坚韧', intensity: 6 },
          { segment: '已是悬崖百丈冰，犹有花枝俏', emotion: '赞叹', intensity: 8 },
          { segment: '俏也不争春，只把春来报', emotion: '谦逊', intensity: 7 },
          { segment: '待到山花烂漫时，她在丛中笑', emotion: '欣慰', intensity: 9 },
        ],
      },
    },
    stats: { charCount: 44, sentenceCount: 4, rhymeCount: 4 },
  },
  {
    id: 'p_059',
    title: '江畔独步寻花',
    author: '杜甫',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '咏物'],
    text: {
      original: '黄四娘家花满蹊，千朵万朵压枝低。留连戏蝶时时舞，自在娇莺恰恰啼。',
      sentences: ['黄四娘家花满蹊', '千朵万朵压枝低', '留连戏蝶时时舞', '自在娇莺恰恰啼'],
      rhymeScheme: ['蹊', '低', '啼'],
    },
    annotations: [
      { term: '黄四娘', note: '杜甫在成都草堂时的邻居。' },
      { term: '蹊', note: '小路。' },
      { term: '留连', note: '舍不得离去。' },
      { term: '恰恰', note: '形容鸟叫的声音和谐动听。' },

      { term: '娇', note: '娇嫩，可爱。' },
    ],
    translation: '黄四娘家的花开满了小路，千朵万朵的花把枝条压得很低。留恋花丛的蝴蝶在不停地飞舞，自由自在的黄莺发出悦耳的叫声。',
    literaryInfo: {
      authorBio: '杜甫（712年—770年），字子美，自号少陵野老，唐代伟大的现实主义诗人，被后人誉为"诗圣"。',
      background: '此诗作于杜甫寓居成都草堂时期，春日独自漫步江边赏花而作。',
      significance: `此诗以欢快的笔调描绘春花烂漫的景象。"黄四娘家花满蹊"写花开满路，"千朵万朵压枝低"以数量和重量写花之繁盛。"留连戏蝶时时舞"以蝴蝶的恋花写花之迷人，"自在娇莺恰恰啼"以莺啼写花间的生机。全诗以"时时""恰恰"的叠音写出连续不断的动态美，是杜甫少有的轻松愉悦之作。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '花满蹊径', keywords: ['花满蹊', '黄四娘'] },
          { level: '中景', content: '万朵压枝低', keywords: ['千朵万朵', '压枝低'] },
          { level: '动态', content: '蝶舞莺啼', keywords: ['戏蝶', '娇莺'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_060',
    title: '蜂',
    author: '罗隐',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['咏物', '人生'],
    text: {
      original: '不论平地与山尖，无限风光尽被占。采得百花成蜜后，为谁辛苦为谁甜？',
      sentences: ['不论平地与山尖', '无限风光尽被占', '采得百花成蜜后', '为谁辛苦为谁甜'],
      rhymeScheme: ['尖', '占', '甜'],
    },
    annotations: [
      { term: '山尖', note: '山顶。' },
      { term: '尽被占', note: '全部被占据了。' },
      { term: '为谁', note: '替谁，为谁。' },
      { term: '百花', note: '各种花，形容花之多。' },
      { term: '成蜜', note: '酿成蜂蜜。' },

      { term: '为谁辛苦为谁甜', note: '为谁辛苦为谁酿蜜呢？感叹蜜蜂辛勤劳作。' }
    ],
    translation: '无论是在平地还是在山顶上，无限美好的风光全都被蜜蜂占据了。采集了百花酿成蜂蜜之后，到底是为谁辛苦为谁酿造这甜蜜呢？',
    literaryInfo: {
      authorBio: '罗隐（833年—909年），字昭谏，唐代诗人，因十次不第而改名隐。',
      background: '此诗以蜂喻人，借蜜蜂辛勤酿蜜而不知为谁辛苦的现象，表达对社会不公的感慨。',
      significance: `此诗以蜜蜂酿蜜为喻，暗喻劳动者的辛劳和不公。"不论平地与山尖，无限风光尽被占"写蜜蜂采蜜的辛勤；"采得百花成蜜后"写劳动成果——辛苦酿成甜蜜；"为谁辛苦为谁甜"以两个"为谁"的反问，揭示劳动者辛勤付出却享受不到成果的社会不公，含蓄而深刻。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '不论平地与山尖', emotion: '赞叹', intensity: 5 },
          { segment: '无限风光尽被占', emotion: '感慨', intensity: 6 },
          { segment: '采得百花成蜜后', emotion: '辛劳', intensity: 7 },
          { segment: '为谁辛苦为谁甜', emotion: '感叹', intensity: 9 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_061',
    title: '独坐敬亭山',
    author: '李白',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '人生'],
    text: {
      original: '众鸟高飞尽，孤云独去闲。相看两不厌，只有敬亭山。',
      sentences: ['众鸟高飞尽', '孤云独去闲', '相看两不厌', '只有敬亭山'],
      rhymeScheme: ['闲', '山'],
    },
    annotations: [
      { term: '敬亭山', note: '在今安徽省宣城市。' },
      { term: '尽', note: '没有了。' },
      { term: '闲', note: '悠闲，悠闲地飘去。' },
      { term: '两不厌', note: '互相看不厌烦。' },

      { term: '相看两不厌', note: '彼此对看都不觉得厌倦。形容人与山之间的默契。' }
    ],
    translation: '鸟儿们飞得不见了踪影，天上飘浮的孤云也不愿意停留，慢慢向远处飘去。只有我和敬亭山互相看着，彼此都看不够，谁能理解我这寂寞的心情呢？',
    literaryInfo: {
      authorBio: '李白（701年—762年），字太白，号青莲居士，唐代伟大的浪漫主义诗人，被后人誉为"诗仙"。',
      background: '此诗作于李白离开长安后漫游宣城时，以敬亭山为知己，寄托孤独之感。',
      significance: `"相看两不厌，只有敬亭山"以山为知己写孤独与超脱。"众鸟高飞尽"以鸟尽飞去写空寂，"孤云独去闲"以云独飘走写寥落。"相看两不厌"写出人与山的对话，互不厌倦；"只有"强调在万物皆去的孤寂中，唯有山是永恒的知己。全诗以景写情，孤独中透出傲然独立的气度。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '众鸟高飞', keywords: ['众鸟', '高飞'] },
          { level: '中景', content: '孤云独去', keywords: ['孤云', '独去'] },
          { level: '近景', content: '敬亭山相对', keywords: ['相看', '敬亭山'] },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_062',
    title: '芙蓉楼送辛渐',
    author: '王昌龄',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['送别', '人生'],
    text: {
      original: '寒雨连江夜入吴，平明送客楚山孤。洛阳亲友如相问，一片冰心在玉壶。',
      sentences: ['寒雨连江夜入吴', '平明送客楚山孤', '洛阳亲友如相问', '一片冰心在玉壶'],
      rhymeScheme: ['吴', '孤', '壶'],
    },
    annotations: [
      { term: '芙蓉楼', note: '原址在润州（今江苏镇江）。' },
      { term: '连江', note: '满江，与江面连成一片。' },
      { term: '平明', note: '天刚亮。' },
      { term: '冰心', note: '比喻纯洁的心。' },

      { term: '楚山', note: '楚地的山。指润州一带。' },
    ],
    translation: '迷蒙的冷雨连绵不断洒满吴地的江天，清晨送别友人时只剩下楚山的孤影。如果洛阳的亲友问起我的情况，就说我依然保持着玉壶中冰心般的清白操守。',
    literaryInfo: {
      authorBio: '王昌龄（698年—757年），字少伯，唐代诗人，以边塞诗著称，被誉为"七绝圣手"。',
      background: '此诗作于王昌龄被贬江宁丞时，送友人辛渐北上洛阳之际。',
      significance: `"一片冰心在玉壶"是千古名句。"寒雨连江夜入吴"以寒雨渲染离别的凄凉，"平明送客楚山孤"以山之孤映衬人之孤。"洛阳亲友如相问"以假设引出，"一片冰心在玉壶"以冰心玉壶自喻，表明虽遭贬谪依然保持清白纯洁的品格。全诗以送别写志，含蓄深沉。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '寒雨连江夜入吴', emotion: '凄冷', intensity: 6 },
          { segment: '平明送客楚山孤', emotion: '孤独', intensity: 8 },
          { segment: '洛阳亲友如相问', emotion: '关切', intensity: 7 },
          { segment: '一片冰心在玉壶', emotion: '坚贞', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_063',
    title: '塞下曲',
    author: '卢纶',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['边塞', '战争'],
    text: {
      original: '月黑雁飞高，单于夜遁逃。欲将轻骑逐，大雪满弓刀。',
      sentences: ['月黑雁飞高', '单于夜遁逃', '欲将轻骑逐', '大雪满弓刀'],
      rhymeScheme: ['高', '逃', '刀'],
    },
    annotations: [
      { term: '月黑', note: '没有月光。' },
      { term: '单于', note: '匈奴的首领，此处泛指外族首领。' },
      { term: '将', note: '率领。' },
      { term: '轻骑', note: '轻装快速的骑兵。' },

      { term: '引', note: '拉，拉开弓。' },
      { term: '平明', note: '天明，清晨。' },
      { term: '石棱', note: '石头的棱角。形容箭头嵌入石中之深。' }
    ],
    translation: '没有月光的夜晚大雁飞得很高，单于趁着夜色偷偷逃跑。正要率领轻骑兵去追击，大雪纷纷落满了弓刀。',
    literaryInfo: {
      authorBio: '卢纶（739年—799年），字允言，唐代诗人，"大历十才子"之一。',
      background: '此诗描写边塞将士月夜追击敌军的场面，气势雄壮。',
      significance: `"大雪满弓刀"以景结情，写出边塞的苦寒与将士的英勇。"月黑雁飞高"以月黑之夜、惊雁高飞渲染紧张气氛；"单于夜遁逃"点明敌军溃逃。"欲将轻骑逐"写准备追击的果敢，"大雪满弓刀"以大雪沾满武器的画面戛然而止，既是环境的严酷，也是将士不畏艰险的写照。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '月黑之夜单于逃跑，将士们冒雪追击。',
        timeline: [
          { event: '月黑之夜', order: 1 },
          { event: '雁飞高', order: 2 },
          { event: '单于夜遁逃', order: 3 },
          { event: '欲将轻骑逐', order: 4 },
          { event: '大雪满弓刀', order: 5 },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_064',
    title: '墨梅',
    author: '王冕',
    dynasty: '元',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['咏物', '人生'],
    text: {
      original: '我家洗砚池头树，朵朵花开淡墨痕。不要人夸好颜色，只留清气满乾坤。',
      sentences: ['我家洗砚池头树', '朵朵花开淡墨痕', '不要人夸好颜色', '只留清气满乾坤'],
      rhymeScheme: ['痕', '坤'],
    },
    annotations: [
      { term: '洗砚池', note: '洗毛笔的池塘。传说王羲之洗砚于此，池水尽黑。' },
      { term: '淡墨痕', note: '淡淡的墨迹，此处形容墨梅花的颜色。' },
      { term: '清气', note: '清香之气，也指清高的气节。' },
      { term: '乾坤', note: '天地之间。' },

      { term: '墨梅', note: '用水墨画的梅花。' },
    ],
    translation: '我家洗砚池边的那棵梅树，朵朵梅花开放像是淡淡的墨迹。不需要别人夸奖它的颜色好看，只愿留下清香之气充满天地之间。',
    literaryInfo: {
      authorBio: '王冕（1287年—1359年），字元章，号煮石山农，元代画家、诗人，以画梅著称。',
      background: '此诗为题画诗，王冕在自画的墨梅图上题此诗，以梅自喻。',
      significance: `"不要人夸好颜色，只留清气满乾坤"是千古名句。此诗为题画诗，"吾家洗砚池头树"以王羲之洗砚池典故起笔，"朵朵花开淡墨痕"写墨梅不用色彩而用墨色的淡雅脱俗。"不要人夸好颜色"表明不求外在华美，"只留清气满乾坤"以"清气"喻高洁品格，不求人夸但求品格流传天地之间。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '我家洗砚池头树', emotion: '平淡', intensity: 4 },
          { segment: '朵朵花开淡墨痕', emotion: '欣赏', intensity: 5 },
          { segment: '不要人夸好颜色', emotion: '超脱', intensity: 7 },
          { segment: '只留清气满乾坤', emotion: '高洁', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 2 },
  },
  // ===== 五年级上册 =====
  {
    id: 'p_065',
    title: '蝉',
    author: '虞世南',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['咏物', '哲理'],
    text: {
      original: '垂緌饮清露，流响出疏桐。居高声自远，非是藉秋风。',
      sentences: ['垂緌饮清露', '流响出疏桐', '居高声自远', '非是藉秋风'],
      rhymeScheme: ['桐', '风'],
    },
    annotations: [
      { term: '緌', note: '古人结在颔下的帽带下垂部分，蝉的头部有触须似帽带。' },
      { term: '清露', note: '清纯的露水。' },
      { term: '疏桐', note: '稀疏的梧桐树。' },
      { term: '藉', note: '凭借，依靠。' },

      { term: '缫丝', note: '从蚕茧中抽丝。' },
      { term: '乞巧', note: '七夕节祈求心灵手巧的习俗。' }
    ],
    translation: '蝉垂下触须饮用清纯的露水，响亮的鸣叫声从稀疏的梧桐树间传出。它身居高处声音自然传得很远，并不是借了秋风的助力。',
    literaryInfo: {
      authorBio: '虞世南（558年—638年），字伯施，唐代书法家、诗人，凌烟阁二十四功臣之一。',
      background: '此诗为咏蝉之作，以蝉的高洁品格寄托自己的志向。',
      significance: `"居高声自远，非是藉秋风"是千古名句。此诗以蝉喻人——蝉声远播不是因为借助秋风，而是因为身处高处。寓意品格高洁者自然声名远播，不必借助外力。"居高"是品格的高度，"声自远"是影响力，"非是藉"强调内在修为而非外在依凭。全诗托物言志，以蝉喻人，含蓄而深刻。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '垂緌饮清露', emotion: '高洁', intensity: 6 },
          { segment: '流响出疏桐', emotion: '清越', intensity: 7 },
          { segment: '居高声自远', emotion: '自豪', intensity: 8 },
          { segment: '非是藉秋风', emotion: '坚定', intensity: 9 },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_066',
    title: '乞巧',
    author: '林杰',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['节日', '人生'],
    text: {
      original: '七夕今宵看碧霄，牵牛织女渡河桥。家家乞巧望秋月，穿尽红丝几万条。',
      sentences: ['七夕今宵看碧霄', '牵牛织女渡河桥', '家家乞巧望秋月', '穿尽红丝几万条'],
      rhymeScheme: ['霄', '桥', '条'],
    },
    annotations: [
      { term: '乞巧', note: '七夕节的传统习俗，女子在月下穿针引线，祈求心灵手巧。' },
      { term: '碧霄', note: '碧蓝的天空。' },
      { term: '牵牛织女', note: '牛郎星和织女星，神话传说中每年七夕在鹊桥相会。' },
      { term: '渡河桥', note: '指渡过银河上的鹊桥。' },

      { term: '九州同', note: '全国统一。九州，代指中国。' },
      { term: '乃翁', note: '你们的父亲。乃，你的。翁，父亲。' }
    ],
    translation: '七夕的夜晚仰望碧蓝的天空，仿佛看见牛郎织女在银河鹊桥上相会。家家户户都在对着秋月穿针乞巧，穿过的红线不知有几万条。',
    literaryInfo: {
      authorBio: '林杰（831年—847年），字智周，唐代诗人，少年才子，年仅十六岁便去世。',
      background: '此诗描写七夕节民间乞巧的习俗，展现了节日的热闹景象。',
      significance: `此诗以简洁的语言描绘了七夕乞巧的风俗。"七夕今宵看碧霄"点明时间，仰望星空；"牵牛织女渡河桥"写牛郎织女鹊桥相会的传说。"家家乞巧望秋月"写民间乞巧的盛况，"穿尽红丝几万条"以"几万条"的夸张写出参与乞巧的人数之多、愿望之切。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '天景', content: '碧霄星河', keywords: ['碧霄', '牵牛织女'] },
          { level: '人间', content: '家家乞巧', keywords: ['乞巧', '秋月'] },
          { level: '细节', content: '红丝万条', keywords: ['红丝', '几万条'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_067',
    title: '示儿',
    author: '陆游',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['爱国'],
    text: {
      original: '死去元知万事空，但悲不见九州同。王师北定中原日，家祭无忘告乃翁。',
      sentences: ['死去元知万事空', '但悲不见九州同', '王师北定中原日', '家祭无忘告乃翁'],
      rhymeScheme: ['空', '同', '翁'],
    },
    annotations: [
      { term: '示儿', note: '给儿子看。示，给……看。' },
      { term: '元知', note: '本来就知道。元，同"原"。' },
      { term: '九州同', note: '全国统一。九州，代指中国。' },
      { term: '乃翁', note: '你们的父亲，指陆游自己。' },

      { term: '空', note: '白白地，徒然。' }
    ],
    translation: '本来就知道人死后万事皆空，只是悲伤看不到国家的统一。当朝廷军队收复中原那一天，在家祭时别忘了告诉你们的父亲这个好消息。',
    literaryInfo: {
      authorBio: '陆游（1125年—1210年），字务观，号放翁，南宋伟大的爱国诗人。',
      background: '此诗为陆游临终前写给儿子的遗诗，表达了至死不忘国家统一的深切感情。',
      significance: `此诗是千古传诵的爱国名篇。"死去元知万事空"以死写起，看似旷达；"但悲不见九州同"以"但悲"转折，至死不忘国家统一。"王师北定中原日"以假设写对未来的期盼，"家祭无忘告乃翁"以嘱咐写对后人的期待。全诗以死写生，以悲写壮，爱国之情至死不渝。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '死去元知万事空', emotion: '坦然', intensity: 4 },
          { segment: '但悲不见九州同', emotion: '悲痛', intensity: 9 },
          { segment: '王师北定中原日', emotion: '期盼', intensity: 8 },
          { segment: '家祭无忘告乃翁', emotion: '叮嘱', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_068',
    title: '题临安邸',
    author: '林升',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['爱国', '咏史'],
    text: {
      original: '山外青山楼外楼，西湖歌舞几时休？暖风熏得游人醉，直把杭州作汴州。',
      sentences: ['山外青山楼外楼', '西湖歌舞几时休', '暖风熏得游人醉', '直把杭州作汴州'],
      rhymeScheme: ['楼', '休', '州'],
    },
    annotations: [
      { term: '临安', note: '南宋都城，今浙江省杭州市。' },
      { term: '邸', note: '旅店。' },
      { term: '暖风', note: '温暖的春风，也暗指歌舞之风。' },
      { term: '汴州', note: '北宋都城，今河南省开封市。' },

      { term: '游人', note: '指权贵们。醉生梦死的达官贵人。' },
      { term: '直把', note: '简直把。直，简直。' }
    ],
    translation: '青山之外还有青山，高楼之外还有高楼，西湖上的歌舞什么时候才能停歇？暖洋洋的春风把游人们吹得醉醺醺的，简直把杭州当成了故都汴州。',
    literaryInfo: {
      authorBio: '林升，南宋诗人，生卒年不详，字梦屏，平阳（今属浙江）人。',
      background: '此诗讽刺南宋统治者偏安江南、沉迷享乐、不思收复失地的行径。',
      significance: `此诗以讽刺的手法揭露南宋统治者的荒淫误国。"山外青山楼外楼"写杭州山水之美，暗含讽刺——统治者沉溺享乐；"西湖歌舞几时休"直斥沉迷歌舞。"暖风熏得游人醉"以"熏"与"醉"写被安逸迷惑，"直把杭州作汴州"是点睛之笔——把临时避难的杭州当作了故都汴州，讽刺深刻而沉痛。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '山外青山楼外楼', emotion: '感叹', intensity: 5 },
          { segment: '西湖歌舞几时休', emotion: '愤慨', intensity: 7 },
          { segment: '暖风熏得游人醉', emotion: '讽刺', intensity: 8 },
          { segment: '直把杭州作汴州', emotion: '怒斥', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_069',
    title: '己亥杂诗',
    author: '龚自珍',
    dynasty: '清',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['爱国', '哲理'],
    text: {
      original: '九州生气恃风雷，万马齐喑究可哀。我劝天公重抖擞，不拘一格降人才。',
      sentences: ['九州生气恃风雷', '万马齐喑究可哀', '我劝天公重抖擞', '不拘一格降人才'],
      rhymeScheme: ['雷', '哀', '才'],
    },
    annotations: [
      { term: '九州', note: '中国。' },
      { term: '恃', note: '依靠。' },
      { term: '万马齐喑', note: '比喻人们沉默不敢发声。喑，哑。' },
      { term: '不拘一格', note: '不限定一种方式，指打破常规选拔人才。' },

      { term: '浩荡', note: '广大无边的样子。' },
      { term: '吟鞭', note: '诗人的马鞭。吟，吟诗。' },
      { term: '落红', note: '落花。红，代指花。' }
    ],
    translation: '中国要恢复生气必须依靠风雷般的变革，万马齐喑的局面实在令人悲哀。我劝老天爷重新振作精神，不要拘泥于常规来选拔和降生人才。',
    literaryInfo: {
      authorBio: '龚自珍（1792年—1841年），字璱人，号定庵，清代思想家、文学家，近代改良主义的先驱。',
      background: '此诗作于己亥年（1839年），龚自珍辞官南归途中，共写315首，此为其中一首。',
      significance: `"我劝天公重抖擞，不拘一格降人才"是千古名句。"九州生气恃风雷"以风雷比喻变革的力量，"万马齐喑究可哀"写社会沉闷压抑的现状。"我劝天公重抖擞"以对天的劝告表达对变革的渴望，"不拘一格降人才"强调要打破成规、选拔各种人才。全诗以自然现象比喻社会现实，表达了渴望变革、渴望人才的强烈愿望。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '九州生气恃风雷', emotion: '渴望', intensity: 7 },
          { segment: '万马齐喑究可哀', emotion: '悲哀', intensity: 8 },
          { segment: '我劝天公重抖擞', emotion: '激昂', intensity: 9 },
          { segment: '不拘一格降人才', emotion: '期盼', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_070',
    title: '山居秋暝',
    author: '王维',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '田园'],
    text: {
      original: '空山新雨后，天气晚来秋。明月松间照，清泉石上流。竹喧归浣女，莲动下渔舟。随意春芳歇，王孙自可留。',
      sentences: ['空山新雨后', '天气晚来秋', '明月松间照', '清泉石上流', '竹喧归浣女', '莲动下渔舟', '随意春芳歇', '王孙自可留'],
      rhymeScheme: ['秋', '流', '舟', '留'],
    },
    annotations: [
      { term: '暝', note: '日落时分，天色将晚。' },
      { term: '竹喧', note: '竹林中传来喧闹声。' },
      { term: '浣女', note: '洗衣服的女子。浣，洗。' },
      { term: '王孙', note: '原指贵族子弟，此处指诗人自己。' },

      { term: '空山', note: '空旷的山林。空，幽静无人。' },
      { term: '新雨后', note: '刚下过雨之后。' },
    ],
    translation: '空旷的山中刚下过一场雨，傍晚的天气格外凉爽。明月的光辉透过松林洒落，清澈的泉水在石头上淙淙流淌。竹林中传来喧闹声是洗衣服的女子归来，荷叶摇动是渔船顺流而下。任凭春天的芳花凋谢，这秋天的山居也足以让王孙留恋。',
    literaryInfo: {
      authorBio: '王维（701年—761年），字摩诘，唐代诗人、画家，有"诗佛"之称。',
      background: '此诗描写秋天雨后山村的傍晚景色，表达了诗人对隐居生活的喜爱。',
      significance: `"明月松间照，清泉石上流"是千古写景名句。"空山新雨后"以空山新雨的清新起笔，"天气晚来秋"点明季节。"明月松间照"以月光穿松写静，"清泉石上流"以泉水击石写动，动静相映。"竹喧归浣女，莲动下渔舟"写人事的和谐，"随意春芳歇，王孙自可留"以反用典故表达归隐之意，诗中有画，画中有诗。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '空山新雨，秋意初来', keywords: ['空山', '新雨'] },
          { level: '中景', content: '明月松间照', keywords: ['明月', '松间'] },
          { level: '近景', content: '清泉石上流', keywords: ['清泉', '石上'] },
          { level: '动态', content: '浣女归渔舟下', keywords: ['浣女', '渔舟'] },
        ],
      },
    },
    stats: { charCount: 40, sentenceCount: 8, rhymeCount: 4 },
  },
  {
    id: 'p_071',
    title: '枫桥夜泊',
    author: '张继',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['思乡', '山水'],
    text: {
      original: '月落乌啼霜满天，江枫渔火对愁眠。姑苏城外寒山寺，夜半钟声到客船。',
      sentences: ['月落乌啼霜满天', '江枫渔火对愁眠', '姑苏城外寒山寺', '夜半钟声到客船'],
      rhymeScheme: ['天', '眠', '船'],
    },
    annotations: [
      { term: '枫桥', note: '在今江苏省苏州市西郊。' },
      { term: '乌啼', note: '乌鸦的啼叫。' },
      { term: '姑苏', note: '苏州的别称。' },
      { term: '寒山寺', note: '在枫桥附近，因唐代僧人寒山曾在此居住而得名。' },

      { term: '霜满天', note: '寒霜满天的深秋夜。' },
      { term: '对愁眠', note: '面对愁绪难以入眠。' },
    ],
    translation: '月亮落下去了，乌鸦啼叫着，天地间霜华满布，面对着江边的枫树和渔火，满怀愁绪难以入眠。半夜时分，姑苏城外寒山寺的钟声传到了这客船上。',
    literaryInfo: {
      authorBio: '张继，唐代诗人，生卒年不详，字懿孙，襄州（今湖北襄阳）人。',
      background: '安史之乱后，张继途经苏州，夜泊枫桥，写下此诗。',
      significance: `此诗以夜半钟声衬托游子的愁思。"月落乌啼霜满天"以月落、乌啼、霜寒三种意象营造凄清氛围，"江枫渔火对愁眠"以明暗对比映衬旅人不眠。"姑苏城外寒山寺，夜半钟声到客船"以夜半钟声打破寂静，钟声入耳更添愁绪。全诗以声写静、以景写情，意境深远。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '月落霜满天', keywords: ['月落', '霜满天'] },
          { level: '中景', content: '江枫渔火', keywords: ['江枫', '渔火'] },
          { level: '近景', content: '寒山寺钟声', keywords: ['寒山寺', '钟声'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_072',
    title: '长相思',
    author: '纳兰性德',
    dynasty: '清',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '词' },
    themes: ['思乡', '山水'],
    text: {
      original: `山一程，水一程，身向榆关那畔行，夜深千帐灯。风一更，雪一更，聒碎乡心梦不成，故园无此声。`,
      sentences: ['山一程，水一程', '身向榆关那畔行', '夜深千帐灯', '风一更，雪一更', '聒碎乡心梦不成', '故园无此声'],
    },
    annotations: [
      { term: '长相思', note: '词牌名。' },
      { term: '榆关', note: '山海关。' },
      { term: '那畔', note: '那边，此处指关外。' },
      { term: '聒', note: '声音嘈杂，使人厌烦。' },

      { term: '山一程', note: '翻越一座山。程，路程，行程。' },
      { term: '千帐灯', note: '千顶帐篷灯火通明。形容行军规模宏大。' },
      { term: '故园', note: '故乡。' }
    ],
    translation: '翻过一座座山，涉过一道道水，向着山海关那边行进，夜深时分千万个营帐中灯火通明。风刮了一更又一夜，雪下了一更又一夜，风雪声搅碎了思乡的心，连梦也做不成，故乡可没有这样的声音。',
    literaryInfo: {
      authorBio: '纳兰性德（1655年—1685年），字容若，号楞伽山人，清代词人，被誉为"清初第一词人"。',
      background: '此词作于康熙二十一年，纳兰性德随康熙帝出关东巡途中，风雪交加之夜思乡而作。',
      significance: `此词以质朴的语言写行役思乡之苦。"山一程，水一程"以叠字写出路途遥远艰辛；"夜深千帐灯"以壮观的军营夜景反衬个人孤独。"风一更，雪一更"以叠字写风雪不停；"聒碎乡心梦不成"以风雪声搅碎思乡之梦；"故园无此声"以对比收束——故园宁静，此地风雪，思乡之情溢于言表。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '山一程，水一程', emotion: '艰辛', intensity: 6 },
          { segment: '身向榆关那畔行', emotion: '远行', intensity: 5 },
          { segment: '夜深千帐灯', emotion: '孤寂', intensity: 7 },
          { segment: '风一更，雪一更', emotion: '苦寒', intensity: 8 },
          { segment: '聒碎乡心梦不成', emotion: '思念', intensity: 9 },
          { segment: '故园无此声', emotion: '伤感', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 36, sentenceCount: 6, rhymeCount: 0 },
  },
  {
    id: 'p_073',
    title: '渔歌子',
    author: '张志和',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '词' },
    themes: ['山水', '田园'],
    text: {
      original: '西塞山前白鹭飞，桃花流水鳜鱼肥。青箬笠，绿蓑衣，斜风细雨不须归。',
      sentences: ['西塞山前白鹭飞', '桃花流水鳜鱼肥', '青箬笠，绿蓑衣', '斜风细雨不须归'],
      rhymeScheme: ['飞', '肥', '归'],
    },
    annotations: [
      { term: '西塞山', note: '在今浙江省湖州市。' },
      { term: '鳜鱼', note: '一种淡水鱼，味道鲜美。' },
      { term: '箬笠', note: '用竹篾和箬叶编成的斗笠。' },
      { term: '不须归', note: '不想回家。' },

      { term: '蓑衣', note: '用草或棕编的雨衣。' },
    ],
    translation: '西塞山前白鹭在自由地飞翔，桃花盛开，江水初涨，水中鳜鱼正肥美。渔翁戴着青色的斗笠，披着绿色的蓑衣，在斜风细雨中垂钓，不想回家。',
    literaryInfo: {
      authorBio: '张志和（732年—774年），字子同，初名龟龄，唐代诗人，自号"烟波钓徒"。',
      background: '此词描写江南水乡春汛时的景致和渔翁的闲适生活。',
      significance: `此词以鲜明的色彩和生动的画面展现了江南春景。"西塞山前白鹭飞"写空中白鹭，"桃花流水鳜鱼肥"写水中花鱼，色彩鲜明。"青箬笠，绿蓑衣"写渔翁装束与自然色调融为一体，"斜风细雨不须归"以"不须归"写出渔翁的自在——在风雨中垂钓不愿归去，正是对隐逸生活的享受。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '西塞山白鹭飞', keywords: ['西塞山', '白鹭'] },
          { level: '中景', content: '桃花流水鳜鱼', keywords: ['桃花', '鳜鱼'] },
          { level: '近景', content: '箬笠蓑衣渔翁', keywords: ['箬笠', '蓑衣'] },
        ],
      },
    },
    stats: { charCount: 27, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_074',
    title: '观书有感（其一）',
    author: '朱熹',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['哲理'],
    text: {
      original: '半亩方塘一鉴开，天光云影共徘徊。问渠那得清如许？为有源头活水来。',
      sentences: ['半亩方塘一鉴开', '天光云影共徘徊', '问渠那得清如许', '为有源头活水来'],
      rhymeScheme: ['开', '徊', '来'],
    },
    annotations: [
      { term: '鉴', note: '镜子。' },
      { term: '徘徊', note: '来回移动。' },
      { term: '渠', note: '它，指方塘。' },
      { term: '清如许', note: '这样清澈。' },

      { term: '如许', note: '如此，这样。' }
    ],
    translation: '半亩大的方形池塘像一面打开的镜子，天空的光彩和浮云的影子都在水面闪耀浮动。要问池塘里的水为何这样清澈？因为有源源不断的活水从源头流来。',
    literaryInfo: {
      authorBio: '朱熹（1130年—1200年），字元晦，号晦庵，南宋理学家、教育家、诗人，理学集大成者。',
      background: '此诗借景喻理，以方塘清澈比喻读书明理的心境。',
      significance: `"问渠那得清如许？为有源头活水来"是千古名句。"半亩方塘一鉴开"以镜喻塘的清澈，"天光云影共徘徊"写水中天光云影的美景。"问渠那得清如许"设问——池水为何如此清澈？"为有源头活水来"作答——因为有源头活水不断注入。比喻学习要不断汲取新知识，才能保持思想的活力。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '全景', content: '半亩方塘如镜', keywords: ['方塘', '一鉴开'] },
          { level: '倒影', content: '天光云影徘徊', keywords: ['天光', '云影'] },
          { level: '哲理', content: '源头活水', keywords: ['源头', '活水'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_075',
    title: '观书有感（其二）',
    author: '朱熹',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['哲理'],
    text: {
      original: '昨夜江边春水生，蒙冲巨舰一毛轻。向来枉费推移力，此日中流自在行。',
      sentences: ['昨夜江边春水生', '蒙冲巨舰一毛轻', '向来枉费推移力', '此日中流自在行'],
      rhymeScheme: ['生', '轻', '行'],
    },
    annotations: [
      { term: '蒙冲', note: '古代的一种战船。' },
      { term: '一毛轻', note: '像一根羽毛一样轻。' },
      { term: '向来', note: '从前，以前。' },
      { term: '中流', note: '江心。' },

    ],
    translation: '昨天夜里江边春水猛涨，巨大的战船像一根羽毛一样轻盈。从前推拉它白费了多少力气，今天它却能在江心自由自在地航行。',
    literaryInfo: {
      authorBio: '朱熹（1130年—1200年），字元晦，号晦庵，南宋理学家、教育家、诗人，理学集大成者。',
      background: '此诗与第一首为姊妹篇，以春水行船比喻读书的感悟。',
      significance: `此诗以水涨船行比喻读书积累到一定程度后豁然贯通。"昨夜江边春水生"写水涨的条件——春水上涨；"蒙冲巨舰一毛轻"写结果——大船变得像羽毛一样轻。"向来枉费推移力"写此前搁浅时费尽力气也无法移动，"此日中流自在行"写水涨后船行自如。全诗强调厚积薄发——条件成熟后自然水到渠成。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '春水上涨后大船自由航行，比喻读书积累后豁然贯通。',
        timeline: [
          { event: '江边枯水期', order: 1 },
          { event: '昨夜春水生', order: 2 },
          { event: '巨舰如一毛轻', order: 3 },
          { event: '向来枉费推移力', order: 4 },
          { event: '此日中流自在行', order: 5 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  // ===== 五年级下册 =====
  {
    id: 'p_076',
    title: '四时田园杂兴（其三十一）',
    author: '范成大',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['田园'],
    text: {
      original: '昼出耘田夜绩麻，村庄儿女各当家。童孙未解供耕织，也傍桑阴学种瓜。',
      sentences: ['昼出耘田夜绩麻', '村庄儿女各当家', '童孙未解供耕织', '也傍桑阴学种瓜'],
      rhymeScheme: ['麻', '家', '瓜'],
    },
    annotations: [
      { term: '耘田', note: '在田间除草。' },
      { term: '绩麻', note: '搓麻线。' },
      { term: '各当家', note: '各自担当一定的家庭劳动。' },
      { term: '未解', note: '不懂，不会。' },

      { term: '昼', note: '白天。' },
      { term: '供耕织', note: '从事耕田织布。供，从事。' },
      { term: '桑阴', note: '桑树荫下。' }
    ],
    translation: '白天出去锄草，夜里搓麻线，村庄里的男男女女各自操持家务。小孙子虽然还不懂得耕田织布，也在桑树荫下学着种瓜。',
    literaryInfo: {
      authorBio: '范成大（1126年—1193年），字致能，号石湖居士，南宋诗人，与陆游、杨万里、尤袤合称"南宋四家"。',
      background: '此诗描写初夏时节农村的繁忙景象，表现了农家生活的乐趣。',
      significance: '此诗以儿童学种瓜的细节增添了田园生活的情趣，是描写农村生活的名篇。',
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '劳作', content: '昼耘田夜绩麻', keywords: ['耘田', '绩麻'] },
          { level: '分工', content: '男女各当家', keywords: ['儿女', '当家'] },
          { level: '童趣', content: '学种瓜', keywords: ['童孙', '种瓜'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_077',
    title: '稚子弄冰',
    author: '杨万里',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['咏物', '田园'],
    text: {
      original: '稚子金盆脱晓冰，彩丝穿取当银铮。敲成玉磬穿林响，忽作玻璃碎地声。',
      sentences: ['稚子金盆脱晓冰', '彩丝穿取当银铮', '敲成玉磬穿林响', '忽作玻璃碎地声'],
      rhymeScheme: ['冰', '铮', '声'],
    },
    annotations: [
      { term: '稚子', note: '小孩子。' },
      { term: '脱晓冰', note: '清晨从铜盆中取出冰块。' },
      { term: '银铮', note: '银色的锣。铮，古代打击乐器。' },
      { term: '玉磬', note: '古代用玉做的打击乐器。' },

      { term: '脱冰', note: '从冰中脱出。小孩将冰块从盆中取出。' },
      { term: '玻璃', note: '古代指天然水晶或透明玉石。这里形容冰块透明。' }
    ],
    translation: '小孩子清晨从铜盆中取出冰块，用彩色的丝线穿起来当作银锣。敲击它发出玉磬般清越的声响穿过树林，忽然冰块掉在地上发出玻璃碎裂般的声响。',
    literaryInfo: {
      authorBio: '杨万里（1127年—1206年），字廷秀，号诚斋，南宋诗人，"南宋四家"之一。',
      background: '此诗描写冬日儿童玩冰的趣事，生动活泼。',
      significance: `此诗捕捉了儿童玩冰的完整过程，从取冰到穿冰、敲冰、碎冰，生动传神。"金盆脱晓冰"写出取冰的仔细，"彩丝穿取当银铮"写出儿童的天真想象，"敲成玉磬穿林响"以声喻声写出冰声的清越，"忽作玻璃碎地声"一个"忽"字写出意外与遗憾。全诗以冰的清脆声响贯穿，从"银铮"到"玉磬"到"玻璃碎"，声音由好听到碎裂，充满童趣又暗含对美好事物易逝的惋惜。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '稚子清晨取冰，穿丝敲击，最后冰碎。',
        timeline: [
          { event: '稚子金盆取冰', order: 1 },
          { event: '彩丝穿取当银铮', order: 2 },
          { event: '敲成玉磬穿林响', order: 3 },
          { event: '冰忽碎落', order: 4 },
          { event: '玻璃碎地声', order: 5 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_078',
    title: '村晚',
    author: '雷震',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['田园'],
    text: {
      original: '草满池塘水满陂，山衔落日浸寒漪。牧童归去横牛背，短笛无腔信口吹。',
      sentences: ['草满池塘水满陂', '山衔落日浸寒漪', '牧童归去横牛背', '短笛无腔信口吹'],
      rhymeScheme: ['陂', '漪', '吹'],
    },
    annotations: [
      { term: '陂', note: '池塘的岸。' },
      { term: '山衔', note: '山好像含着落日。衔，含在口中。' },
      { term: '漪', note: '水波。' },
      { term: '无腔', note: '没有曲调。' },

      { term: '衔', note: '含在口中。比喻落日被山头含住。' },
      { term: '短笛无腔信口吹', note: '吹短笛没有曲调随便吹奏。腔，曲调。信口，随口。' }
    ],
    translation: '绿草长满了池塘，水也涨满了池岸，远山好像含着落日，倒映在清凉的水波中。牧童横坐在牛背上回家，随意吹着没有曲调的短笛。',
    literaryInfo: {
      authorBio: '雷震，南宋诗人，生卒年不详，眉州（今四川眉山）人。',
      background: '此诗描写乡村傍晚的优美景色和牧童的悠闲生活。',
      significance: '此诗以优美的画面描绘了村晚景色，"牧童归去横牛背，短笛无腔信口吹"生动展现了牧童的悠闲自在。',
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '山衔落日', keywords: ['山衔', '落日'] },
          { level: '中景', content: '草满池塘', keywords: ['草满', '水满'] },
          { level: '近景', content: '牧童横牛背', keywords: ['牧童', '横牛背'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_079',
    title: '游子吟',
    author: '孟郊',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '古体诗' },
    themes: ['思乡', '人生'],
    text: {
      original: '慈母手中线，游子身上衣。临行密密缝，意恐迟迟归。谁言寸草心，报得三春晖。',
      sentences: ['慈母手中线', '游子身上衣', '临行密密缝', '意恐迟迟归', '谁言寸草心', '报得三春晖'],
      rhymeScheme: ['衣', '归', '晖'],
    },
    annotations: [
      { term: '游子', note: '离家远行的人。' },
      { term: '意恐', note: '担心。' },
      { term: '寸草心', note: '小草的嫩心，比喻子女微薄的心意。' },
      { term: '三春晖', note: '春天温暖的阳光，比喻母爱。' },

    ],
    translation: '慈爱的母亲手里拿着针线，为将要远行的儿子赶制衣衫。临行前一针一线密密缝好，担心的是儿子迟迟不能回来。谁说像小草那样微弱的孝心，能报答得了像春晖般广博的母爱呢？',
    literaryInfo: {
      authorBio: '孟郊（751年—814年），字东野，唐代诗人，以苦吟著称，与贾岛合称"郊寒岛瘦"。',
      background: '此诗为孟郊出任溧阳县尉前所作，回忆母亲为自己缝衣的情景。',
      significance: `"谁言寸草心，报得三春晖"是歌颂母爱的千古名句。"慈母手中线，游子身上衣"以针线写母爱的细密，"临行密密缝"以"密密"写母亲一针一线的不舍，"意恐迟迟归"写母亲的担忧。"寸草心"与"三春晖"的对比——小草的微弱之心怎能报答春天的阳光？以极端的悬殊写出母爱的伟大和无法回报的感慨。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '慈母手中线', emotion: '温馨', intensity: 5 },
          { segment: '游子身上衣', emotion: '关爱', intensity: 6 },
          { segment: '临行密密缝', emotion: '不舍', intensity: 8 },
          { segment: '意恐迟迟归', emotion: '担忧', intensity: 9 },
          { segment: '谁言寸草心', emotion: '感慨', intensity: 8 },
          { segment: '报得三春晖', emotion: '感恩', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 30, sentenceCount: 6, rhymeCount: 3 },
  },
  {
    id: 'p_080',
    title: '鸟鸣涧',
    author: '王维',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水'],
    text: {
      original: '人闲桂花落，夜静春山空。月出惊山鸟，时鸣春涧中。',
      sentences: ['人闲桂花落', '夜静春山空', '月出惊山鸟', '时鸣春涧中'],
      rhymeScheme: ['空', '中'],
    },
    annotations: [
      { term: '涧', note: '山间流水的小沟。' },
      { term: '人闲', note: '人心悠闲。' },
      { term: '惊', note: '惊动。' },
      { term: '时鸣', note: '不时地鸣叫。' },

      { term: '春涧', note: '春天的山涧。以动衬静的手法。' }
    ],
    translation: '人心悠闲桂花悄然飘落，夜晚寂静春天的山谷空旷无人。明月升起惊动了山中的鸟儿，它们不时在春天的溪涧中鸣叫。',
    literaryInfo: {
      authorBio: '王维（701年—761年），字摩诘，唐代诗人、画家，有"诗佛"之称。',
      background: '此诗描写春夜山间的静谧景象，以花落和鸟鸣衬托山涧的幽静。',
      significance: `此诗以动写静，以鸟鸣涧之动衬托春山之静。"人闲桂花落"以花落之微声写出极静的环境，"夜静春山空"直写春山的空寂。"月出惊山鸟"以月光惊动山鸟写出夜的静谧被轻微打破，"时鸣春涧中"以鸟鸣回荡在涧中反衬出更深的寂静。全诗体现了"蝉噪林逾静，鸟鸣山更幽"的审美境界。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '近景', content: '桂花飘落', keywords: ['桂花', '人闲'] },
          { level: '远景', content: '春山空旷', keywords: ['夜静', '春山'] },
          { level: '动态', content: '月出鸟鸣', keywords: ['月出', '山鸟'] },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_081',
    title: '从军行',
    author: '王昌龄',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['边塞', '爱国'],
    text: {
      original: '青海长云暗雪山，孤城遥望玉门关。黄沙百战穿金甲，不破楼兰终不还。',
      sentences: ['青海长云暗雪山', '孤城遥望玉门关', '黄沙百战穿金甲', '不破楼兰终不还'],
      rhymeScheme: ['山', '关', '还'],
    },
    annotations: [
      { term: '青海', note: '青海湖。' },
      { term: '穿', note: '磨破。' },
      { term: '金甲', note: '铠甲。' },
      { term: '楼兰', note: '汉代西域国名，此处借指外族入侵者。' },

      { term: '孤城', note: '孤立的城。指玉门关。' },
      { term: '百战', note: '身经百战。形容战争频繁。' }
    ],
    translation: '青海湖上空的长云遮蔽了雪山，孤城遥遥望着玉门关。黄沙漫天身经百战磨穿了金甲，不击败敌人绝不返回故乡。',
    literaryInfo: {
      authorBio: '王昌龄（698年—757年），字少伯，唐代诗人，以边塞诗著称，被誉为"七绝圣手"。',
      background: '此诗描写边塞将士的艰苦生活和誓死卫国的决心。',
      significance: `"黄沙百战穿金甲，不破楼兰终不还"是千古名句。"青海长云暗雪山"以暗色调写边塞的苍凉，"孤城遥望玉门关"写戍边将士的孤独。"黄沙百战"写战斗的频繁和艰苦，"穿金甲"写铠甲被磨穿，"不破楼兰终不还"以誓言写出将士保家卫国的坚定决心，豪壮之中透出悲壮。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '青海长云暗雪山', emotion: '苍凉', intensity: 7 },
          { segment: '孤城遥望玉门关', emotion: '孤独', intensity: 6 },
          { segment: '黄沙百战穿金甲', emotion: '艰辛', intensity: 8 },
          { segment: '不破楼兰终不还', emotion: '壮烈', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_082',
    title: '秋夜将晓出篱门迎凉有感',
    author: '陆游',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['爱国'],
    text: {
      original: '三万里河东入海，五千仞岳上摩天。遗民泪尽胡尘里，南望王师又一年。',
      sentences: ['三万里河东入海', '五千仞岳上摩天', '遗民泪尽胡尘里', '南望王师又一年'],
      rhymeScheme: ['天', '年'],
    },
    annotations: [
      { term: '三万里河', note: '指黄河，三万里形容其长。' },
      { term: '五千仞岳', note: '指华山，五千仞形容其高。仞，古代长度单位。' },
      { term: '遗民', note: '沦陷区的人民。' },
      { term: '王师', note: '朝廷的军队。' },

      { term: '南望王师', note: '向南盼望朝廷的军队来收复失地。' }
    ],
    translation: '三万里长的黄河向东流入大海，五千仞高的华山直冲云霄。沦陷区的人民在金人统治下眼泪都哭干了，他们盼望南宋朝廷的军队北伐又一年了。',
    literaryInfo: {
      authorBio: '陆游（1125年—1210年），字务观，号放翁，南宋伟大的爱国诗人。',
      background: '此诗作于陆游晚年闲居山阴时，对沦陷区人民的深切同情和对朝廷不思北伐的失望。',
      significance: `"遗民泪尽胡尘里，南望王师又一年"是千古名句。"三万里河东入海"写黄河的磅礴，"五千仞岳上摩天"写华山的巍峨，以壮阔山河反衬沦陷区的悲剧。"遗民泪尽"写百姓眼泪流干，"胡尘里"写在敌人铁蹄之下，"南望王师又一年"以"又一年"写出年年盼望年年落空的绝望，深刻表达了对南宋朝廷的失望。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '三万里河东入海', emotion: '壮阔', intensity: 7 },
          { segment: '五千仞岳上摩天', emotion: '雄伟', intensity: 7 },
          { segment: '遗民泪尽胡尘里', emotion: '悲痛', intensity: 9 },
          { segment: '南望王师又一年', emotion: '失望', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_083',
    title: '闻官军收河南河北',
    author: '杜甫',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['爱国', '人生'],
    text: {
      original: '剑外忽传收蓟北，初闻涕泪满衣裳。却看妻子愁何在，漫卷诗书喜欲狂。白日放歌须纵酒，青春作伴好还乡。即从巴峡穿巫峡，便下襄阳向洛阳。',
      sentences: ['剑外忽传收蓟北', '初闻涕泪满衣裳', '却看妻子愁何在', '漫卷诗书喜欲狂', '白日放歌须纵酒', '青春作伴好还乡', '即从巴峡穿巫峡', '便下襄阳向洛阳'],
      rhymeScheme: ['裳', '狂', '乡', '阳'],
    },
    annotations: [
      { term: '剑外', note: '剑门关以南，指四川。' },
      { term: '蓟北', note: '今河北北部地区，安史叛军的根据地。' },
      { term: '漫卷', note: '胡乱卷起，形容喜极失态。' },
      { term: '青春', note: '明媚的春天。' },

      { term: '涕泪', note: '眼泪。涕，眼泪。喜极而泣。' },
      { term: '却看', note: '回头看。却，回转。' },
      { term: '放歌', note: '放声高歌。' },
      { term: '纵酒', note: '开怀畅饮。' }
    ],
    translation: '剑门关外忽然传来收复蓟北的消息，初听到时泪水沾满了衣裳。回头看妻子儿女哪里还有愁容，胡乱卷起诗书高兴得简直要发狂。白天放声歌唱还要痛饮美酒，趁着明媚的春光正好回乡。立刻从巴峡穿过巫峡，再顺流而下经襄阳奔向洛阳。',
    literaryInfo: {
      authorBio: '杜甫（712年—770年），字子美，自号少陵野老，唐代伟大的现实主义诗人，被后人誉为"诗圣"。',
      background: '此诗作于安史之乱平定时，杜甫闻讯欣喜若狂而作。',
      significance: `此诗被称为杜甫"生平第一快诗"。"忽传"二字写出消息的突然与惊喜，"初闻涕泪满衣裳"以喜极而涕写情感的强烈。"却看妻子愁何在"以家人的喜悦印证自己的快乐，"漫卷诗书喜欲狂"以"狂"字写出难以自持的兴奋。"即从巴峡穿巫峡，便下襄阳向洛阳"以连续的地名写出归心似箭，一气呵成。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '剑外忽传收蓟北', emotion: '惊喜', intensity: 7 },
          { segment: '初闻涕泪满衣裳', emotion: '激动', intensity: 9 },
          { segment: '却看妻子愁何在', emotion: '欢喜', intensity: 8 },
          { segment: '漫卷诗书喜欲狂', emotion: '狂喜', intensity: 10 },
          { segment: '白日放歌须纵酒', emotion: '畅快', intensity: 9 },
          { segment: '青春作伴好还乡', emotion: '期待', intensity: 8 },
          { segment: '即从巴峡穿巫峡', emotion: '急切', intensity: 9 },
          { segment: '便下襄阳向洛阳', emotion: '归心', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 56, sentenceCount: 8, rhymeCount: 4 },
  },
  {
    id: 'p_084',
    title: '凉州词',
    author: '王之涣',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['边塞', '战争'],
    text: {
      original: '黄河远上白云间，一片孤城万仞山。羌笛何须怨杨柳，春风不度玉门关。',
      sentences: ['黄河远上白云间', '一片孤城万仞山', '羌笛何须怨杨柳', '春风不度玉门关'],
      rhymeScheme: ['间', '山', '关'],
    },
    annotations: [
      { term: '万仞', note: '形容极高。仞，古代长度单位。' },
      { term: '羌笛', note: '古代西部少数民族的吹奏乐器。' },
      { term: '杨柳', note: '指《折杨柳》曲，古代送别时常唱的曲子。' },
      { term: '度', note: '越过。' },

      { term: '征人', note: '出征的将士。' },
      { term: '杨花', note: '柳絮。古人折柳送别，杨花暗含离别之意。' }
    ],
    translation: '黄河好像从白云间奔流而来，玉门关孤零零地耸立在高山之中。何必用羌笛吹起那哀怨的《折杨柳》曲呢，要知道春风是吹不到玉门关外的。',
    literaryInfo: {
      authorBio: '王之涣（688年—742年），字季凌，唐代诗人，以边塞诗见长。',
      background: '此诗描写边塞的荒凉和戍边将士的思乡之苦。',
      significance: `"羌笛何须怨杨柳，春风不度玉门关"是千古名句。"黄河远上白云间"以黄河与白云相连写出边塞的辽远，"一片孤城万仞山"以孤城与高山的对比写出戍边的孤独。"羌笛何须怨杨柳"以杨柳双关——既是笛曲《折杨柳》，也指边关无柳的荒凉；"春风不度玉门关"以春风不至暗含对朝廷不关心戍边将士的不满。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '黄河白云间', keywords: ['黄河', '白云'] },
          { level: '中景', content: '孤城万仞山', keywords: ['孤城', '万仞山'] },
          { level: '情感', content: '羌笛怨杨柳', keywords: ['羌笛', '杨柳'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_085',
    title: '黄鹤楼送孟浩然之广陵',
    author: '李白',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['送别', '友情'],
    text: {
      original: '故人西辞黄鹤楼，烟花三月下扬州。孤帆远影碧空尽，唯见长江天际流。',
      sentences: ['故人西辞黄鹤楼', '烟花三月下扬州', '孤帆远影碧空尽', '唯见长江天际流'],
      rhymeScheme: ['楼', '州', '流'],
    },
    annotations: [
      { term: '黄鹤楼', note: '在今湖北省武汉市，古代著名楼阁。' },
      { term: '西辞', note: '从西方辞别，黄鹤楼在扬州之西。' },
      { term: '烟花', note: '形容春天花开似锦、烟雾迷蒙的景象。' },
      { term: '碧空尽', note: '消失在碧蓝的天际。' },

      { term: '惟见', note: '只看见。' }
    ],
    translation: '老朋友在黄鹤楼与我辞别，在繁花似锦的三月乘船去扬州。他乘坐的帆船渐行渐远，消失在碧空尽头，只看见滚滚长江水向天际流去。',
    literaryInfo: {
      authorBio: '李白（701年—762年），字太白，号青莲居士，唐代伟大的浪漫主义诗人，被后人誉为"诗仙"。',
      background: '此诗作于李白在黄鹤楼送别好友孟浩然时，表现了深切的惜别之情。',
      significance: `"孤帆远影碧空尽，唯见长江天际流"是千古送别名句。"故人西辞黄鹤楼"点明送别之地，"烟花三月下扬州"以春景反衬离愁。"孤帆远影碧空尽"写帆影消逝于碧空，以目送写出离别的怅惘；"唯见长江天际流"以江水奔流不息象征友情的绵延。全诗以景写情，景中含情。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '起点', content: '黄鹤楼辞别', keywords: ['黄鹤楼', '故人'] },
          { level: '时节', content: '烟花三月', keywords: ['烟花', '三月'] },
          { level: '远方', content: '孤帆远影', keywords: ['孤帆', '碧空尽'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_086',
    title: '乡村四月',
    author: '翁卷',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['田园'],
    text: {
      original: '绿遍山原白满川，子规声里雨如烟。乡村四月闲人少，才了蚕桑又插田。',
      sentences: ['绿遍山原白满川', '子规声里雨如烟', '乡村四月闲人少', '才了蚕桑又插田'],
      rhymeScheme: ['川', '烟', '田'],
    },
    annotations: [
      { term: '山原', note: '山陵和原野。' },
      { term: '白满川', note: '指水田映着天光一片白。' },
      { term: '子规', note: '杜鹃鸟。' },
      { term: '才了', note: '刚刚做完。' },

      { term: '才了蚕桑又插田', note: '刚忙完采桑养蚕又要插秧了。了，结束。' }
    ],
    translation: '绿色染遍了山陵和原野，水田里的水光映着天色一片白，杜鹃鸟在如烟的细雨中声声啼叫。乡村四月没有闲人，刚刚忙完采桑养蚕又忙着插秧种田。',
    literaryInfo: {
      authorBio: '翁卷，南宋诗人，生卒年不详，字续古，一字灵舒，永嘉（今浙江温州）人，"永嘉四灵"之一。',
      background: '此诗描写江南农村四月的繁忙景象，充满浓郁的乡土气息。',
      significance: `此诗以清新的笔调写出乡村四月的忙碌与美丽。"绿遍山原白满川"以绿白二色写山原与水田，"子规声里雨如烟"以杜鹃声和烟雨写江南春景。"乡村四月闲人少"以"闲人少"写农忙，"才了蚕桑又插田"以"才了""又"写农事的紧张衔接，生动展现了农人的辛劳。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '绿遍山原', keywords: ['山原', '绿遍'] },
          { level: '中景', content: '子规烟雨', keywords: ['子规', '雨如烟'] },
          { level: '近景', content: '蚕桑插田', keywords: ['蚕桑', '插田'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  // ===== 六年级上册 =====
  {
    id: 'p_087',
    title: '宿建德江',
    author: '孟浩然',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '思乡'],
    text: {
      original: '移舟泊烟渚，日暮客愁新。野旷天低树，江清月近人。',
      sentences: ['移舟泊烟渚', '日暮客愁新', '野旷天低树', '江清月近人'],
      rhymeScheme: ['新', '人'],
    },
    annotations: [
      { term: '建德江', note: '指新安江流经建德（今属浙江）的一段。' },
      { term: '烟渚', note: '雾气笼罩的小洲。' },
      { term: '客愁新', note: '旅途中的愁思又涌上心头。' },
      { term: '天低树', note: '天空低垂，仿佛比树还低。' },

      { term: '日暮', note: '黄昏时分。' },
    ],
    translation: '把小船停靠在烟雾迷蒙的小洲边，日暮时分旅人又添了新的愁思。原野空旷，天空仿佛比树还低，江水清澈，月亮好像离人很近。',
    literaryInfo: {
      authorBio: '孟浩然（689年—740年），名浩，字浩然，号孟山人，唐代著名山水田园派诗人。',
      background: '此诗作于孟浩然漫游吴越途中，傍晚泊舟建德江时所作。',
      significance: `"野旷天低树，江清月近人"以奇特的视角写出旷野的空旷和江月的亲切。"移舟泊烟渚"写停船靠岸，"日暮客愁新"以日暮引出新愁。"野旷天低树"写旷野空旷，天幕低垂仿佛比树还低；"江清月近人"写江水清澈，月亮仿佛亲近旅人。低与近的对仗，以自然的"亲近"反衬人事的孤独。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '野旷天低树', keywords: ['野旷', '天低树'] },
          { level: '中景', content: '烟渚日暮', keywords: ['烟渚', '日暮'] },
          { level: '近景', content: '江清月近人', keywords: ['江清', '月近人'] },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_088',
    title: '六月二十七日望湖楼醉书',
    author: '苏轼',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水'],
    text: {
      original: '黑云翻墨未遮山，白雨跳珠乱入船。卷地风来忽吹散，望湖楼下水如天。',
      sentences: ['黑云翻墨未遮山', '白雨跳珠乱入船', '卷地风来忽吹散', '望湖楼下水如天'],
      rhymeScheme: ['山', '船', '天'],
    },
    annotations: [
      { term: '望湖楼', note: '在杭州西湖边。' },
      { term: '翻墨', note: '打翻墨水，形容云层黑如泼墨。' },
      { term: '跳珠', note: '跳动的珍珠，形容雨滴。' },
      { term: '卷地风', note: '从地面席卷而来的大风。' },

      { term: '醉书', note: '醉中书写。醉意中写下的诗。' },
    ],
    translation: '乌云翻卷如泼墨还未来得及遮住山峦，白花花的雨点就像跳动的珍珠纷纷落入船舱。忽然一阵大风席卷而来把云雨吹散，望湖楼下的湖面又恢复了水天一色的景象。',
    literaryInfo: {
      authorBio: '苏轼（1037年—1101年），字子瞻，号东坡居士，北宋文学家、书画家，"唐宋八大家"之一。',
      background: '此诗作于苏轼任杭州通判时，在望湖楼上观赏西湖骤雨即景而作。',
      significance: `此诗以极为生动的比喻写出夏日西湖阵雨的全过程。"黑云翻墨未遮山"以翻墨比喻乌云翻涌，"白雨跳珠乱入船"以跳珠比喻雨点的急促。"卷地风来忽吹散"写风来雨散的突然，"望湖楼下水如天"写雨后水天一色的开阔。全诗以"翻墨""跳珠"的比喻新颖生动，写出了暴雨来去迅疾的特点。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '从黑云翻墨到白雨跳珠，再到风来吹散，描写一场西湖骤雨。',
        timeline: [
          { event: '黑云翻墨未遮山', order: 1 },
          { event: '白雨跳珠乱入船', order: 2 },
          { event: '卷地风来', order: 3 },
          { event: '忽吹散', order: 4 },
          { event: '水如天', order: 5 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_089',
    title: '西江月·夜行黄沙道中',
    author: '辛弃疾',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '词', subGenre: '婉约派' },
    themes: ['田园', '山水'],
    text: {
      original: `明月别枝惊鹊，清风半夜鸣蝉。稻花香里说丰年，听取蛙声一片。七八个星天外，两三点雨山前。旧时茅店社林边，路转溪桥忽见。`,
      sentences: ['明月别枝惊鹊', '清风半夜鸣蝉', '稻花香里说丰年，听取蛙声一片', '七八个星天外', '两三点雨山前', '旧时茅店社林边，路转溪桥忽见'],
      rhymeScheme: ['蝉', '年', '前', '见'],
    },
    annotations: [
      { term: '西江月', note: '词牌名。' },
      { term: '黄沙道', note: '黄沙岭间的路，在今江西上饶西。' },
      { term: '别枝', note: '横斜的树枝。' },
      { term: '鸣蝉', note: '蝉的叫声。' },
      { term: '说丰年', note: '谈论丰收的年景。' },
      { term: '社林', note: '土地庙附近的树林。社，土地神庙。' },
      { term: '忽见', note: '忽然出现。见，同"现"。' },

      { term: '丰年', note: '丰收之年。' },
    ],
    translation: '明亮的月光惊动了枝头的喜鹊，清凉的夜风中传来蝉鸣声。稻花飘香预示着丰收之年，听取一片蛙声。天外几颗星星闪烁，山前飘来两三点细雨。记得从前社林边的茅店，路转过溪桥忽然出现在眼前。',
    literaryInfo: {
      authorBio: '辛弃疾（1140年—1207年），字幼安，号稼轩，南宋豪放派词人，与苏轼合称"苏辛"。',
      background: '此词作于辛弃疾闲居上饶时，夜行黄沙道中所见所感。',
      significance: `此词以清新自然的笔调描绘夏夜乡村美景。"明月别枝惊鹊"以月光惊鹊写夜的静谧，"清风半夜鸣蝉"以蝉鸣增添夏夜气息。"稻花香里说丰年，听取蛙声一片"以蛙声预兆丰收，表达农人喜悦。"七八个星天外，两三点雨山前"以数字对仗写天气变化，"路转溪桥忽见"写寻找旧店的惊喜，充满田园情趣。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '天景', content: '明月惊鹊', keywords: ['明月', '惊鹊'] },
          { level: '声景', content: '蛙声说丰年', keywords: ['稻花', '蛙声'] },
          { level: '雨景', content: '星天外雨山前', keywords: ['星天外', '雨山前'] },
          { level: '发现', content: '茅店溪桥', keywords: ['茅店', '溪桥'] },
        ],
      },
    },
    stats: { charCount: 50, sentenceCount: 6, rhymeCount: 4 },
  },
  {
    id: 'p_090',
    title: '七律·长征',
    author: '毛泽东',
    dynasty: '近现代',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '词', subGenre: '近体诗' },
    themes: ['爱国', '人生'],
    text: {
      original: `红军不怕远征难，万水千山只等闲。五岭逶迤腾细浪，乌蒙磅礴走泥丸。金沙水拍云崖暖，大渡桥横铁索寒。更喜岷山千里雪，三军过后尽开颜。`,
      sentences: ['红军不怕远征难', '万水千山只等闲', '五岭逶迤腾细浪', '乌蒙磅礴走泥丸', '金沙水拍云崖暖', '大渡桥横铁索寒', '更喜岷山千里雪', '三军过后尽开颜'],
      rhymeScheme: ['难', '闲', '丸', '寒', '颜'],
    },
    annotations: [
      { term: '等闲', note: '平常，不放在心上。' },
      { term: '五岭', note: '越城岭、都庞岭、萌渚岭、骑田岭、大庾岭的总称。' },
      { term: '乌蒙', note: '乌蒙山，在云南贵州之间。' },
      { term: '大渡桥', note: '指泸定桥，红军飞夺泸定桥。' },

      { term: '逶迤', note: '弯弯曲曲连绵不断。' },
      { term: '磅礴', note: '气势雄伟。' },
      { term: '开颜', note: '喜笑颜开。' }
    ],
    translation: '红军不怕长征途中的艰难险阻，把万水千山看作平常之事。绵延的五岭在红军看来不过是翻腾的细小波浪，气势雄伟的乌蒙山不过是滚动的小泥丸。金沙江两岸悬崖高耸水流湍急，大渡河上泸定桥横跨两岸铁索寒光闪闪。更让人欢喜的是岷山上的千里白雪，三军翻过之后人人喜笑颜开。',
    literaryInfo: {
      authorBio: '毛泽东（1893年—1976年），字润之，中国革命的领袖，也是杰出的诗人。',
      background: '此诗作于1935年10月，红军即将完成长征时，回顾长征途中的壮举。',
      significance: `此诗以磅礴的气势概括了长征的艰难历程。"红军不怕远征难"以"不怕"写出革命者的坚定，"万水千山只等闲"以"等闲"写出对困难的蔑视。颈联以"五岭""乌蒙"写山的险峻，以"细浪""泥丸"写困难的渺小——在革命者眼中不过如此。尾联"更喜岷山千里雪，三军过后尽开颜"以"尽开颜"写出胜利的喜悦，展现了革命乐观主义精神。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '红军长征途中的壮举：翻五岭、越乌蒙、渡金沙、夺泸定、过岷山。',
        timeline: [
          { event: '远征不怕难', order: 1 },
          { event: '五岭腾细浪', order: 2 },
          { event: '乌蒙走泥丸', order: 3 },
          { event: '金沙水拍云崖', order: 4 },
          { event: '大渡铁索寒', order: 5 },
          { event: '岷山千里雪', order: 6 },
          { event: '三军尽开颜', order: 7 },
        ],
      },
    },
    stats: { charCount: 56, sentenceCount: 8, rhymeCount: 5 },
  },
  {
    id: 'p_091',
    title: '浪淘沙（其一）',
    author: '刘禹锡',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '哲理'],
    text: {
      original: '九曲黄河万里沙，浪淘风簸自天涯。如今直上银河去，同到牵牛织女家。',
      sentences: ['九曲黄河万里沙', '浪淘风簸自天涯', '如今直上银河去', '同到牵牛织女家'],
      rhymeScheme: ['沙', '涯', '家'],
    },
    annotations: [
      { term: '九曲', note: '形容黄河弯弯曲曲。' },
      { term: '浪淘风簸', note: '波浪翻滚，风浪吹荡。' },
      { term: '银河', note: '天河。' },
      { term: '牵牛织女', note: '牛郎星和织女星。' },

      { term: '直上', note: '径直上升到。' }
    ],
    translation: '九曲黄河挟带着万里泥沙，大浪翻滚狂风怒卷仿佛来自天涯。如今我们要径直飞上银河去，一起到牛郎织女的家里做客。',
    literaryInfo: {
      authorBio: '刘禹锡（772年—842年），字梦得，唐代诗人、哲学家，有"诗豪"之称。',
      background: '此诗为刘禹锡《浪淘沙》组诗之一，以黄河起兴，抒发豪迈的想象。',
      significance: `此诗想象奇特，以黄河通银河的浪漫想象表现乐观精神。"黄河远上白云间"以黄河之水天上来写出壮阔，诗人想象如果黄河之水直通银河，便可乘槎上天。全诗以浪漫的想象写出对理想境界的追求，表现了诗人积极向上的精神。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '九曲黄河万里沙', keywords: ['九曲', '万里沙'] },
          { level: '动态', content: '浪淘风簸', keywords: ['浪淘', '风簸'] },
          { level: '想象', content: '直上银河', keywords: ['银河', '牵牛织女'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_092',
    title: '江南春',
    author: '杜牧',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '咏史'],
    text: {
      original: '千里莺啼绿映红，水村山郭酒旗风。南朝四百八十寺，多少楼台烟雨中。',
      sentences: ['千里莺啼绿映红', '水村山郭酒旗风', '南朝四百八十寺', '多少楼台烟雨中'],
      rhymeScheme: ['红', '风', '中'],
    },
    annotations: [
      { term: '山郭', note: '山边的城镇。郭，外城。' },
      { term: '酒旗', note: '酒馆门前悬挂的旗帜。' },
      { term: '南朝', note: '指先后在建康（今南京）建都的宋、齐、梁、陈四朝。' },
      { term: '四百八十寺', note: '南朝修建了大量佛寺，此处形容佛寺之多。' },

      { term: '绿映红', note: '绿叶映衬着红花。' },
      { term: '酒旗风', note: '酒旗在风中飘扬。酒旗，酒家的标志。' },
    ],
    translation: '千里江南到处莺歌燕舞，绿树映衬着红花，水边村庄山边城郭酒旗在风中飘扬。南朝修建了四百八十多座佛寺，如今有多少楼台笼罩在蒙蒙烟雨之中。',
    literaryInfo: {
      authorBio: '杜牧（803年—852年），字牧之，唐代诗人，与李商隐并称"小李杜"。',
      background: '此诗描写江南春色，既有自然美景，也有对南朝佛寺兴亡的感慨。',
      significance: `此诗前半写江南春色之美，后半以烟雨楼台寄托历史兴亡之叹。"千里莺啼绿映红"以声色写出江南春景的繁华，"水村山郭酒旗风"写人间烟火气。"南朝四百八十寺，多少楼台烟雨中"以烟雨朦胧中的南朝佛寺暗喻历史兴亡——昔日辉煌的佛寺如今只剩烟雨中的遗迹，繁华终将逝去。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '千里莺啼绿映红', keywords: ['莺啼', '绿映红'] },
          { level: '中景', content: '水村山郭酒旗风', keywords: ['水村', '酒旗'] },
          { level: '近景', content: '楼台烟雨中', keywords: ['楼台', '烟雨'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_093',
    title: '书湖阴先生壁',
    author: '王安石',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['田园', '山水'],
    text: {
      original: '茅檐长扫净无苔，花木成畦手自栽。一水护田将绿绕，两山排闼送青来。',
      sentences: ['茅檐长扫净无苔', '花木成畦手自栽', '一水护田将绿绕', '两山排闼送青来'],
      rhymeScheme: ['苔', '栽', '来'],
    },
    annotations: [
      { term: '湖阴先生', note: '杨德逢的号，王安石在金陵时的邻居。' },
      { term: '畦', note: '田地中分成的小区。' },
      { term: '护田', note: '护卫着农田。' },
      { term: '排闼', note: '推开门。闼，门。' },

      { term: '长扫', note: '经常打扫。长，常，经常。' },
    ],
    translation: '茅屋檐下经常打扫得干干净净没有青苔，成行的花木都是主人亲手栽种的。一条小溪护卫着农田将绿意环绕，两座青山推开门把翠色送来。',
    literaryInfo: {
      authorBio: '王安石（1021年—1086年），字介甫，号半山，北宋政治家、文学家，"唐宋八大家"之一。',
      background: '此诗为题写在邻居湖阴先生墙壁上的诗，赞美了主人的高雅和居处的优美环境。',
      significance: `"一水护田将绿绕，两山排闼送青来"是千古名句。"茅檐长扫净无苔"写庭院的洁净，"花木成畦手自栽"写主人的勤勉。"一水护田将绿绕"以"护"字拟人，写溪水环绕田地的温柔；"两山排闼送青来"以"排闼"（推门）拟人，写青山主动把翠色送入院中。全诗以拟人手法写山水对人的情意，极为生动。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '近景', content: '茅檐无苔花木成畦', keywords: ['茅檐', '花木'] },
          { level: '中景', content: '一水护田绿绕', keywords: ['一水', '护田'] },
          { level: '远景', content: '两山送青来', keywords: ['两山', '排闼'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_094',
    title: '过故人庄',
    author: '孟浩然',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['田园', '友情'],
    text: {
      original: '故人具鸡黍，邀我至田家。绿树村边合，青山郭外斜。开轩面场圃，把酒话桑麻。待到重阳日，还来就菊花。',
      sentences: ['故人具鸡黍', '邀我至田家', '绿树村边合', '青山郭外斜', '开轩面场圃', '把酒话桑麻', '待到重阳日', '还来就菊花'],
      rhymeScheme: ['黍', '家', '斜', '麻', '花'],
    },
    annotations: [
      { term: '具鸡黍', note: '准备鸡和黄米饭，指准备丰盛的饭菜。' },
      { term: '合', note: '环绕。' },
      { term: '场圃', note: '打谷场和菜园。' },
      { term: '就菊花', note: '来赏菊花。就，靠近，赴。' },

      { term: '故人', note: '老朋友。' },
      { term: '具', note: '准备，置办。' },
      { term: '斜', note: '同“斜”，偏斜。' }
    ],
    translation: '老朋友准备了丰盛的饭菜，邀请我到他的农家做客。翠绿的树木环绕着村庄，青翠的山峦在城外隐约可见。打开窗户面对着打谷场和菜园，举杯饮酒闲谈农事。等到重阳节那一天，我还要来赏菊花。',
    literaryInfo: {
      authorBio: '孟浩然（689年—740年），名浩，字浩然，号孟山人，唐代著名山水田园派诗人。',
      background: '此诗写诗人到农村访友的情景，描绘了田园生活的恬静和友情的淳朴。',
      significance: `此诗以平淡自然的语言写出农家生活的淳朴和友情的真挚。"故人具鸡黍"写主人的盛情准备，"邀我至田家"写友情的随意自然。"绿树村边合，青山郭外斜"写环境的优美——绿树环绕、青山斜映。"开轩面场圃，把酒话桑麻"写窗前饮酒、闲话农事的惬意。"待到重阳日，还来就菊花"以约定再来写出友情的长久。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '环境', content: '绿树村边合，青山郭外斜', keywords: ['绿树', '青山'] },
          { level: '活动', content: '开轩面场圃，把酒话桑麻', keywords: ['场圃', '桑麻'] },
          { level: '约定', content: '重阳日就菊花', keywords: ['重阳', '菊花'] },
        ],
      },
    },
    stats: { charCount: 40, sentenceCount: 8, rhymeCount: 5 },
  },
  {
    id: 'p_095',
    title: '菩萨蛮·大柏地',
    author: '毛泽东',
    dynasty: '近现代',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '词', subGenre: '婉约派' },
    themes: ['山水', '爱国'],
    text: {
      original: `赤橙黄绿青蓝紫，谁持彩练当空舞？雨后复斜阳，关山阵阵苍。当年鏖战急，弹洞前村壁。装点此关山，今朝更好看。`,
      sentences: ['赤橙黄绿青蓝紫', '谁持彩练当空舞', '雨后复斜阳', '关山阵阵苍', '当年鏖战急', '弹洞前村壁', '装点此关山', '今朝更好看'],
      rhymeScheme: ['舞', '苍', '壁', '看'],
    },
    annotations: [
      { term: '菩萨蛮', note: '词牌名。' },
      { term: '大柏地', note: '在江西瑞金，1929年红军在此击败国民党军。' },
      { term: '彩练', note: '彩色的绸带，比喻彩虹。' },
      { term: '鏖战', note: '激烈的战斗。' },

      { term: '关山阵阵苍', note: '关山在阵雨中时隐时现，显得苍翠。阵阵，时断时续。' },
      { term: '当年', note: '指过去战斗的年代。' }
    ],
    translation: '赤橙黄绿青蓝紫七种颜色，是谁拿着彩色的绸带在天空中舞动？雨后天边又出现了一轮夕阳，关山在夕阳中更显得苍翠。当年这里曾进行过激烈的战斗，前村墙壁上还留着弹孔。这些弹孔装点着这关山，如今看起来更加好看。',
    literaryInfo: {
      authorBio: '毛泽东（1893年—1976年），字润之，中国革命的领袖，也是杰出的诗人。',
      background: '此词作于1933年夏，毛泽东重返大柏地，回忆当年战斗场景而作。',
      significance: `此词以彩虹和弹洞的对比展现革命乐观主义精神。"赤橙黄绿青蓝紫"以七色开篇如彩虹凌空，"谁持彩练当空舞"以拟人写彩虹如彩带飞舞。"当年鏖战急，弹洞前村壁"回忆昔日战斗遗迹，"装点此关山，今朝更好看"将战争痕迹视为今日关山的装饰，化残酷为壮美。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '天景', content: '彩虹当空', keywords: ['彩练', '当空舞'] },
          { level: '远景', content: '关山苍翠', keywords: ['关山', '阵阵苍'] },
          { level: '近景', content: '弹洞前村壁', keywords: ['弹洞', '鏖战'] },
        ],
      },
    },
    stats: { charCount: 44, sentenceCount: 8, rhymeCount: 4 },
  },
  {
    id: 'p_096',
    title: '春日',
    author: '朱熹',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '哲理'],
    text: {
      original: '胜日寻芳泗水滨，无边光景一时新。等闲识得东风面，万紫千红总是春。',
      sentences: ['胜日寻芳泗水滨', '无边光景一时新', '等闲识得东风面', '万紫千红总是春'],
      rhymeScheme: ['滨', '新', '春'],
    },
    annotations: [
      { term: '胜日', note: '好日子，此处指春日。' },
      { term: '寻芳', note: '游春赏花。' },
      { term: '泗水', note: '河名，在山东曲阜，孔子曾在此讲学。' },
      { term: '等闲', note: '轻易，随便。' },

      { term: '东风面', note: '春天的面貌。东风，春风。' }
    ],
    translation: '在风和日丽的日子里来到泗水河边游春赏花，无边无际的风光焕然一新。轻易就能认出东风的面容，因为百花盛开万紫千红都是春风带来的。',
    literaryInfo: {
      authorBio: '朱熹（1130年—1200年），字元晦，号晦庵，南宋理学家、教育家、诗人，理学集大成者。',
      background: '此诗表面写春游，实则是借春日寻芳比喻读书求道的感悟。泗水为孔子讲学之地，暗含求道之意。',
      significance: `"等闲识得东风面，万紫千红总是春"是千古名句。此诗表面写春游，实则是借春日寻芳比喻读书求道的感悟。泗水为孔子讲学之地，暗含求道之意。"万紫千红"既是春景的写实，也是读书领悟后思想境界的隐喻。全诗一诗二解，妙趣横生。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '泗水寻芳', keywords: ['泗水', '寻芳'] },
          { level: '中景', content: '光景一新', keywords: ['光景', '一时新'] },
          { level: '近景', content: '万紫千红', keywords: ['东风', '万紫千红'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_097',
    title: '回乡偶书',
    author: '贺知章',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['思乡', '人生'],
    text: {
      original: '少小离家老大回，乡音无改鬓毛衰。儿童相见不相识，笑问客从何处来。',
      sentences: ['少小离家老大回', '乡音无改鬓毛衰', '儿童相见不相识', '笑问客从何处来'],
      rhymeScheme: ['回', '衰', '来'],
    },
    annotations: [
      { term: '偶书', note: '偶然写下的诗句。' },
      { term: '老大', note: '年纪大了。' },
      { term: '鬓毛衰', note: '两鬓的头发稀疏了。衰，稀疏。' },
      { term: '客', note: '客人，此处指外来的人。' },

      { term: '少小离家老大回', note: '年少时离家年老才回来。' },
      { term: '乡音', note: '家乡的口音。' },
    ],
    translation: '年少时离开家乡，年纪老大了才回来，家乡的口音没有改变但两鬓的头发已经稀疏了。村里的孩子们见了我都不认识，笑着问我这位客人从哪里来。',
    literaryInfo: {
      authorBio: '贺知章（659年—744年），字季真，唐代诗人、书法家，自号"四明狂客"。',
      background: '此诗作于贺知章辞官回乡时，年已八十多岁，感慨万千而作。',
      significance: `此诗以朴素的语言写出了久别回乡的复杂心情。"少小离家老大回"以少小与老大的对比写出时光流逝，"乡音无改鬓毛衰"以乡音未变与鬓毛已衰写出人虽老而乡情不改。"儿童相见不相识，笑问客从何处来"以儿童的纯真笑容中诗人感受到被故乡视为"客"的酸楚，笑中含泪，意味深长。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '少小离家老大回', emotion: '感慨', intensity: 7 },
          { segment: '乡音无改鬓毛衰', emotion: '唏嘘', intensity: 8 },
          { segment: '儿童相见不相识', emotion: '怅然', intensity: 7 },
          { segment: '笑问客从何处来', emotion: '苦涩', intensity: 9 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  // ===== 六年级下册 =====
  {
    id: 'p_098',
    title: '寒食',
    author: '韩翃',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['节日'],
    text: {
      original: '春城无处不飞花，寒食东风御柳斜。日暮汉宫传蜡烛，轻烟散入五侯家。',
      sentences: ['春城无处不飞花', '寒食东风御柳斜', '日暮汉宫传蜡烛', '轻烟散入五侯家'],
      rhymeScheme: ['花', '斜', '家'],
    },
    annotations: [
      { term: '寒食', note: '节日名，在清明前两天，古人这天禁火只吃冷食。' },
      { term: '御柳', note: '皇宫中的柳树。' },
      { term: '汉宫', note: '此处借指唐宫。' },
      { term: '五侯', note: '泛指权贵。' },

      { term: '春城', note: '春天的京城。指长安。' },
      { term: '传蜡烛', note: '寒食节禁火，但皇帝特赐蜡烛给权贵。' }
    ],
    translation: '春天的京城里无处不飘飞着落花，寒食节的东风吹拂着皇宫中的柳枝。傍晚时分汉宫中开始赐传蜡烛，轻烟飘入了权贵之家。',
    literaryInfo: {
      authorBio: '韩翃，唐代诗人，生卒年不详，字君平，"大历十才子"之一。',
      background: '此诗以寒食节为背景，借汉宫赐烛之事暗讽中唐以来宦官专权的现实。',
      significance: `"春城无处不飞花"是千古名句。此诗以寒食节为背景，前两句写春城飞花、东风御柳的美景，后两句以汉宫赐烛之事暗讽中唐宦官专权——百姓禁火而权贵享有赐烛特权。"轻烟散入五侯家"以轻烟暗写特权，含蓄而辛辣，是"不著一字，尽得风流"的典范。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '春城飞花', keywords: ['飞花', '无处不'] },
          { level: '中景', content: '东风御柳', keywords: ['东风', '御柳'] },
          { level: '近景', content: '汉宫蜡烛散轻烟', keywords: ['蜡烛', '轻烟'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_099',
    title: '迢迢牵牛星',
    author: '佚名',
    dynasty: '汉',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '古体诗' },
    themes: ['爱情', '人生'],
    text: {
      original: '迢迢牵牛星，皎皎河汉女。纤纤擢素手，札札弄机杼。终日不成章，泣涕零如雨。河汉清且浅，相去复几许。盈盈一水间，脉脉不得语。',
      sentences: ['迢迢牵牛星', '皎皎河汉女', '纤纤擢素手', '札札弄机杼', '终日不成章', '泣涕零如雨', '河汉清且浅', '相去复几许', '盈盈一水间', '脉脉不得语'],
      rhymeScheme: ['女', '杼', '雨', '许', '语'],
    },
    annotations: [
      { term: '迢迢', note: '遥远的样子。' },
      { term: '皎皎', note: '明亮洁白的样子。' },
      { term: '擢', note: '伸出。' },
      { term: '脉脉', note: '含情相视的样子。' },

      { term: '札札', note: '织机发出的声音。' },
      { term: '盈盈', note: '水清澈的样子。形容银河水浅。' }
    ],
    translation: '远远的牵牛星，明亮的织女星。纤细的手伸出白皙的手腕，札札地穿梭织布。整天也织不成布帛，眼泪像雨一样落下。银河清清浅浅，两人相距又能有多远呢。只隔着一道清浅的水，含情脉脉却不能说话。',
    literaryInfo: {
      authorBio: '佚名，出自《古诗十九首》，为汉代文人五言诗，作者不详。',
      background: '此诗以牛郎织女的神话为题材，描写了织女隔河思念牛郎的痛苦。',
      significance: `"盈盈一水间，脉脉不得语"是千古名句。全诗以叠字贯穿——迢迢、皎皎、纤纤、札札、盈盈、脉脉，声韵优美。以牛郎织女的神话暗喻人间的相思之苦，"盈盈一水间"写距离之近，"脉脉不得语"写痛苦之深——虽近在咫尺却不得相聚言说。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '迢迢牵牛星', emotion: '遥远', intensity: 5 },
          { segment: '纤纤擢素手', emotion: '柔美', intensity: 4 },
          { segment: '终日不成章', emotion: '悲伤', intensity: 7 },
          { segment: '泣涕零如雨', emotion: '痛苦', intensity: 9 },
          { segment: '河汉清且浅', emotion: '感叹', intensity: 7 },
          { segment: '脉脉不得语', emotion: '无奈', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 50, sentenceCount: 10, rhymeCount: 5 },
  },
  {
    id: 'p_100',
    title: '十五夜望月',
    author: '王建',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['节日', '思乡'],
    text: {
      original: '中庭地白树栖鸦，冷露无声湿桂花。今夜月明人尽望，不知秋思落谁家。',
      sentences: ['中庭地白树栖鸦', '冷露无声湿桂花', '今夜月明人尽望', '不知秋思落谁家'],
      rhymeScheme: ['鸦', '花', '家'],
    },
    annotations: [
      { term: '十五夜', note: '农历八月十五日夜晚，即中秋夜。' },
      { term: '地白', note: '月光照在地上的样子。' },
      { term: '冷露', note: '冰凉的露水。' },
      { term: '秋思', note: '秋天的思念之情。' },

      { term: '尽望乡', note: '都在望月思乡。尽，都，全。' }
    ],
    translation: '庭院中月光照在地上泛白，树上栖息着乌鸦，冰凉的露水无声地打湿了桂花。今夜明月当空人人都在仰望，不知道这秋天的思念会落在谁家。',
    literaryInfo: {
      authorBio: '王建（约767年—约830年），字仲初，唐代诗人，以乐府诗著称。',
      background: '此诗为中秋望月思乡之作，表达了对远方亲人的思念。',
      significance: `"今夜月明人尽望，不知秋思落谁家"是中秋诗词名句。前两句写景——庭中月光如银、乌鸦栖息、冷露湿花，营造清冷氛围。"人尽望"写出望月的普遍性，"不知秋思落谁家"以反问将普遍的望月引向深层的思乡，看似不知实则自知——秋思就在自己心中。全诗以景写情，含蓄蕴藉。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '中庭地白', keywords: ['地白', '栖鸦'] },
          { level: '中景', content: '冷露桂花', keywords: ['冷露', '桂花'] },
          { level: '情感', content: '月明人望', keywords: ['月明', '秋思'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_101',
    title: '长歌行',
    author: '汉乐府',
    dynasty: '汉',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '古体诗' },
    themes: ['哲理', '人生'],
    text: {
      original: '青青园中葵，朝露待日晞。阳春布德泽，万物生光辉。常恐秋节至，焜黄华叶衰。百川东到海，何时复西归？少壮不努力，老大徒伤悲。',
      sentences: ['青青园中葵', '朝露待日晞', '阳春布德泽', '万物生光辉', '常恐秋节至', '焜黄华叶衰', '百川东到海', '何时复西归', '少壮不努力', '老大徒伤悲'],
      rhymeScheme: ['葵', '晞', '辉', '衰', '归', '悲'],
    },
    annotations: [
      { term: '葵', note: '一种蔬菜。' },
      { term: '晞', note: '晒干。' },
      { term: '布德泽', note: '施加恩惠。' },
      { term: '焜黄', note: '枯黄。' },

      { term: '朝露', note: '早晨的露水。比喻生命短暂。' },
      { term: '阳春', note: '温暖的春天。' },
      { term: '德泽', note: '恩惠。大自然的恩赐。' }
    ],
    translation: '园中绿油油的葵菜上沾满了清晨的露水，等待着阳光的照耀。春天把恩泽洒向大地，万物都焕发出勃勃生机。常常担心秋天到来，花叶变得枯黄衰败。千百条河流向东流入大海，什么时候才能再向西流回来呢？年少时如果不努力，到老来就只能白白地悲伤了。',
    literaryInfo: {
      authorBio: '汉乐府，汉代官方音乐机构采集的民间诗歌，作者多为无名氏。',
      background: '此诗为汉乐府民歌，以自然界的盛衰规律比喻人生，劝勉人珍惜时光。',
      significance: `"少壮不努力，老大徒伤悲"是千古流传的格言。此诗以自然界盛衰规律比喻人生：园中葵的朝露待晞、春阳布泽是少年美好的象征；秋节将至的华叶衰败、百川东去的不复西归是年华老去的写照。全诗从自然到人生，由物及人，层层推进，最终以警诫收束，劝勉珍惜年少时光。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '青青园中葵', emotion: '生机', intensity: 5 },
          { segment: '阳春布德泽', emotion: '赞叹', intensity: 6 },
          { segment: '常恐秋节至', emotion: '忧虑', intensity: 7 },
          { segment: '百川东到海', emotion: '感慨', intensity: 8 },
          { segment: '少壮不努力', emotion: '警诫', intensity: 9 },
          { segment: '老大徒伤悲', emotion: '痛惜', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 50, sentenceCount: 10, rhymeCount: 6 },
  },
  {
    id: 'p_102',
    title: '马诗',
    author: '李贺',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['咏物', '人生'],
    text: {
      original: '大漠沙如雪，燕山月似钩。何当金络脑，快走踏清秋。',
      sentences: ['大漠沙如雪', '燕山月似钩', '何当金络脑', '快走踏清秋'],
      rhymeScheme: ['钩', '秋'],
    },
    annotations: [
      { term: '燕山', note: '指燕然山，今蒙古国境内。' },
      { term: '钩', note: '弯刀，此处形容弯月。' },
      { term: '金络脑', note: '用黄金装饰的马笼头，指骏马受到重用。' },
      { term: '何当', note: '何时能够。' },

    ],
    translation: '大漠上的沙子洁白如雪，燕山上空挂着弯月如钩。何时才能给骏马配上金笼头，在秋高气爽的疆场上驰骋呢？',
    literaryInfo: {
      authorBio: '李贺（790年—816年），字长吉，唐代诗人，有"诗鬼"之称，诗风奇丽。',
      background: '此诗为《马诗二十三首》之五，以骏马渴望驰骋疆场自喻怀才不遇。',
      significance: `此诗以马喻人，表达了渴望建功立业的壮志。"大漠沙如雪"以雪比喻大漠白沙的洁白，"燕山月似钩"以弯刀比喻新月的形状，营造边塞月夜的壮阔苍凉。"何当金络脑"以骏马渴望戴上金笼头自喻渴望被重用，"快走踏清秋"以骏马驰骋秋野的想象表达渴望建功的心愿。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '大漠沙如雪', keywords: ['大漠', '沙如雪'] },
          { level: '中景', content: '燕山月似钩', keywords: ['燕山', '月似钩'] },
          { level: '想象', content: '快走踏清秋', keywords: ['金络脑', '清秋'] },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_103',
    title: '石灰吟',
    author: '于谦',
    dynasty: '明',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['咏物', '人生'],
    text: {
      original: '千锤万凿出深山，烈火焚烧若等闲。粉骨碎身浑不怕，要留清白在人间。',
      sentences: ['千锤万凿出深山', '烈火焚烧若等闲', '粉骨碎身浑不怕', '要留清白在人间'],
      rhymeScheme: ['山', '闲', '间'],
    },
    annotations: [
      { term: '千锤万凿', note: '形容开采石灰石的艰辛。' },
      { term: '等闲', note: '平常，不在乎。' },
      { term: '浑不怕', note: '全然不怕。' },
      { term: '清白', note: '指石灰的白色，也喻高洁的品格。' },

      { term: '若等闲', note: '好像平常的事。若，好像。等闲，平常。' },
    ],
    translation: '石灰石经过千锤万凿才从深山中开采出来，烈火焚烧它也当作平常事。即使粉身碎骨也全然不怕，只要把清白留在人间。',
    literaryInfo: {
      authorBio: '于谦（1398年—1457年），字廷益，明代名臣、民族英雄，土木堡之变后力主保卫北京。',
      background: '此诗为于谦少年时所作，以石灰自喻，表达坚贞不屈的品格。',
      significance: `"粉骨碎身浑不怕，要留清白在人间"是千古名句。此诗以石灰自喻，字字双关："千锤万凿"既写石灰开采也喻人生磨砺；"烈火焚烧若等闲"既写石灰烧制也喻面对考验的坦然；"粉骨碎身浑不怕"既写石灰粉化也喻牺牲自我的无畏；"要留清白在人间"既写石灰的洁白也喻高洁品格的坚守。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '千锤万凿出深山', emotion: '艰辛', intensity: 7 },
          { segment: '烈火焚烧若等闲', emotion: '坚毅', intensity: 8 },
          { segment: '粉骨碎身浑不怕', emotion: '无畏', intensity: 9 },
          { segment: '要留清白在人间', emotion: '高洁', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_104',
    title: '竹石',
    author: '郑燮',
    dynasty: '清',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['咏物', '人生'],
    text: {
      original: '咬定青山不放松，立根原在破岩中。千磨万击还坚劲，任尔东西南北风。',
      sentences: ['咬定青山不放松', '立根原在破岩中', '千磨万击还坚劲', '任尔东西南北风'],
      rhymeScheme: ['松', '中', '风'],
    },
    annotations: [
      { term: '咬定', note: '紧紧咬住，比喻扎根牢固。' },
      { term: '破岩', note: '碎裂的岩石。' },
      { term: '坚劲', note: '坚韧挺拔。' },
      { term: '任尔', note: '任凭你。' },

    ],
    translation: '紧紧咬住青山毫不放松，它的根须原来就扎在碎裂的岩石之中。经受千万次的磨炼和打击依然坚韧挺拔，任凭你刮东西南北什么风。',
    literaryInfo: {
      authorBio: '郑燮（1693年—1765年），字克柔，号板桥，清代书画家、诗人，"扬州八怪"之一。',
      background: '此诗为郑板桥题画诗，借竹子生长在岩石中的坚韧品质表达自己的志向。',
      significance: `"咬定青山不放松"和"任尔东西南北风"是表达坚守气节的千古名句。此诗为题画诗，借竹子扎根破岩、不畏风霜的形象表达志向。"咬定"极写竹根的牢固，"千磨万击还坚劲"写无论多少磨难都改变不了竹的坚韧，"任尔"二字豪迈洒脱，以轻蔑的语气写出对一切打击的不屑。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '咬定青山不放松', emotion: '坚定', intensity: 8 },
          { segment: '立根原在破岩中', emotion: '顽强', intensity: 7 },
          { segment: '千磨万击还坚劲', emotion: '坚韧', intensity: 9 },
          { segment: '任尔东西南北风', emotion: '豪迈', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_105',
    title: '采薇（节选）',
    author: '佚名',
    dynasty: '先秦',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '古体诗' },
    themes: ['思乡', '战争'],
    text: {
      original: '昔我往矣，杨柳依依。今我来思，雨雪霏霏。行道迟迟，载渴载饥。我心伤悲，莫知我哀！',
      sentences: ['昔我往矣，杨柳依依', '今我来思，雨雪霏霏', '行道迟迟，载渴载饥', '我心伤悲，莫知我哀'],
      rhymeScheme: ['依', '霏', '饥', '哀'],
    },
    annotations: [
      { term: '薇', note: '一种野菜，可食用。' },
      { term: '昔我往矣', note: '当初我出发的时候。' },
      { term: '雨雪', note: '下雪。雨，此处作动词。' },
      { term: '载渴载饥', note: '又渴又饿。载，又。' },

      { term: '依依', note: '柳枝随风飘拂的样子。' },
      { term: '霏霏', note: '雪花纷飞的样子。' }
    ],
    translation: '当初我出征的时候，杨柳依依随风飘舞。如今我回来了，大雪纷纷漫天飞舞。道路泥泞走得很慢，又渴又饥。我的心里多么悲伤，有谁能知道我的哀愁！',
    literaryInfo: {
      authorBio: '佚名，出自《诗经·小雅》，为先秦时期的民间诗歌。',
      background: '此诗描写戍边将士归途中的情景，以昔日离别和今日归来的对比表达战争的苦难。',
      significance: `"昔我往矣，杨柳依依。今我来思，雨雪霏霏"是《诗经》中最著名的诗句之一。以昔日出征时杨柳依依的春景与今日归来时雨雪霏霏的冬景形成鲜明对比，同一路途两种季节映照两种心情——去时虽别犹有春色慰藉，归时虽喜却满目凄凉。"莫知我哀"以无人理解作结，更加深了悲凉。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '昔我往矣，杨柳依依', emotion: '回忆', intensity: 5 },
          { segment: '今我来思，雨雪霏霏', emotion: '凄凉', intensity: 8 },
          { segment: '行道迟迟，载渴载饥', emotion: '艰辛', intensity: 7 },
          { segment: '我心伤悲，莫知我哀', emotion: '悲伤', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 32, sentenceCount: 4, rhymeCount: 4 },
  },
  {
    id: 'p_106',
    title: '送元二使安西',
    author: '王维',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['送别', '友情'],
    text: {
      original: '渭城朝雨浥轻尘，客舍青青柳色新。劝君更尽一杯酒，西出阳关无故人。',
      sentences: ['渭城朝雨浥轻尘', '客舍青青柳色新', '劝君更尽一杯酒', '西出阳关无故人'],
      rhymeScheme: ['尘', '新', '人'],
    },
    annotations: [
      { term: '元二', note: '姓元，排行第二，王维的朋友。' },
      { term: '安西', note: '安西都护府，在今新疆库车。' },
      { term: '浥', note: '湿润。' },
      { term: '阳关', note: '古关名，在今甘肃敦煌西南。' },

      { term: '浥轻尘', note: '润湿了地上的浮尘。浥，湿润。' },
      { term: '更尽', note: '再喝完。更，再。' },
      { term: '故人', note: '老朋友。' }
    ],
    translation: '清晨的细雨润湿了渭城的浮尘，客舍旁的柳树显得更加青翠清新。劝你再喝一杯离别之酒，向西出了阳关就没有老朋友了。',
    literaryInfo: {
      authorBio: '王维（701年—761年），字摩诘，唐代诗人、画家，有"诗佛"之称。',
      background: '此诗为送别友人出使安西而作，表达深切的惜别之情。',
      significance: `"劝君更尽一杯酒，西出阳关无故人"是千古送别名句。"渭城朝雨浥轻尘"以清晨微雨的清新写送别环境，"客舍青青柳色新"以柳色点出惜别之情。"更尽一杯酒"将千言万语融入一杯酒中，"更"字写出了不忍分别的眷恋；"西出阳关无故人"写出了此去的孤寂。后被谱成《阳关三叠》传唱千古。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '渭城朝雨浥轻尘', emotion: '清新', intensity: 4 },
          { segment: '客舍青青柳色新', emotion: '惜别', intensity: 5 },
          { segment: '劝君更尽一杯酒', emotion: '深情', intensity: 8 },
          { segment: '西出阳关无故人', emotion: '感伤', intensity: 10 },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_107',
    title: '春夜喜雨',
    author: '杜甫',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '田园'],
    text: {
      original: '好雨知时节，当春乃发生。随风潜入夜，润物细无声。野径云俱黑，江船火独明。晓看红湿处，花重锦官城。',
      sentences: ['好雨知时节', '当春乃发生', '随风潜入夜', '润物细无声', '野径云俱黑', '江船火独明', '晓看红湿处', '花重锦官城'],
      rhymeScheme: ['生', '声', '明', '城'],
    },
    annotations: [
      { term: '乃发生', note: '就下起来了。' },
      { term: '潜', note: '悄悄地。' },
      { term: '花重', note: '花因沾雨水而显得饱满沉重。重，沉重。' },
      { term: '锦官城', note: '成都的别称。' },

      { term: '潜入夜', note: '悄悄地在夜间降临。潜，暗暗地。' },
      { term: '花重锦官城', note: '锦官城中的花因沾满雨水而显得沉重饱满。重，沉甸甸。' }
    ],
    translation: '好雨知道下雨的节气，正是在春天植物萌发生长的时候。它随着春风在夜里悄悄到来，默默地滋润着万物。野外的小路和乌云都是黑沉沉的，只有江边船上的灯火格外明亮。等天亮后去看看被雨水湿润的红花，整个锦官城中的繁花都显得沉甸甸的。',
    literaryInfo: {
      authorBio: '杜甫（712年—770年），字子美，自号少陵野老，唐代伟大的现实主义诗人，被后人誉为"诗圣"。',
      background: '此诗作于杜甫寓居成都草堂时期，春夜降雨令诗人欣喜而作。',
      significance: `"随风潜入夜，润物细无声"是千古名句。全诗以"喜"字贯穿，"好雨知时节"以"知"字赋予春雨灵性——它懂得何时该下雨。"潜入夜"写雨的悄无声息，"细无声"写雨的轻柔细腻。"野径云俱黑，江船火独明"以黑与明的对比写夜雨的深沉。"晓看红湿处，花重锦官城"以雨后繁花的饱满沉重写春雨润物的效果，"重"字极为精妙。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '天景', content: '好雨知时节', keywords: ['好雨', '时节'] },
          { level: '动态', content: '随风潜入夜', keywords: ['潜入夜', '细无声'] },
          { level: '夜景', content: '野径黑江船明', keywords: ['野径', '江船'] },
          { level: '晨景', content: '花重锦官城', keywords: ['红湿', '锦官城'] },
        ],
      },
    },
    stats: { charCount: 40, sentenceCount: 8, rhymeCount: 4 },
  },
  {
    id: 'p_108',
    title: '早春呈水部张十八员外',
    author: '韩愈',
    dynasty: '唐',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水'],
    text: {
      original: '天街小雨润如酥，草色遥看近却无。最是一年春好处，绝胜烟柳满皇都。',
      sentences: ['天街小雨润如酥', '草色遥看近却无', '最是一年春好处', '绝胜烟柳满皇都'],
      rhymeScheme: ['酥', '无', '都'],
    },
    annotations: [
      { term: '天街', note: '京城的街道。' },
      { term: '酥', note: '酥油，形容春雨润泽。' },
      { term: '绝胜', note: '远远胜过。' },
      { term: '皇都', note: '京城，指长安。' },

      { term: '润如酥', note: '润泽如酥酪。酥，酥油，形容细滑润泽。' },
    ],
    translation: '京城的街道上细雨纷纷，润泽如酥油，远看草色青青走近看却几乎看不到。这是一年中最美的春色，远远胜过满城烟柳的暮春。',
    literaryInfo: {
      authorBio: '韩愈（768年—824年），字退之，唐代文学家、哲学家，"唐宋八大家"之首。',
      background: '此诗为韩愈赠友人张籍之作，赞美早春的独特之美。',
      significance: `"草色遥看近却无"是描写早春景色的千古名句。远处看草色青青，走近却几乎看不到，写出了早春草色若隐若现的微妙之美。这种审美发现独到而精微，韩愈称之为"最是一年春好处"，认为早春的清新远胜暮春的浓艳，在"无"处见"有"，在平淡中见神奇。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '小雨润如酥', keywords: ['小雨', '润如酥'] },
          { level: '中景', content: '草色遥看近却无', keywords: ['草色', '遥看'] },
          { level: '感悟', content: '最是春好处', keywords: ['春好处', '绝胜'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_109',
    title: '江上渔者',
    author: '范仲淹',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['人生', '哲理'],
    text: {
      original: '江上往来人，但爱鲈鱼美。君看一叶舟，出没风波里。',
      sentences: ['江上往来人', '但爱鲈鱼美', '君看一叶舟', '出没风波里'],
      rhymeScheme: ['美', '里'],
    },
    annotations: [
      { term: '但爱', note: '只喜爱。' },
      { term: '鲈鱼', note: '一种味道鲜美的鱼。' },
      { term: '一叶舟', note: '像一片树叶一样的小船。' },
      { term: '出没', note: '出现和隐没。' },

      { term: '但', note: '只，仅仅。' },
      { term: '鲈鱼美', note: '鲈鱼味道鲜美。' }
    ],
    translation: '江上来来往往的人，只喜爱鲈鱼的味道鲜美。你看那像树叶一样的小船，在风浪中出没是多么危险。',
    literaryInfo: {
      authorBio: '范仲淹（989年—1052年），字希文，北宋政治家、文学家，有"先天下之忧而忧"的名言。',
      background: '此诗以对比手法反映渔民的艰辛，类似于《悯农》的主题。',
      significance: `此诗与《悯农》异曲同工，以食客与渔者的对比揭示劳动者艰辛。"江上往来人，但爱鲈鱼美"写岸上食客只知鱼味鲜美；"君看一叶舟，出没风波里"写水上渔者冒着生命危险捕鱼。"往来人"的悠闲与"一叶舟"的危难形成强烈对比，全诗不着一字议论，却通过画面对比让读者自己体悟。`,
    },
    visualization: {
      type: 'lyrical',
      lyricalData: {
        emotionCurve: [
          { segment: '江上往来人', emotion: '平静', intensity: 3 },
          { segment: '但爱鲈鱼美', emotion: '贪恋', intensity: 4 },
          { segment: '君看一叶舟', emotion: '关注', intensity: 6 },
          { segment: '出没风波里', emotion: '担忧', intensity: 9 },
        ],
      },
    },
    stats: { charCount: 20, sentenceCount: 4, rhymeCount: 2 },
  },
  {
    id: 'p_110',
    title: '泊船瓜洲',
    author: '王安石',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['思乡', '山水'],
    text: {
      original: '京口瓜洲一水间，钟山只隔数重山。春风又绿江南岸，明月何时照我还。',
      sentences: ['京口瓜洲一水间', '钟山只隔数重山', '春风又绿江南岸', '明月何时照我还'],
      rhymeScheme: ['间', '山', '还'],
    },
    annotations: [
      { term: '京口', note: '今江苏省镇江市。' },
      { term: '瓜洲', note: '在今江苏省扬州市南，长江北岸。' },
      { term: '钟山', note: '今南京紫金山。' },
      { term: '绿', note: '吹绿，用作动词。' },

      { term: '一水间', note: '只隔一条江水。间，间隔。' },
      { term: '数重山', note: '几重山岭。' },
      { term: '照我还', note: '照着我回来。' }
    ],
    translation: '京口和瓜洲之间只隔着一条长江，钟山也只隔着几重山峦。春风又一次吹绿了江南的大地，明月什么时候才能照着我回到故乡？',
    literaryInfo: {
      authorBio: '王安石（1021年—1086年），字介甫，号半山，北宋政治家、文学家，"唐宋八大家"之一。',
      background: '此诗作于王安石再次被召入京途中，路过瓜洲时思念家乡而作。',
      significance: `"春风又绿江南岸"是千古名句，"绿"字用作动词，化静为动，生动形象，被誉为炼字的典范。据说王安石先后试用"到""过""入""满"等字，最终选定"绿"字，将春风吹过江南、万物由枯转荣的过程浓缩为一个字。"明月何时照我还"以问句收束，表达对归乡的渴望。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '远景', content: '京口瓜洲一水间', keywords: ['京口', '瓜洲'] },
          { level: '中景', content: '钟山数重山', keywords: ['钟山', '数重山'] },
          { level: '近景', content: '春风绿江南', keywords: ['春风', '绿江南'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_111',
    title: '游园不值',
    author: '叶绍翁',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '诗', subGenre: '近体诗' },
    themes: ['山水', '哲理'],
    text: {
      original: '应怜屐齿印苍苔，小扣柴扉久不开。春色满园关不住，一枝红杏出墙来。',
      sentences: ['应怜屐齿印苍苔', '小扣柴扉久不开', '春色满园关不住', '一枝红杏出墙来'],
      rhymeScheme: ['苔', '开', '来'],
    },
    annotations: [
      { term: '不值', note: '没有遇到，此处指没有见到园主人。' },
      { term: '应怜', note: '大概是心疼。' },
      { term: '屐齿', note: '木屐底下的齿。' },
      { term: '柴扉', note: '柴门。' },

      { term: '怜', note: '爱惜，喜爱。' },
      { term: '苍苔', note: '青苔。' },
      { term: '小扣', note: '轻轻敲门。扣，敲。' }
    ],
    translation: '大概是园主人担心我的木屐会踩坏了青苔，轻轻敲柴门好久也没有人来开。可是满园的春色是关不住的，一枝红色的杏花已经伸出了墙头来。',
    literaryInfo: {
      authorBio: '叶绍翁，南宋诗人，字嗣宗，号靖逸，龙泉（今属浙江）人。',
      background: '此诗写诗人春日游园未遇主人，却从一枝伸出墙外的杏花感受到春天的气息。',
      significance: `"春色满园关不住，一枝红杏出墙来"是千古名句。前两句写游园不遇的遗憾，后两句突然转折——虽未入园，一枝伸出墙外的红杏已透露了满园春色。"关不住"与"出墙来"构成张力——春色是关不住的，生命是不可阻挡的，既写春色之美，也寓意新生事物无法被遏制。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '近景', content: '屐齿苍苔柴扉', keywords: ['屐齿', '苍苔'] },
          { level: '中景', content: '满园春色', keywords: ['春色', '满园'] },
          { level: '特写', content: '一枝红杏出墙来', keywords: ['红杏', '出墙'] },
        ],
      },
    },
    stats: { charCount: 28, sentenceCount: 4, rhymeCount: 3 },
  },
  {
    id: 'p_112',
    title: '卜算子·送鲍浩然之浙东',
    author: '王观',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '词', subGenre: '婉约派' },
    themes: ['送别', '山水'],
    text: {
      original: `水是眼波横，山是眉峰聚。欲问行人去那边？眉眼盈盈处。才始送春归，又送君归去。若到江南赶上春，千万和春住。`,
      sentences: ['水是眼波横', '山是眉峰聚', '欲问行人去那边', '眉眼盈盈处', '才始送春归', '又送君归去', '若到江南赶上春', '千万和春住'],
      rhymeScheme: ['聚', '处', '去', '住'],
    },
    annotations: [
      { term: '卜算子', note: '词牌名。' },
      { term: '鲍浩然', note: '词人的友人。' },
      { term: '之浙东', note: '前往浙东。之，往、到。' },
      { term: '眼波横', note: '形容水如美人流动的目光。' },
      { term: '眉峰聚', note: '形容山峦如美人的蹙眉。' },
      { term: '盈盈', note: '美好的样子。' },
      { term: '才始', note: '刚刚。' },

      { term: '水是眼波横', note: '水像眼波一样横流。比喻流水如美人的眼波。' },
      { term: '送鲍浩然', note: '送别鲍浩然。之，往，到。' }
    ],
    translation: '水像美人流动的眼波，山如美人蹙起的眉毛。要问行人去哪里？去那山水交汇的美丽地方。才刚刚送走了春天，又要送你离去。如果你到了江南还能赶上春天，千万要和春天住在一起。',
    literaryInfo: {
      authorBio: '王观，北宋词人，生卒年不详，字通叟，如皋（今属江苏）人。',
      background: '此词为送别友人鲍浩然去浙东而作，以山水喻眉眼，构思新颖。',
      significance: `"水是眼波横，山是眉峰聚"以美人眉眼喻山水，构思奇巧。"若到江南赶上春，千万和春住"语浅情深，表面是嘱咐友人留住春光，实则暗含惜别之意。全词以山水拟人，将送别的感伤化为对友人前路的美好祝愿，格调清新。`,
    },
    visualization: {
      type: 'scenic',
      scenicData: {
        layers: [
          { level: '水景', content: '眼波横', keywords: ['眼波', '水'] },
          { level: '山景', content: '眉峰聚', keywords: ['眉峰', '山'] },
          { level: '情感', content: '送春送人', keywords: ['送春', '送君'] },
        ],
      },
    },
    stats: { charCount: 30, sentenceCount: 8, rhymeCount: 4 },
  },
  // ===== 小学文言文 =====
  {
    id: 'p_113',
    title: '司马光',
    author: '佚名',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '文言文', subGenre: '记叙文' },
    themes: ['哲理', '人生'],
    text: {
      original: '群儿戏于庭，一儿登瓮，足跌没水中。众皆弃去，光持石击瓮破之，水迸，儿得活。',
      sentences: ['群儿戏于庭', '一儿登瓮，足跌没水中', '众皆弃去', '光持石击瓮破之', '水迸，儿得活'],
    },
    annotations: [
      { term: '瓮', note: '一种盛水或酒的陶器，口小肚大。' },
      { term: '足跌', note: '失足跌落。' },
      { term: '没', note: '淹没，沉没。' },
      { term: '众皆弃去', note: '其他小孩都吓得跑开了。皆，都。弃去，跑开。' },
      { term: '迸', note: '涌出。' },
      { term: '光', note: '指司马光。' },
      { term: '戏于庭', note: '在院子里玩耍。于，介词，在。' },

    ],
    translation: '一群小孩在院子里玩耍，一个小孩爬上大水缸，失足跌落被水淹没。其他小孩都吓得跑开了，只有司马光拿起石头砸破了水缸，水流了出来，落水的小孩得救了。',
    literaryInfo: {
      authorBio: '佚名，出自《宋史·司马光传》。司马光（1019年—1086年），字君实，北宋政治家、史学家。',
      background: '此故事记述了司马光幼年时砸缸救人的故事。',
      significance: `此故事表现了司马光遇事冷静沉着、善于动脑的品质。"众皆弃去"以众人的惊慌逃跑反衬司马光的冷静，"光持石击瓮破之"写他的果断行动，"水迸，儿得活"是圆满结局。全篇叙事简洁，对比鲜明，是培养儿童判断力和勇气的经典故事。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '群儿玩耍，一儿落入水瓮，众人惊逃，司马光砸瓮救人。',
        timeline: [
          { event: '群儿戏于庭', order: 1 },
          { event: '一儿落水', order: 2 },
          { event: '众皆弃去', order: 3 },
          { event: '光持石击瓮', order: 4 },
          { event: '儿得活', order: 5 },
        ],
      },
    },
    stats: { charCount: 30, sentenceCount: 5, rhymeCount: 0 },
  },
  {
    id: 'p_114',
    title: '守株待兔',
    author: '佚名',
    dynasty: '先秦',
    gradeLevel: { stage: '小学', grade: '三年级' },
    genre: { category: '文言文', subGenre: '说理文' },
    themes: ['哲理', '人生'],
    text: {
      original: '宋人有耕者。田中有株。兔走触株，折颈而死。因释其耒而守株，冀复得兔。兔不可复得，而身为宋国笑。',
      sentences: ['宋人有耕者', '田中有株', '兔走触株，折颈而死', '因释其耒而守株', '冀复得兔', '兔不可复得，而身为宋国笑'],
    },
    annotations: [
      { term: '株', note: '树桩。' },
      { term: '走', note: '跑。【古今异义】古义为跑，今义为步行。' },
      { term: '释', note: '放下。' },
      { term: '耒', note: '古代的一种农具，形如木叉。' },
      { term: '冀', note: '希望。' },
      { term: '触', note: '撞到。' },
      { term: '折颈', note: '折断脖子。' },
      { term: '为……笑', note: '被……嘲笑。为，介词，被。' },

      { term: '宋人', note: '宋国人。' },
    ],
    translation: '宋国有个农民，他的田地中有一个树桩。一天，一只奔跑的兔子撞在了树桩上，扭断了脖子死了。于是这个农民便放下手中的农具，整天守在树桩旁，希望能再捡到撞死的兔子。兔子当然不可能再捡到，而他自己也被宋国人耻笑。',
    literaryInfo: {
      authorBio: '佚名，出自《韩非子·五蠹》。韩非（约前280年—前233年），战国末期思想家，法家代表人物。',
      background: '此寓言出自《韩非子》，用以讽刺那些不知变通、墨守成规的人。',
      significance: `"守株待兔"已成为常用成语。此寓言以荒诞的故事讽刺不知变通、心存侥幸的人。兔子撞桩而死是极偶然的事件，农夫却将偶然当必然，放弃农耕守株等兔，结果"兔不可复得，而身为宋国笑"。告诫人们不要心存侥幸，要靠自己的努力去获得成功。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '农夫见兔触株而死，便放下农具守株等兔，终为国人所笑。',
        timeline: [
          { event: '兔走触株折颈死', order: 1 },
          { event: '释耒守株', order: 2 },
          { event: '冀复得兔', order: 3 },
          { event: '兔不可复得', order: 4 },
          { event: '身为宋国笑', order: 5 },
        ],
      },
    },
    stats: { charCount: 39, sentenceCount: 6, rhymeCount: 0 },
  },
  {
    id: 'p_115',
    title: '囊萤夜读',
    author: '佚名',
    dynasty: '魏晋南北朝',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '文言文', subGenre: '记叙文' },
    themes: ['哲理', '人生'],
    text: {
      original: '胤恭勤不倦，博学多通。家贫不常得油，夏月则练囊盛数十萤火以照书，以夜继日焉。',
      sentences: ['胤恭勤不倦，博学多通', '家贫不常得油', '夏月则练囊盛数十萤火以照书', '以夜继日焉'],
    },
    annotations: [
      { term: '恭勤', note: '肃敬勤勉。' },
      { term: '练囊', note: '白色薄绢做的口袋。练，白绢。' },
      { term: '盛', note: '装，放入。【词类活用】此处为动词，把……装入。' },
      { term: '以夜继日', note: '用夜晚的时间接上白天，形容日夜不停。' },
      { term: '通', note: '精通，通晓。' },
      { term: '焉', note: '语气助词，表陈述。' },
      { term: '博学', note: '学识广博。' },

      { term: '恭', note: '恭敬。' },
      { term: '不倦', note: '不知疲倦。' }
    ],
    translation: '车胤谦恭有礼、勤勉而不知疲倦，知识广博学问精通。家里贫穷常常买不起灯油，夏天的夜晚他就用白色薄绢做成小口袋，装几十只萤火虫来照着读书，夜以继日地学习。',
    literaryInfo: {
      authorBio: '佚名，出自《晋书·车胤传》。车胤（约333年—约401年），东晋大臣，以勤学著称。',
      background: '此故事记述车胤家贫夜读的典故，是中国古代刻苦读书的代表性故事之一。',
      significance: `"囊萤夜读"是著名的勤学故事，与"悬梁刺股""凿壁偷光"并称。车胤家贫买不起灯油，却想出用萤火虫照明的办法，以夜继日地苦读。"练囊盛数十萤火以照书"既写出条件的艰苦，也写出方法的巧妙和求学的执着。此故事告诉人们：条件再差也阻挡不了求学的决心。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '车胤家贫买不起灯油，以萤火虫照明读书，日夜苦学。',
        timeline: [
          { event: '车胤恭勤不倦', order: 1 },
          { event: '博学多通', order: 2 },
          { event: '家贫不常得油', order: 3 },
          { event: '练囊盛数十萤火', order: 4 },
          { event: '以萤火照书夜读', order: 5 },
          { event: '以夜继日终成名', order: 6 },
        ],
      },
    },
    stats: { charCount: 33, sentenceCount: 4, rhymeCount: 0 },
  },
  {
    id: 'p_116',
    title: '铁杵成针',
    author: '佚名',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '四年级' },
    genre: { category: '文言文', subGenre: '记叙文' },
    themes: ['哲理', '人生'],
    text: {
      original: '磨针溪，在象耳山下。世传李太白读书山中，未成，弃去。过是溪，逢老媪方磨铁杵。问之，曰：\`欲作针。\`太白感其意，还卒业。',
      sentences: ['磨针溪，在象耳山下', '世传李太白读书山中，未成，弃去', '过是溪，逢老媪方磨铁杵', '问之，曰：欲作针', '太白感其意，还卒业'],
    },
    annotations: [
      { term: '铁杵', note: '铁制的舂米或捶衣的棒。' },
      { term: '媪', note: '老年妇女。' },
      { term: '方', note: '正在。' },
      { term: '卒业', note: '完成学业。' },
      { term: '是', note: '这，此。【古今异义】古义为这，今多用作判断词。' },
      { term: '感其意', note: '被她的心意所感动。' },
      { term: '还', note: '回去，返回。' },

      { term: '世传', note: '世间传说。' },
    ],
    translation: '磨针溪在象耳山脚下。世人相传李白在山中读书，还没有读完，就放弃离开了。经过这条小溪，遇到一位老妇人正在磨一根铁杵。李白问她在做什么，老妇人说："我想把它磨成针。"李白被她的精神感动，于是回去完成了学业。',
    literaryInfo: {
      authorBio: '佚名，出自南宋祝穆《方舆胜览》。故事主角李白（701年—762年），唐代伟大诗人。',
      background: '此故事为关于李白少年勤学的传说，记述了"铁杵磨成针"的典故。',
      significance: `"只要功夫深，铁杵磨成针"是中国人耳熟能详的励志名言。李白读书未成弃去，遇到老媪磨铁杵欲作针，被其精神感动而返完成学业。故事以老媪磨针的坚韧与李白弃学的浮躁形成对比，铁杵之粗与针之细的巨大反差更强化了"功夫深"的必要。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '李白读书未成弃去，遇老媪磨铁杵欲作针，受感动而返卒业。',
        timeline: [
          { event: '磨针溪在象耳山下', order: 1 },
          { event: '李白读书山中未成弃去', order: 2 },
          { event: '过溪逢老媪方磨铁杵', order: 3 },
          { event: '问之曰欲作针', order: 4 },
          { event: '太白感其意', order: 5 },
          { event: '还卒业完成学业', order: 6 },
        ],
      },
    },
    stats: { charCount: 49, sentenceCount: 5, rhymeCount: 0 },
  },
  {
    id: 'p_117',
    title: '自相矛盾',
    author: '佚名',
    dynasty: '先秦',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '文言文', subGenre: '说理文' },
    themes: ['哲理', '人生'],
    text: {
      original: '楚人有鬻盾与矛者，誉之曰：\`吾盾之坚，物莫能陷也。\`又誉其矛曰：\`吾矛之利，于物无不陷也。\`或曰：\`以子之矛陷子之盾，何如？\`其人弗能应也。夫不可陷之盾与无不陷之矛，不可同世而立。',
      sentences: ['楚人有鬻盾与矛者', '誉之曰：吾盾之坚，物莫能陷也', '又誉其矛曰：吾矛之利，于物无不陷也', '或曰：以子之矛陷子之盾，何如', '其人弗能应也', '夫不可陷之盾与无不陷之矛，不可同世而立'],
    },
    annotations: [
      { term: '鬻', note: '卖。' },
      { term: '誉', note: '夸耀。' },
      { term: '陷', note: '刺破，穿透。' },
      { term: '弗能应', note: '不能回答。弗，不。' },
      { term: '或', note: '有人。【古今异义】古义为有人，今多用作选择连词。' },
      { term: '子', note: '你，对人的尊称。【古今异义】古义为你，今多指儿子。' },
      { term: '立', note: '存在，成立。' },
      { term: '夫', note: '句首发语词，无实义。' },

    ],
    translation: '楚国有个卖盾和矛的人，他夸耀自己的盾说："我的盾坚固无比，什么东西都刺不破。"又夸耀自己的矛说："我的矛锋利无比，什么东西都能刺穿。"有人说："用你的矛去刺你的盾，会怎么样呢？"那个人回答不出来了。什么都刺不破的盾和什么都能刺穿的矛，是不可能同时存在的。',
    literaryInfo: {
      authorBio: '佚名，出自《韩非子·难一》。韩非（约前280年—前233年），战国末期思想家，法家代表人物。',
      background: '此寓言出自《韩非子》，用以说明互相矛盾的说法不能同时成立。',
      significance: `"自相矛盾"已成为常用成语，告诫人们说话做事要前后一致，不能自相抵触。此寓言以卖者自夸的荒诞场景，揭示逻辑自洽的重要性：坚不可破之盾与无坚不摧之矛不可能同时成立。"以子之矛陷子之盾"的追问如利刃直戳矛盾核心，卖者"弗能应"恰证其荒谬。韩非子借此寓言批评儒家"尧舜并圣"之说自相矛盾，具有深刻的哲学思辨意义。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '楚人卖盾与矛，夸盾不可破又夸矛无不利，被人质疑后无法自圆其说。',
        timeline: [
          { event: '鬻盾与矛', order: 1 },
          { event: '誉盾之坚', order: 2 },
          { event: '誉矛之利', order: 3 },
          { event: '或问以矛陷盾', order: 4 },
          { event: '弗能应', order: 5 },
        ],
      },
    },
    stats: { charCount: 83, sentenceCount: 6, rhymeCount: 0 },
  },
  {
    id: 'p_118',
    title: '杨氏之子',
    author: '佚名',
    dynasty: '魏晋南北朝',
    gradeLevel: { stage: '小学', grade: '五年级' },
    genre: { category: '文言文', subGenre: '记叙文' },
    themes: ['哲理', '人生'],
    text: {
      original: '梁国杨氏子九岁，甚聪惠。孔君平诣其父，父不在，乃呼儿出。为设果，果有杨梅。孔指以示儿曰：\`此是君家果。\`儿应声答曰：\`未闻孔雀是夫子家禽。\`',
      sentences: ['梁国杨氏子九岁，甚聪惠', '孔君平诣其父，父不在，乃呼儿出', '为设果，果有杨梅', '孔指以示儿曰：此是君家果', '儿应声答曰：未闻孔雀是夫子家禽'],
    },
    annotations: [
      { term: '聪惠', note: `聪明伶俐。惠，同"慧"，聪明。【通假字】"惠"同"慧"。` },
      { term: '诣', note: '拜访。' },
      { term: '乃', note: '就，于是。' },
      { term: '夫子', note: '对男子的尊称，此处指孔君平。' },
      { term: '设果', note: '摆放水果。设，摆放。' },
      { term: '应声', note: '随声，紧接着。形容反应迅速。' },
      { term: '家禽', note: `家中饲养的禽类。此处为双关，"禽"与"琴"谐音。【古今异义】今义为家养的鸟类，此处取字面本义。` },

      { term: '甚聪惠', note: '非常聪明。惠，同“慧”，聪明。' }
    ],
    translation: '梁国一户姓杨的人家有个九岁的儿子，非常聪明。孔君平来拜访他的父亲，恰巧父亲不在家，就把孩子叫了出来。孩子给孔君平端上了水果，其中有杨梅。孔君平指着杨梅对孩子说："这是你们家的水果。"孩子马上回答说："我可没听说过孔雀是您家的家禽。"',
    literaryInfo: {
      authorBio: '佚名，出自南朝刘义庆《世说新语·言语》。刘义庆（403年—444年），南朝宋宗室，文学家。',
      background: '此故事记述杨氏之子以杨梅和孔雀的姓氏关联机智应答的故事。',
      significance: `此故事展现了儿童的机智和语言才华。孔君平以"杨梅"谐"杨"姓戏言"此是君家果"，杨氏之子立即以"孔雀"谐"孔"姓妙答"未闻孔雀是夫子家禽"，以彼之道还施彼身。对答之妙在于：既沿用了对方姓氏关联的思路，又用"未闻"一词委婉反驳，不卑不亢。"应声"二字写出反应之快，九岁小儿有如此才思，令人叹服。全篇语言简洁，人物鲜明，是训练语言智慧的经典故事。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '杨氏子九岁甚聪惠，以孔雀非孔君平家禽巧妙回应杨梅是君家果的戏言。',
        timeline: [
          { event: '杨氏子九岁甚聪惠', order: 1 },
          { event: '孔君平诣其父', order: 2 },
          { event: '父不在乃呼儿出', order: 3 },
          { event: '为设果果有杨梅', order: 4 },
          { event: '孔指杨梅戏言君家果', order: 5 },
          { event: '儿应声答未闻孔雀家禽', order: 6 },
        ],
      },
    },
    stats: { charCount: 63, sentenceCount: 5, rhymeCount: 0 },
  },
  {
    id: 'p_119',
    title: '伯牙鼓琴',
    author: '佚名',
    dynasty: '先秦',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '文言文', subGenre: '记叙文' },
    themes: ['友情', '人生'],
    text: {
      original: '伯牙鼓琴，锺子期听之。方鼓琴而志在太山，锺子期曰：\`善哉乎鼓琴，巍巍乎若太山。\`少选之间而志在流水，锺子期又曰：\`善哉乎鼓琴，汤汤乎若流水。\`锺子期死，伯牙破琴绝弦，终身不复鼓琴，以为世无足复为鼓琴者。',
      sentences: ['伯牙鼓琴，锺子期听之', '方鼓琴而志在太山', '锺子期曰：善哉乎鼓琴，巍巍乎若太山', '少选之间而志在流水', '锺子期又曰：善哉乎鼓琴，汤汤乎若流水', '锺子期死，伯牙破琴绝弦', '终身不复鼓琴', '以为世无足复为鼓琴者'],
    },
    annotations: [
      { term: '鼓琴', note: '弹琴。鼓，弹奏。【词类活用】"鼓"名词用作动词，弹奏。' },
      { term: '善哉', note: '好啊。善，好。哉，语气词，表感叹。' },
      { term: '少选', note: '一会儿，不久。' },
      { term: '汤汤', note: '水流湍急的样子。' },
      { term: '巍巍', note: '高大的样子。' },
      { term: '志', note: '心志，心中所想。' },
      { term: '破琴绝弦', note: '摔破琴身扯断琴弦。' },
      { term: '足', note: '值得。' },

    ],
    translation: '伯牙弹琴，锺子期听他弹奏。刚开始弹琴时伯牙心中想着泰山，锺子期说："弹得真好啊，像巍峨的泰山一样。"过了一会儿，伯牙心中又想着流水，锺子期又说："弹得真好啊，像奔流的江河一样。"锺子期死后，伯牙摔破了琴扯断了弦，终身不再弹琴，认为世上再也没有值得为他弹琴的人了。',
    literaryInfo: {
      authorBio: '佚名，出自《吕氏春秋·本味》。吕不韦（？—前235年），战国末期政治家，《吕氏春秋》的主编。',
      background: '此故事记述了伯牙与锺子期以琴相交的知音故事。',
      significance: `"高山流水""知音"的典故即源于此，伯牙绝弦的故事成为友情至深的象征。文中"巍巍乎若太山""汤汤乎若流水"两处描写，将无形的琴声化为有形的山川，展现了伯牙琴艺的高超与锺子期鉴赏的精妙。子期死后伯牙"破琴绝弦，终身不复鼓琴"，极端的行为表达极端的情感：知音既逝，琴声再美也无人能解。全篇以琴声为纽带、以生死为断点，结构上先合后离，对比鲜明，"知音"一词由此成为挚友的代称。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '伯牙鼓琴志在高山流水，锺子期皆能领悟，锺子期死后伯牙绝弦不复鼓。',
        timeline: [
          { event: '伯牙鼓琴', order: 1 },
          { event: '志在太山，锺子期善听', order: 2 },
          { event: '志在流水，锺子期善听', order: 3 },
          { event: '锺子期死', order: 4 },
          { event: '破琴绝弦', order: 5 },
        ],
      },
    },
    stats: { charCount: 91, sentenceCount: 8, rhymeCount: 0 },
  },
  {
    id: 'p_120',
    title: '书戴嵩画牛',
    author: '苏轼',
    dynasty: '宋',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '文言文', subGenre: '说理文' },
    themes: ['哲理', '人生'],
    text: {
      original: '蜀中有杜处士，好书画，所宝以百数。有戴嵩《牛》一轴，尤所爱，锦囊玉轴，常以自随。一日曝书画，有一牧童见之，拊掌大笑，曰：\`此画斗牛也。牛斗，力在角，尾搐入两股间，今乃掉尾而斗，谬矣。\`处士笑而然之。古语有云：\`耕当问奴，织当问婢。\`不可改也。',
      sentences: ['蜀中有杜处士，好书画', '有戴嵩《牛》一轴，尤所爱', '一日曝书画，有一牧童见之', '拊掌大笑曰：此画斗牛也，谬矣', '处士笑而然之', '古语云：耕当问奴，织当问婢'],
    },
    annotations: [
      { term: '处士', note: '有德才而隐居不愿做官的人。' },
      { term: '曝', note: '晒。' },
      { term: '搐', note: '收缩。' },
      { term: '掉尾', note: '摇尾巴。' },
      { term: '所宝', note: `所珍藏的。【词类活用】"宝"名词用作动词，当做珍宝。` },
      { term: '拊掌', note: '拍手。' },
      { term: '然之', note: `认为他说得对。然，认为……对。【词类活用】形容词的意动用法。` },
      { term: '婢', note: '婢女，此指织布的女子。' },

      { term: '谬', note: '错误。' },
    ],
    translation: '四川有个杜处士，喜爱书画，珍藏的书画数以百计。其中有一幅戴嵩画的《斗牛》，他特别喜爱，用锦囊装起来用玉做画轴，经常随身携带。有一天晒书画，一个牧童看到了这幅画，拍手大笑说："这画的是斗牛啊。牛相斗时力量在角上，尾巴收缩在两条大腿之间，现在这幅画上的牛却是摇着尾巴在斗，错了。"杜处士笑了笑认为他说得对。古人说："耕种的事应当问农夫，织布的事应当问织女。"这个道理是不可改变的。',
    literaryInfo: {
      authorBio: '苏轼（1037年—1101年），字子瞻，号东坡居士，北宋文学家、书画家，"唐宋八大家"之一。',
      background: '此文为苏轼题画杂记，通过牧童指出名画错误的故事，阐述实践出真知的道理。',
      significance: `此文通过牧童指出名画错误的故事，阐述实践出真知的道理。杜处士"锦囊玉轴，常以自随"的珍爱与牧童"拊掌大笑"的率真形成鲜明对比，名画家戴嵩的权威与牧童的常识也形成反差。牧童以"牛斗，力在角，尾搐入两股间"的生活经验指出"掉尾而斗"的谬误，说明艺术创作不能脱离实际观察。结尾"耕当问奴，织当问婢"以俗语点题：内行人的经验最为可靠，实践是检验真理的标准。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '杜处士珍藏戴嵩《斗牛图》，牧童指出画中斗牛掉尾之误，处士然之。',
        timeline: [
          { event: '杜处士好书画', order: 1 },
          { event: '尤爱戴嵩牛', order: 2 },
          { event: '牧童见之拊掌大笑', order: 3 },
          { event: '指出谬误', order: 4 },
          { event: '处士然之', order: 5 },
        ],
      },
    },
    stats: { charCount: 101, sentenceCount: 6, rhymeCount: 0 },
  },
  {
    id: 'p_121',
    title: '学弈',
    author: '佚名',
    dynasty: '先秦',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '文言文', subGenre: '说理文' },
    themes: ['哲理', '人生'],
    text: {
      original: '弈秋，通国之善弈者也。使弈秋诲二人弈，其一人专心致志，惟弈秋之为听；一人虽听之，一心以为有鸿鹄将至，思援弓缴而射之。虽与之俱学，弗若之矣。为是其智弗若与？曰：非然也。',
      sentences: ['弈秋，通国之善弈者也', '使弈秋诲二人弈', '其一人专心致志，惟弈秋之为听', '一人虽听之，一心以为有鸿鹄将至', '思援弓缴而射之', '虽与之俱学，弗若之矣', '为是其智弗若与？曰：非然也'],
    },
    annotations: [
      { term: '弈', note: '下棋。' },
      { term: '通国', note: '全国。' },
      { term: '鸿鹄', note: '天鹅。' },
      { term: '弓缴', note: '系着丝绳的箭。缴，系在箭上的丝绳。' },
      { term: '诲', note: '教导。' },
      { term: '惟弈秋之为听', note: '只听弈秋的教导。惟，只。' },
      { term: '弗若', note: '不如，比不上。' },
      { term: '与', note: `同"欤"，语气词，表疑问。【通假字】"与"同"欤"。` },

      { term: '弈秋', note: '名叫秋的围棋高手。弈，下棋。' },
    ],
    translation: '弈秋是全国最善于下棋的人。让弈秋教两个人下棋，其中一个人专心致志，只听弈秋的教导；另一个人虽然也在听，但心里却想着天空中将有天鹅飞过，想要拿弓箭去射它。虽然他和前一个人一起学习，但成绩却不如前一个人。是因为他的智力不如吗？回答说：不是这样的。',
    literaryInfo: {
      authorBio: '佚名，出自《孟子·告子上》。孟子（约前372年—前289年），战国时期思想家，儒家代表人物。',
      background: '此故事出自《孟子》，用以说明学习必须专心致志的道理。',
      significance: `"专心致志"这一成语即源于此，故事以二人同师学弈却结果迥异的对比，论证学习必须专心致志。一人"惟弈秋之为听"，另一人"一心以为有鸿鹄将至"，同样的老师、同样的棋艺，差别仅在于心志的专注与否。"思援弓缴而射之"写出分心者的心理活动，生动传神。末句"为是其智弗若与？曰：非然也"以问答作结，明确否定智力差异，强调态度决定成败，说理有力。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '弈秋教二人弈，一人专心一人分心，结果不同，非智不如而是心不专。',
        timeline: [
          { event: '弈秋善弈', order: 1 },
          { event: '诲二人弈', order: 2 },
          { event: '一人专心致志', order: 3 },
          { event: '一人思射鸿鹄', order: 4 },
          { event: '弗若之矣', order: 5 },
          { event: '非智弗若', order: 6 },
        ],
      },
    },
    stats: { charCount: 70, sentenceCount: 7, rhymeCount: 0 },
  },
  {
    id: 'p_122',
    title: '两小儿辩日',
    author: '佚名',
    dynasty: '先秦',
    gradeLevel: { stage: '小学', grade: '六年级' },
    genre: { category: '文言文', subGenre: '说理文' },
    themes: ['哲理', '人生'],
    text: {
      original: '孔子东游，见两小儿辩斗，问其故。一儿曰：\`我以日始出时去人近，而日中时远也。\`一儿以日初出远，而日中时近也。一儿曰：\`日初出大如车盖，及日中则如盘盂，此不为远者小而近者大乎？\`一儿曰：\`日初出沧沧凉凉，及其日中如探汤，此不为近者热而远者凉乎？\`孔子不能决也。两小儿笑曰：\`孰为汝多知乎？\`',
      sentences: ['孔子东游，见两小儿辩斗', '一儿曰：我以日始出时去人近，而日中时远也', '一儿以日初出远，而日中时近也', '一儿曰：日初出大如车盖，及日中则如盘盂', '一儿曰：日初出沧沧凉凉，及其日中如探汤', '孔子不能决也', '两小儿笑曰：孰为汝多知乎'],
    },
    annotations: [
      { term: '辩斗', note: '辩论，争论。' },
      { term: '去', note: '距离。【古今异义】古义为距离，今多用作前往。' },
      { term: '盘盂', note: '盛物的器皿，圆者为盘，方者为盂。' },
      { term: '探汤', note: `把手伸进热水里。汤，热水。【古今异义】"汤"古义为热水，今多指食物煮后的汁液。` },
      { term: '车盖', note: '古代车上的圆形伞盖。' },
      { term: '沧沧凉凉', note: '清凉寒凉的样子。' },
      { term: '孰', note: '谁。' },
      { term: '知', note: `同"智"，智慧。【通假字】"知"同"智"。` },

      { term: '汤', note: '热水，开水。' },
      { term: '决', note: '判断，裁决。' }
    ],
    translation: '孔子到东方游历，看到两个小孩在争辩，就问他们争辩的原因。一个小孩说："我认为太阳刚出来的时候离人近，而正午的时候离人远。"另一个小孩认为太阳刚出来的时候离人远，而正午的时候离人近。一个小孩说："太阳刚出来的时候像车盖一样大，到了正午就像盘盂一样小，这不是远的小而近的大吗？"另一个小孩说："太阳刚出来的时候清凉凉爽，到了正午就像把手伸进热水里一样热，这不是近的热而远的凉吗？"孔子也不能判断谁对谁错。两个小孩笑着说："谁说你知识渊博呢？"',
    literaryInfo: {
      authorBio: '佚名，出自《列子·汤问》。列子，战国时期道家思想家。',
      background: '此故事以两小儿辩日为难孔子之事，说明知识无穷、学无止境的道理。',
      significance: `此故事以两小儿辩日为难孔子之事，说明知识无穷、学无止境。一儿从视觉出发，以"大如车盖"与"如盘盂"的对比论证近大远小；一儿从触觉出发，以"沧沧凉凉"与"如探汤"的对比论证近热远凉。两种推理各有依据却结论相反，连孔子也无法裁决。"孔子不能决也"体现了"知之为知之，不知为不知"的求实态度，两小儿"孰为汝多知乎"的天真发问更增趣味。全篇寓言还暗示：即使圣人也有不知之事，宇宙奥秘有待探索，不能盲从权威。`,
    },
    visualization: {
      type: 'narrative',
      narrativeData: {
        summary: '两小儿就太阳远近各执一词，孔子不能决，被两小儿笑问。',
        timeline: [
          { event: '孔子见两小儿辩斗', order: 1 },
          { event: '一儿以视觉论近远', order: 2 },
          { event: '一儿以触觉论近远', order: 3 },
          { event: '孔子不能决', order: 4 },
          { event: '两小儿笑之', order: 5 },
        ],
      },
    },
    stats: { charCount: 133, sentenceCount: 7, rhymeCount: 0 },
  },
];
